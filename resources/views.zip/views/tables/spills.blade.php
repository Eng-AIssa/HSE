<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Spill Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Accident') }}</li>
        <li class="breadcrumb-item">{{ __('Spill') }}</li>
        <li class="breadcrumb-item active">{{ __('Spill Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Chemical Spill Name</th>
                                <th>Chemical Spilled Quantity</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Was there a Fire ?</th>
                                <th>Is Process Fire ?</th>
                                <th>Any Person Exposed ?</th>
                                <th>Equipment Involved</th>
                                <th>Employee Involved</th>
                                <th>Nature of Chemical</th>
                                <th>Chemical Spilled to Surrounding</th>
                                <th>Spill Type</th>
                                <th>Spill Related To</th>
                                <th>Apparent Cause</th>
                                <th>Action Taken</th>
                                <th>Equipment Condition</th>
                                <th>Accident ID</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($spills as $spill)
                                <tr>
                                    <td>{{$spill->id ?? ''}}</td>
                                    <td>{{$spill->chemical_spill_name ?? ''}}</td>
                                    <td>{{$spill->chemical_spilled_quantity ?? ''}}</td>
                                    <td>{{$spill->location->name ?? ''}}</td>
                                    <td>{{$spill->area->name ?? ''}}</td>

                                    <td>{{(($spill->was_there_fire ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{ isset($spill->is_process_fire) ? ($spill->is_process_fire == 1 ? 'Yes' : 'No') : ''}}</td>
                                    <td>{{(($spill->was_any_person_exposed ?? '') == 1) ?  'Yes' : 'No'}}</td>

                                    <td>{{$spill->equipment_involved ?? ''}}</td>
                                    <td>{{ is_numeric($spill->employee_involved) ? $spill->employeeInvolved->name : $spill->employee_involved}}</td>

                                    <td>{{$spill->nature_of_chemical ?? ''}}</td>
                                    <td>
                                        @foreach($spill->chemical_spilled_to_surrounding ?? [''] as $item)
                                            {{$item}},
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($spill->spill_type ?? [''] as $type)
                                            {{$type}},
                                        @endforeach
                                    </td>
                                    <td>{{$spill->spill_related_to ?? ''}}</td>
                                    <td>{{$spill->apparent_cause ?? ''}}</td>
                                    <td>{{$spill->immediate_action_taken ?? ''}}</td>
                                    <td>{{$spill->equipment_condition ?? ''}}</td>
                                    <td>{{$spill->accident_id ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
