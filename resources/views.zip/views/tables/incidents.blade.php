<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Incident Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Incident') }}</li>
        <li class="breadcrumb-item active">{{ __('incident Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Incident Type</th>
                                <th>Incident Group</th>
                                <th>Title</th>
                                <th>Incident Date</th>
                                <th>Incident Time</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Incident Description</th>
                                <th>Logging Date</th>
                                <th>Logging Time</th>
                                <th>Immediate Action Taken</th>
                                <th>Incident Related to</th>
                                <th>Is Repeated</th>
                                <th>Activity at Time of Incident</th>
                                <th>Actual Loss</th>
                                <th>People</th>
                                <th>Environment</th>
                                <th>Asset</th>
                                <th>Reported by</th>
                                <th>Responsible Person</th>
                                <th>Stage </th>
                                <th>Timeline </th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($incidents as $incident)
                                <tr>

                                    <td>{{$incident->id ?? ''}}</td>
                                    <td>{{$incident->incident_type ?? ''}}</td>
                                    <td>{{$incident->incident_group ?? ''}}</td>
                                    <td>{{$incident->title ?? ''}}</td>
                                    <td>{{$incident->incident_date ?? ''}}</td>
                                    <td>{{$incident->incident_time ?? ''}}</td>
                                    <td>{{$incident->location->name ?? ''}}</td>
                                    <td>{{$incident->area->name ?? ''}}</td>
                                    <td>{{$incident->incident_description ?? ''}}</td>
                                    <td>{{$incident->logging_date ?? ''}}</td>
                                    <td>{{$incident->logging_time ?? ''}}</td>
                                    <td>{{$incident->immediate_action_taken ?? ''}}</td>
                                    <td>{{$incident->incident_related_to ?? ''}}</td>
                                    <td>{{(($incident->is_repeated ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{$incident->activity_at_time_of_incident ?? ''}}</td>
                                    <td>
                                        @foreach($incident->actual_loss ?? [] as $loss)
                                            {{$loss}},
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($incident->people ?? [] as $key => $value)
                                            {{$key . ' => ' . $value}}, {{ ' ' }}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($incident->environment ?? [] as $key => $value)
                                            {{$key . ' => ' . $value}}, {{ ' ' }}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($incident->asset ?? [] as $key => $value)
                                            {{$key . ' => ' . $value}}, {{ ' ' }}
                                        @endforeach
                                    </td>
                                    <td>{{$incident->reporter->name ?? ''}}</td>
                                    <td>{{$incident->responsible->name ?? ''}}</td>
                                    <td>{{$incident->stage->name ?? ''}}</td>
                                    <td>{{$incident->timeline->name ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
