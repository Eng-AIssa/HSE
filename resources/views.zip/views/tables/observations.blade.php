<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Observation Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Observation') }}</li>
        <li class="breadcrumb-item active">{{ __('Observation Reports') }}</li>
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Category</th>
                                <th>Sub Category</th>
                                <th>Description</th>
                                <th>Immediate Action</th>
                                <th>People Consequences</th>
                                <th>Environment Consequences</th>
                                <th>Asset Consequences</th>
                                <th>Comment</th>
                                <th>Reported By</th>
                                <th>Responsible</th>
                                <th>Stage</th>
                                <th>timeline</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($observations as $observation)
                                <tr>
                                    <td>{{$observation->id ?? ''}}</td>
                                    <td>{{$observation->title ?? ''}}</td>
                                    <td>{{$observation->observation_date ?? ''}}</td>
                                    <td>{{$observation->observation_time ?? ''}}</td>
                                    <td>{{$observation->location->name ?? ''}}</td>
                                    <td>{{$observation->area->name ?? ''}}</td>
                                    <td>{{$observation->category ?? ''}}</td>
                                    <td>{{$observation->sub_category ?? ''}}</td>
                                    <td>{{$observation->observation_description ?? ''}}</td>
                                    <td>{{$observation->immediate_action_taken ?? ''}}</td>
                                    <td>{{$observation->people_potential_consequences ?? ''}}</td>
                                    <td>{{$observation->environment_potential_consequences ?? ''}}</td>
                                    <td>{{$observation->asset_potential_consequences ?? ''}}</td>
                                    <td>{{$observation->comment ?? ''}}</td>
                                    <td>{{$observation->reporter->name ?? ''}}</td>
                                    <td>{{$observation->responsible->name ?? ''}}</td>
                                    <td>{{$observation->stage->name ?? ''}}</td>
                                    <td>{{$observation->timeline->name ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
