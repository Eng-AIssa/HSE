<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Asset Damage Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Asset Damage') }}</li>
        <li class="breadcrumb-item active">{{ __('Asset Damage Reports') }}</li>
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100 ">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Equipment Tag</th>
                                <th>Equipment Description</th>
                                <th>Was any Person exposed</th>
                                <th>Employee Involved</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Location Details</th>
                                <th>Human Factor</th>
                                <th>Nature Factor</th>
                                <th>External Factor</th>
                                <th>Factor Led to Asset Damage</th>
                                <th>Asset Type</th>
                                <th>Direct Cost</th>
                                <th>Direct Cost Amount</th>
                                <th>Indirect Cost</th>
                                <th>Indirect Cost Amount</th>
                                <th>Total Cost</th>
                                <th>Accident Id</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($assetDamages as $assetDamage)
                                <tr>
                                    <td>{{$assetDamage->id ?? ''}}</td>
                                    <td>{{$assetDamage->equipment_tag ?? ''}}</td>
                                    <td>{{$assetDamage->equipment_description ?? ''}}</td>
                                    <td>{{($assetDamage->was_any_person_exposed == 0) ? 'No' : 'Yes'}}</td>
                                    <td>{{ is_numeric($assetDamage->employee_involved) ? $assetDamage->employeeInvolved->name : $assetDamage->employee_involved}}</td>
                                    <td>{{$assetDamage->location->name ?? ''}}</td>
                                    <td>{{$assetDamage->area->name ?? ''}}</td>
                                    <td>{{$assetDamage->location_details ?? ''}}</td>
                                    <td>{{$assetDamage->human_factor ?? ''}}</td>
                                    <td>{{$assetDamage->nature_factor ?? ''}}</td>
                                    <td>{{$assetDamage->external_factor ?? ''}}</td>
                                    <td>{{$assetDamage->factor_led_to_asset_damage ?? ''}}</td>
                                    <td>@foreach($assetDamage->asset_type ?? [] as $type) {{$type ?? ''}} @endforeach</td>
                                    <td>{{$assetDamage->direct_cost ?? ''}}</td>
                                    <td>{{$assetDamage->direct_cost_amount ?? ''}}</td>
                                    <td>{{$assetDamage->indirect_cost ?? ''}}</td>
                                    <td>{{$assetDamage->indirect_cost_amount ?? ''}}</td>
                                    <td>{{$assetDamage->total_cost ?? ''}}</td>
                                    <td>{{$assetDamage->accident_id ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
