<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Action Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Action') }}</li>
        <li class="breadcrumb-item active">{{ __('Action Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Logging Data</th>
                                <th>Logging Time</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Action Source</th>
                                <th>Item Category</th>
                                <th>Item Type</th>
                                <th>Target Date</th>
                                <th>Action Category</th>
                                <th>Risk</th>
                                <th>Priority</th>
                                <th>Description</th>
                                <th>Closure Justification</th>
                                <th>Reported By</th>
                                <th>Responsible</th>
                                <th>Approver</th>
                                <th>Stage</th>
                                <th>Timeline</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($actions as $action)
                                <tr>
                                    <td>{{$action->id ?? ''}}</td>
                                    <td>{{$action->title ?? ''}}</td>
                                    <td>{{$action->logging_date ?? ''}}</td>
                                    <td>{{$action->logging_time ?? ''}}</td>
                                    <td>{{$action->location->name ?? ''}}</td>
                                    <td>{{$action->area->name ?? ''}}</td>
                                    <td>{{$action->action_item_source ?? ''}}</td>
                                    <td>{{$action->action_item_category ?? ''}}</td>
                                    <td>{{$action->action_item_type ?? ''}}</td>
                                    <td>{{$action->target_date ?? ''}}</td>
                                    <td>{{$action->action_category ?? ''}}</td>
                                    <td>{{$action->risk ?? ''}}</td>
                                    <td>{{$action->priority ?? ''}}</td>
                                    <td>{{$action->description ?? ''}}</td>
                                    <td>{{$action->closure_justification ?? ''}}</td>
                                    <td>{{$action->reporter->name ?? ''}}</td>
                                    <td>{{$action->responsible->name ?? ''}}</td>
                                    <td>{{$action->approvedBy->name ?? ''}}</td>
                                    <td>{{$action->stage->name ?? ''}}</td>
                                    <td>{{$action->timeline->name ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
