<x-main-layout>

    @push('css')


    @endpush

    <x-slot name="pageTitle">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">HSSE</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                            <li class="breadcrumb-item active">Processing</li>
                        </ol>
                    </div>
                    <h4 class="page-title">{{ __('Processing Reports') }}</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
    </x-slot>


    <div class="container-fluid">

        <table id="inline-editable">

        </table>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h3 class="mb-4">Summary of Processing Reports</h3>

                        <div class="table-responsive">
                            <table class="table table-centered mb-0 text-center" id="btn-editable">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Date Occurred</th>
                                    <th>potential Risk</th>
                                    <th>Justification For Risk</th>
                                    <th>Location</th>
                                    <th>General Classification</th>
                                </tr>
                                </thead>

                                <tbody>
                                @foreach($accidents as $accident)
                                    <tr>
                                        <td>{{$loop->index}}</td>
                                        <td>{{$accident->title}}</td>
                                        <td>{{$accident->date_occurred}}</td>
                                        <td>{{$accident->potential_risk}}</td>
                                        <td>{{$accident->justification_for_risk}}</td>
                                        <td>{{$accident->location->name}}</td>
                                        <td>{{$accident->general_classification}}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div> <!-- end .table-responsive-->
                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container -->


    @push('scripts')

    <!-- Table Editable plugin-->
        <script src="{{asset('libs/jquery-tabledit/jquery.tabledit.min.js')}}"></script>

        <!-- Table editable init-->
        <script src="{{asset('js/pages/tabledit.init.js')}}"></script>

    @endpush
</x-main-layout>
