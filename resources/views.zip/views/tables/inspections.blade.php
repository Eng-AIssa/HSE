<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Inspection Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Inspection') }}</li>
        <li class="breadcrumb-item active">{{ __('Inspection Reports') }}</li>
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Inspection Date</th>
                                <th>Inspection Time</th>
                                <th>Logging Date</th>
                                <th>Logging Time</th>
                                <th>Target Date</th>
                                <th>Location </th>
                                <th>Area </th>
                                <th>Location Details</th>
                                <th>Activity Observed</th>
                                <th>General Remark</th>
                                <th>Is Contact Made</th>
                                <th>Has Interactive Discussion Made</th>
                                <th>Has Positive Behavior Highlighted</th>
                                <th>Has Concurrence of Improvement Taken</th>
                                <th>Contact Info Name</th>
                                <th>Contact Info Department</th>
                                <th>Reported By</th>
                                <th>Accompanied By</th>
                                <th>Notify Only</th>
                                <th>Section </th>
                                <th>Stage </th>
                                <th>Timeline </th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($inspections as $inspection)
                                <tr>
                                    <td>{{$inspection->id ?? ''}}</td>
                                    <td>{{$inspection->name ?? ''}}</td>
                                    <td>{{$inspection->type ?? ''}}</td>
                                    <td>{{$inspection->category ?? ''}}</td>
                                    <td>{{$inspection->inspection_date ?? ''}}</td>
                                    <td>{{$inspection->inspection_time ?? ''}}</td>
                                    <td>{{$inspection->logging_date ?? ''}}</td>
                                    <td>{{$inspection->logging_time ?? ''}}</td>
                                    <td>{{$inspection->target_date ?? ''}}</td>
                                    <td>{{$inspection->location->name ?? ''}}</td>
                                    <td>{{$inspection->area->name ?? ''}}</td>
                                    <td>{{$inspection->location_details ?? ''}}</td>
                                    <td>{{$inspection->activity_observed ?? ''}}</td>
                                    <td>{{$inspection->general_remark ?? ''}}</td>
                                    <td>{{($inspection->is_contact_made ?? '') == 0 ? 'No' : 'Yes'}}</td>
                                    <td>
                                        @foreach($inspection->has_interactive_discussion_made ?? [] as $key => $check)
                                            {{ ($check ?? '') == 0 ? $key . ': No' : $key . ': Yes'}}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($inspection->has_positive_behavior_highlighted ?? [] as $key => $check)
                                            {{ ($check ?? '') == 0 ? $key . ': No' : $key . ': Yes'}}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($inspection->has_concurrence_of_improvement_taken ?? [] as $key => $check)
                                            {{ ($check ?? '') == 0 ? $key . ': No' : $key . ': Yes'}}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($inspection->contact_info_name ?? [] as $key => $check)
                                            {{ $key . ': ' . ( is_numeric($check) ? ($inspection->employeeName($check) ?? '') : ($check ?? '') ) . ', '}}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($inspection->contact_info_department ?? [] as $key => $check)
                                            {{ $key . ': ' . $check ?? '' . ', '}}
                                        @endforeach
                                    </td>
                                    <td>{{$inspection->reporter->name ?? ''}}</td>
                                    <td>
                                        @foreach($inspection->accompanied_by ?? [] as $key => $member)
                                            {{ $key . ': ' . $inspection->employeeName($member) . ', '}}

                                        @endforeach</td>
                                    <td>{{$inspection->notify->name ?? ''}}</td>
                                    <td>{{$inspection->section->name ?? ''}}</td>
                                    <td>{{$inspection->stage->name ?? ''}}</td>
                                    <td>{{$inspection->timeline->name ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
