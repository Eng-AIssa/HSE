<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Fire Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Accident') }}</li>
        <li class="breadcrumb-item">{{ __('Fire') }}</li>
        <li class="breadcrumb-item active">{{ __('Fire Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Ignition Source</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Duration of Fire</th>
                                <th>In Classified Area ?</th>
                                <th>Is Process Fire ?</th>
                                <th>Any Person Exposed ?</th>
                                <th>Equipment Involved</th>
                                <th>Employee Involved</th>
                                <th>Fire Type</th>
                                <th>Resulted Loss</th>
                                <th>Action Taken</th>
                                <th>Accident ID</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($fires as $fire)
                                <tr>
                                    <td>{{$fire->id ?? ''}}</td>
                                    <td>{{$fire->ignition_sources ?? ''}}</td>
                                    <td>{{$fire->location->name ?? ''}}</td>
                                    <td>{{$fire->area->name ?? ''}}</td>
                                    <td>{{'Hours: ' . ($fire->duration_of_fire['hours'] ?? '')}}
                                        , {{' Minutes: ' . ($fire->duration_of_fire['minutes'] ?? '')}}</td>
                                    <td>{{(($fire->is_in_classified_area ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($fire->is_process_fire ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($fire->was_any_person_exposed ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{$fire->equipment_involved ?? ''}}</td>
                                    <td>{{ is_numeric($fire->employee_involved) ? $fire->employeeInvolved->name : $fire->employee_involved}}</td>
                                    <td>
                                        @foreach($fire->fire_type ?? [''] as $type)
                                            {{$type}},
                                        @endforeach
                                    </td>
                                    <td>{{$fire->resulted_loss ?? ''}}</td>
                                    <td>{{$fire->immediate_action_taken ?? ''}}</td>
                                    <td>{{$fire->accident_id ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
