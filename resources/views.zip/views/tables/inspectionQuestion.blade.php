<x-main-layout>
    @push('css')
        <livewire:styles/>
    @endpush


    <x-slot name="pageTitle">
        {{ __('Update Inspections Questions') }}
    </x-slot>

        <x-slot name="path">
            <li class="breadcrumb-item ">{{ __('Inspection') }}</li>
            <li class="breadcrumb-item active">{{ __('Manage Questions') }}</li>
        </x-slot>

    <livewire:update-inspection-question/>


    @push('scripts')

        <livewire:scripts/>
    @endpush


</x-main-layout>
