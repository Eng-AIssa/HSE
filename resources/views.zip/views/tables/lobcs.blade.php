<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('LOPC Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Accident') }}</li>
        <li class="breadcrumb-item">{{ __('LOPC') }}</li>
        <li class="breadcrumb-item active">{{ __('LOPC Reports') }}</li>
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type of Leak</th>
                                <th>Leak Quantity</th>
                                <th>Chemical Leaked</th>
                                <th>Leak Duration</th>
                                <th>Was any Person Exposed ?</th>
                                <th>Leak Resulted Into Fire ?</th>
                                <th>Leak Resulted Into Environment Issues ?</th>
                                <th>Leak Resulted Into Human Injury ?</th>
                                <th>Release Resulted Into Emergency Evacuation ?</th>
                                <th>Release Resulted In Adverse Consequences ?</th>
                                <th>Location</th>
                                <th>Area</th>
                                <th>Leak Type</th>
                                <th>Operational Mode</th>
                                <th>Equipment Involved</th>
                                <th>Employee Involved</th>
                                <th>Type of Equipment Involved</th>
                                <th>Apparent Cause</th>
                                <th>Equipment Condition</th>
                                <th>Action Taken</th>
                                <th>Accident ID</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($lobcs as $lobc)
                                <tr>
                                    <td>{{$lobc->id ?? ''}}</td>
                                    <td>{{$lobc->type_of_leak ?? ''}}</td>
                                    <td>{{$lobc->leak_quantity ?? ''}}</td>
                                    <td>{{$lobc->chemical_leaked ?? ''}}</td>
                                    {{--<td>{{$lobc->leak_duration ?? ''}}</td>--}}
                                    <td>{{'Hours: ' . ($lobc->leak_duration['hours'] ?? '')}}
                                        , {{' Minutes: ' . ($lobc->leak_duration['minutes'] ?? '')}}</td>

                                    <td>{{(($lobc->was_any_person_exposed ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($lobc->has_leak_resulted_into_fire ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($lobc->has_leak_resulted_into_environment_issues ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($lobc->has_leak_resulted_into_human_injury ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($lobc->has_release_resulted_into_emergency_evacuation ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{(($lobc->has_release_resulted_in_adverse_consequences ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{$lobc->location->name ?? ''}}</td>
                                    <td>{{$lobc->area->name ?? ''}}</td>
                                    <td>
                                        @foreach($lobc->leak_type ?? [''] as $type)
                                            {{$type,}}
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($lobc->operational_mode ?? [''] as $mode)
                                            {{$mode,}}
                                        @endforeach
                                    </td>
                                    <td>{{$lobc->equipment_involved ?? ''}}</td>
                                    <td>{{$lobc->employee_involved ?? ''}}</td>
                                    <td>{{$lobc->type_of_equipment_involved ?? ''}}</td>
                                    <td>{{$lobc->apparent_cause ?? ''}}</td>
                                    <td>{{$lobc->equipment_condition ?? ''}}</td>
                                    <td>{{$lobc->immediate_action_taken ?? ''}}</td>
                                    <td>{{$lobc->accident_id ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
