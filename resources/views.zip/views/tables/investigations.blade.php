<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('Investigation Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Investigation') }}</li>
        <li class="breadcrumb-item active">{{ __('Investigation Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Classification</th>
                                <th>Target Date</th>
                                <th>Direct Immediate Cause</th>
                                <th>Immediate Cause</th>
                                <th>Direct Contributing Factor</th>
                                <th>Contributing Factor</th>
                                <th>Direct Root Cause</th>
                                <th>Root Cause</th>
                                <th>Root Cause Analysis Tool</th>
                                <th>Communication to Authorities</th>
                                <th>Investigation Leader</th>
                                <th>Investigation Team</th>
                                <th>Sponsor</th>
                                <th>Stage</th>
                                <th>timeline</th>
                            </tr>
                            </thead>


                            <tbody>
                            @foreach($investigations as $investigation)
                                <tr>
                                    <td>{{$investigation->id ?? ''}}</td>
                                    <td>{{$investigation->type ?? ''}}</td>
                                    <td>{{$investigation->classification ?? ''}}</td>
                                    <td>{{$investigation->target_date ?? ''}}</td>
                                    <td>{{$investigation->direct_immediate_cause ?? ''}}</td>
                                    <td>{{$investigation->immediate_cause ?? ''}}</td>
                                    <td>{{$investigation->direct_contributing_factor ?? ''}}</td>
                                    <td>{{$investigation->contributing_factor ?? ''}}</td>
                                    <td>{{$investigation->direct_root_cause ?? ''}}</td>
                                    <td>{{$investigation->root_cause ?? ''}}</td>
                                    <td>{{$investigation->root_cause_analysis_tool ?? ''}}</td>
                                    <td>{{(($investigation->has_communication_done ?? '') == 1) ?  'Yes' : 'No'}}</td>
                                    <td>{{$investigation->leader->name ?? ''}}</td>
                                    <td>
                                        @foreach($investigation->investigation_team ?? ['']  as $member)
                                            {{$investigation->employeeName($member)}},
                                        @endforeach
                                    </td>
                                    <td>{{$investigation->sponsoredBy->name ?? ''}}</td>
                                    <td>{{$investigation->stage->name ?? ''}}</td>
                                    <td>{{$investigation->timeline->name ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
