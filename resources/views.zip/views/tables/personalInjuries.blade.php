<x-main-layout>

    @push('css')
        <link href="{{asset('libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
        <link href="{{asset('libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet"
              type="text/css"/>
    @endpush

    <x-slot name="pageTitle">
        {{ __('personalInjury Reports') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Accident') }}</li>
        <li class="breadcrumb-item">{{ __('personalInjury') }}</li>
        <li class="breadcrumb-item active">{{ __('personalInjury Reports') }}</li>
    </x-slot>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <table id="alternative-page-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Employee Age</th>
                                <th>Employee Department</th>
                                <th>Employee Gender</th>
                                <th>Employee Job Title</th>
                                <th>Contractor Name</th>
                                <th>Contractor Job title</th>
                                <th>Contractor Age</th>
                                <th>Contractor Department</th>
                                <th>Contractor Company</th>
                                <th>Type of Injury</th>
                                <th>Injury Description</th>
                                <th>Injury Category</th>
                                <th>Injury Type</th>
                                <th>Illness Type</th>
                                <th>Harmed Body Parts</th>
                                <th>Reason of Injury or Illness</th>
                                <th>treatment Date</th>
                                <th>Diagnosis Date</th>
                                <th>Return to Work Date</th>
                                <th>Numbers of Days Away From Work</th>
                                <th>Is Job Transfer</th>
                                <th>Restriction Post Injury</th>
                                <th>Number of Light Duty Days</th>
                                <th>Doctor Remark</th>
                                <th>Accident ID</th>

                            </tr>
                            </thead>


                            <tbody>
                            @foreach($personalInjuries as $personalInjury)
                                <tr>
                                    <td>{{$personalInjury->id ?? ''}}</td>
                                    <td>{{$personalInjury->employee_id ?? ''}}</td>
                                    <td>{{$personalInjury->employee_name ?? ''}}</td>
                                    <td>{{$personalInjury->employee_age ?? ''}}</td>
                                    <td>{{$personalInjury->employee_department ?? ''}} </td>
                                    <td>{{$personalInjury->employee_gender ?? ''}}</td>
                                    <td>{{$personalInjury->employee_job_title ?? ''}}</td>
                                    <td>{{$personalInjury->contractor_name ?? ''}}</td>
                                    <td>{{$personalInjury->contractor_job_title ?? ''}}</td>
                                    <td>{{$personalInjury->contractor_age ?? ''}}</td>
                                    <td>{{$personalInjury->contractor_department ?? ''}}</td>
                                    <td>{{$personalInjury->contractor_company ?? ''}}</td>
                                    <td>{{$personalInjury->type_of_injury ?? ''}}</td>
                                    <td>{{$personalInjury->injury_description ?? ''}}</td>
                                    <td>{{$personalInjury->injury_category ?? ''}}</td>
                                    <td>
                                        @foreach($personalInjury->injury_type ?? [] as $type)
                                            {{$type}},
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($personalInjury->illness_type ?? [] as $type)
                                            {{$type}},
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($personalInjury->harmed_body_parts ?? [] as $part)
                                            {{$part}},
                                        @endforeach
                                    </td>
                                    <td>
                                        @foreach($personalInjury->reason_of_injury_or_illness ?? [] as $reason)
                                            {{$reason}},
                                        @endforeach
                                    </td>
                                    <td>{{$personalInjury->treatment_date ?? ''}}</td>
                                    <td>{{$personalInjury->diagnosis_date ?? ''}}</td>
                                    <td>{{$personalInjury->return_to_work_date ?? ''}}</td>
                                    <td>{{$personalInjury->numbers_of_days_away_from_work ?? ''}}</td>
                                    <td>{{($personalInjury->is_job_transfer ?? '') ? 'Yes' : 'No'}}</td>
                                    <td>{{$personalInjury->restriction_post_injury ?? ''}}</td>
                                    <td>{{$personalInjury->number_of_light_duty_days ?? ''}}</td>
                                    <td>{{$personalInjury->doctor_remark ?? ''}}</td>
                                    <td>{{$personalInjury->accident_id ?? ''}}</td>

                                </tr>
                            @endforeach

                            </tbody>
                        </table>

                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->


        @push('scripts')


            <script src="{{asset('js/pages/datatables.init.js')}}"></script>

            {{--Jquery to handle ordering, rows number, search and pagination operations--}}
            <script src="{{asset('libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
            {{--all buttons pagination, seacrch, # of rows list ..etc--}}
            <script src="{{asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
            {{--handle styling and alignment--}}
            <script src="{{asset('libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
            {{--responsiveness--}}
            <script src="{{asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>


    @endpush
</x-main-layout>
