<x-main-layout>

    <x-slot name="pageTitle">
        {{ __('Raised Reports') }}
    </x-slot>


    <div class="container-fluid">

        <table id="inline-editable"></table>


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h3 class="mb-4">Summary of Raised Reports</h3>

                        <div class="table-responsive">
                            <table class="table table-centered mb-0 text-center" id="btn-editable">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Date Occurred</th>
                                    <th>potential Risk</th>
                                    <th>Justification For Risk</th>
                                    <th>Location</th>
                                    <th>General Classification</th>
                                    <th>Full Data</th>
                                    <th>Edit</th>
                                </tr>
                                </thead>

                                <tbody>
                                @foreach($accidents as $accident)
                                    <tr>
                                        <td>{{$loop->index}}</td>
                                        <td>{{$accident->title}}</td>
                                        <td>{{$accident->date_occurred}}</td>
                                        <td>{{$accident->potential_risk}}</td>
                                        <td>{{$accident->justification_for_risk}}</td>
                                        <td>{{$accident->location->name}}</td>
                                        <td>{{$accident->general_classification}}</td>
                                        <td>
                                            <button id="edit-button" type="button" class="btn  btn-lg"
                                                    data-toggle="modal"
                                                    data-target="#edit-model"><i class="fas fa-desktop"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div> <!-- end .table-responsive-->
                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div> <!-- container -->


    <!-- Edit modal -->
    <div class="modal fade" id="edit-model" tabindex="-1" role="dialog" aria-labelledby="edit-model-label"
         aria-hidden="true">
        <!-- Start modal-dialog -->
        <div class="modal-dialog modal-md">
            <!-- Start modal-content -->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="edit-model-label">Edit Model</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group ">
                        <form id="edit-form" action="" method="POST">
                            @csrf
                            @method('PUT')
                           {{-- <x-form.select-input disable="disabled" label="{{ __('Incident Type') }}">
                                <option>{{ __('Select') }}</option>
                                <option selected value="">{{ __('Nearmiss') }}</option>
                                <option value="">{{ __('Accident') }}</option>
                            </x-form.select-input>

                            <x-form.select-input disable="disabled" label="{{ __('Incident Group') }}">
                                <option>{{ __('Select') }}</option>
                                <option selected value="">{{ __('Injury') }}</option>
                                <option value="">{{ __('Health') }}</option>
                                <option value="">{{ __('Operation') }}</option>
                                <option value="">{{ __('Environment') }}</option>
                            </x-form.select-input>

                            <x-form.select-input disable="disabled" label="{{ __('Location') }}">
                                <option>{{ __('Select') }}</option>
                                <option selected value="">{{ __('Location A') }}</option>
                                <option value="">{{ __('Location B') }}</option>
                                <option value="">{{ __('Location C') }}</option>
                                <option value="">{{ __('Location D') }}</option>
                            </x-form.select-input>

                            <div class="d-flex flex-row ">
                                <x-form.date-input label="{{ __('Date Occurred') }}"/>
                                <x-form.time-input label="{{ __('Time Occurred') }}" class="ml-2"/>
                            </div>

                            <div class="d-flex flex-row ">
                                <x-form.date-input label="{{ __('Logging Date') }}"/>
                                <x-form.time-input label="{{ __('Logging Time') }}" class="ml-2"/>
                            </div>

                            <x-form.text-input label="{{ __('Title') }}" mb="3"/>

                            <div class="d-flex flex-row justify-content-around ">
                                <x-form.select-input disable="disabled" label="{{ __('Potential Severity') }}" class="ml-1">
                                    <option>{{ __('Select') }}</option>
                                    <option selected value="">{{ __('C1') }}</option>
                                    <option value="">{{ __('C2') }}</option>
                                    <option value="">{{ __('C3') }}</option>
                                </x-form.select-input>
                                <x-form.select-input disable="disabled" label="{{__('Frequency')}}" class="ml-1">
                                    <option>{{ __('Select') }}</option>
                                    <option selected value="">{{ __('F1') }}</option>
                                    <option value="">{{ __('F2') }}</option>
                                    <option value="">{{ __('F3') }}</option>
                                </x-form.select-input>
                                <x-form.select-input disable="disabled" label="{{ __('Potential Risk') }}" class="ml-1">
                                    <option>{{ __('Select') }}</option>
                                    <option selected value="">{{ __('R1') }}</option>
                                    <option value="">{{ __('R2') }}</option>
                                    <option value="">{{ __('R3') }}</option>

                                </x-form.select-input>
                            </div>

                            <x-form.text-input label="{{ __('Justification For Risk') }}" mb="4"/>


                            <x-form.select-input label="{{ __('General Classification') }}"
                                                 style="margin-bottom: 5px!important;" class="ml-1">
                                <option>{{ __('Select') }}</option>
                                <option selected value="">{{ __('System Involved') }}</optionselected>
                                <option value="">{{ __('Equipment Involved') }}</option>
                                <option value="">{{ __('Substance Chemical Involved') }}</option>
                            </x-form.select-input>

                            <input type="text" class="control mb-3 mt-0 ml-1"
                                   placeholder="{{ __('Write Classification') }}">


                            <div class="d-flex flex-row justify-content-start ">
                                <x-form.select-input label="{{ __('Incident Related To') }}" class="ml-1">
                                    <option selected>{{ __('Select') }}</option>
                                    --}}{{--<option value="">{{ __('On The Jop') }}</option>
                                    <option value="">{{ __('Off The Jop') }}</option>--}}{{--
                                </x-form.select-input>
                                <div class="mt-3 ml-3">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input">
                                        <label class="custom-control-label" for="">{{ __('Communication has done to
                                                authorities') }}</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input">
                                        <label class="custom-control-label"
                                               for="">{{ __('Is Repeated Incident') }}</label>
                                    </div>
                                </div>
                            </div>

                            <x-form.text-input label="{{ __('Reported By') }}" placeholder="{{ __('Name') }}"
                                               mb="0"/>
                            <x-form.text-input label="" placeholder="{{ __('Department') }}" mb="3"/>

                            <x-form.text-input label="{{ __('Responsible Person') }}" placeholder="{{ __('Name') }}"
                                               mb="0"/>
                            <x-form.text-input label="" placeholder="{{ __('Department') }}" mb="4"/>

                            <x-form.textarea-input label="{{ __('Incident Description') }}"/>

                            <x-form.textarea-input label="{{ __('Immediate Action Taken') }}" rows="2"/>

                            <x-form.select-input label="{{ __('Type Of Activity At Time Of Incident') }}">
                                <option>{{ __('Select') }}</option>
                                <option selected value="">{{ __('Normal Operation') }}</option>
                                <option value="">{{ __('Chemical Handling') }}</option>
                                <option value="">{{ __('Cleaning') }}</option>
                                <option value="">{{ __('Commissioning') }}</option>
                            </x-form.select-input>--}}
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

@push('scripts')

    <!-- Table Editable plugin-->
        <script src="{{asset('libs/jquery-tabledit/jquery.tabledit.min.js')}}"></script>

        <!-- Table editable init-->
        <script src="{{asset('js/pages/tabledit.init.js')}}"></script>

    @endpush
</x-main-layout>
