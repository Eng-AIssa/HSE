<x-main-layout>

    @push('css')
    <!-- Loading button css -->
        <link href="{{asset('libs/ladda/ladda-themeless.min.css')}}" rel="stylesheet" type="text/css"/>

        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Profile') }}
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8">

                <livewire:update-profile-form :user="$user"/>
                <livewire:update-password-form :user="$user"/>

            </div>
        </div>
    </div>


    @push('scripts')
    <!-- Loading buttons js -->
        <script src="{{asset('libs/ladda/spin.min.js')}}"></script>
        <script src="{{asset('libs/ladda/ladda.min.js')}}"></script>

        <!-- Buttons init js-->
        <script src="{{asset('js/pages/loading-btn.init.js')}}"></script>


        @livewireScripts
    @endpush
</x-main-layout>
