<div class="row justify-content-center">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
        <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Incident') }} # {{$incident['id'] ?? ''}} </h3>
    </div>
    <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
         style="display: flex;">
        <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-2 ml-2 ml-sm-0">
            <h3 class="">{{ __('Status:') }}</h3>
            <p class=" ml-2 font-20" style="padding-top: 0.6rem;">{{ __('Initiation') }}</p>
        </div>
    </div>


    <form wire:submit.prevent="store" id="incident-form" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form"
          action="{{route('accident.store')}}" method="POST">
        @csrf


        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <h5 class="bg-light p-2 mt-0 mb-4">{{ __('Workflow Overview') }}</h5>

        <div class="row track-order-list">
            <ul class="list-unstyled col-12 d-flex flex-wrap flex-xl-nowrap justify-content-center">
                <li class="{{--completed--}}current pt-2">
                    <span class="active-dot dot"></span>
                    <i style="color: green;" class="fas fa-location-arrow"></i>
                    <h5 class="mt-0 mb-1 mr-3">Initiation</h5>
                    <p class="text-muted text-center"><br><small class="text-muted"></small>
                    </p>
                </li>
                <li class="">
                    {{--<span class="active-dot dot"></span>--}}
                    <i class="fas fa-location-arrow"></i>
                    <h5 class="mt-0 mb-1 ">HSE</h5>
                    <p class="text-muted ">review & process what's required <br><small
                            class="text-muted"></small>
                    </p>
                </li>
                <li>
                    <i class="fas fa-location-arrow"></i>
                    <h5 class="mt-0 mb-1 ">Responsible</h5>
                    <p class="text-muted "> Review, Accept & process<br> <small
                            class="text-muted"></small>
                    </p>
                </li>
                <li>
                    <i class="fas fa-location-arrow"></i>
                    <h5 class="mt-0 mb-1 "> HSE </h5>
                    <p class="text-muted ">last step review</p>
                </li>
                <li class="">
                    <i class="fas fa-location-arrow"></i>
                    <h5 class="mt-0 mb-1 "> Closed</h5>
                    <p class="text-muted">last step review</p>
                </li>
                <li class="end-point p-0">
                </li>
            </ul>
        </div>


        <h5 class="bg-light p-2 mt-0 mb-3">{{ __('Category & Title') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model="incident.incident_type"
                                     wire:key="incident-type"
                                     label="{{ __('Incident Type') }}"
                                     id="incident_type" name="incident_type"
                                     required='required'>
                    @foreach($datalist->where('name','Incident Type')->first()->content as $item)
                        <option id="{{$item}}" value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="incident.incident_group"
                                     label="{{ __('Incident Group') }}"
                                     name="incident_group"
                                     required='required'>
                    @foreach($datalist->where('name','Incident Group')->first()->content as $item)
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12">
                <x-form.text-input wire:model.defer="incident.title"
                                   label="{{ __('Title') }}"
                                   id="title" name="title"
                                   required='required' mb="3"/>
            </div>
        </div>


        <h5 class="bg-light p-2 mt-0 mb-3">{{ __('Time & Location') }}</h5>

        <div class="row " wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="incident.incident_date"
                                   label="{{ __('Incident Date') }}"
                                   name="incident_date" max="{{date('Y-m-d')}}"
                                   required='required'/>

            </div>

            <div class="col-12 col-md-6">
                <x-form.time-input wire:model.defer="incident.incident_time"
                                   label="{{ __('Incident Time') }}"
                                   name="incident_time"
                                   required='required'/>
            </div>
        </div>


        <div class="row " wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="incident.logging_date"
                                   label="{{ __('Logging Date') }}"
                                   name="logging_date" max="{{date('Y-m-d')}}"
                                   required='required'/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.time-input wire:model.defer="incident.logging_time"
                                   label="{{ __('Logging Time') }}"
                                   name="logging_time"
                                   required='required'/>
            </div>
        </div>


        <div class="row">
            <div class="col-12 col-md-6 col-xl-4" wire:ignore>
                <x-form.select-input wire:model="incident.location_id"
                                     wire:key="incident-location-id"
                                     label="{{ __('Location') }}"
                                     name="location_id"
                                     required='required'>
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6 col-xl-4">
                <x-form.select-input wire:model.defer="incident.area_id" wire:ignore.self
                                     label="{{ __('Area') }}"
                                     name="area_id"
                                     required='required'>
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6 col-xl-4" wire:ignore>
                <x-form.text-input wire:model.defer="incident.location_details"
                                   label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details"/>
            </div>
        </div>


        <h5 class="bg-light p-2 mt-0 mb-3">{{ __('Incident Data') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12">
                <x-form.textarea-input wire:model.defer="incident.incident_description"
                                       label="{{ __('Incident Description') }}"
                                       name="incident_description" rows="3"
                                       required='required'/>
            </div>
            <div class="col-12">
                <x-form.textarea-input wire:model.defer="incident.immediate_action_taken"
                                       label="{{ __('Immediate Action Taken') }}"
                                       name="immediate_action_taken"
                                       required='required' rows="2"/>
            </div>
        </div>

        <div class="row mt-4 mb-2" wire:ignore>
            <div class="col-6">
                <x-form.select-input wire:model.defer="incident.incident_related_to"
                                     label="{{ __('Incident Related to') }}"
                                     name="incident_related_to" class="ml-1"
                                     required='required'>
                    @foreach($datalist->where('name','Incident Related To')->first()->content as $item)
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-6 mt-3">
                <div class="checkbox checkbox-primary mt-2 ">
                    <x-form.checkbox wire:model.defer="incident.is_repeated"
                                     label="{{ __('Repeated Incident') }}"
                                     id="is-repeated" name="is_repeated"
                                     value="1"/>
                </div>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12 hide" id="type-of-activity">
                <x-form.select-input wire:model.defer="incident.activity_at_time_of_incident"
                                     label="{{ __('Type of Activity at Time of Incident') }}"
                                     name="activity_at_time_of_incident">
                    @foreach($datalist->where('name','Type Of Activity At Time Of Incident')->first()->content as $item)
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <h5 wire:ignore class="bg-light p-2 mt-0 mb-3 accident-consequences hide">{{ __('Actual loss') }}</h5>

        <div class="pl-2 mb-4 accident-consequences hide" wire:ignore>

            <div class="row " wire:ignore>
                <div class="col-12 col-sm-6 col-md-4">
                    <x-form.checkbox wire:model.defer="incident.actual_loss.1"
                                     label="{{'Personal Injury'}}" id="personal-checkbox" name="actual_loss[]"
                                     value="PersonalInjury"/>

                    <x-form.checkbox wire:model.defer="incident.actual_loss.2"
                                     label="{{ __('Spill') }}" id="spill-checkbox" name="actual_loss[]" value="Spill"/>

                    <x-form.checkbox wire:model.defer="incident.actual_loss.3"
                                     label="{{ __('Safety') }}" id="safety-checkbox" name="actual_loss[]"
                                     value="Safety"/>
                </div>

                <div class="col-12 col-sm-6 col-md-4col-12 col-sm-6 col-md-4">
                    <x-form.checkbox wire:model.defer="incident.actual_loss.4"
                                     label="{{ __('Asset Damage') }}" id="asset-checkbox" name="actual_loss[]"
                                     value="AssetDamage"/>

                    <x-form.checkbox wire:model.defer="incident.actual_loss.5"
                                     label="{{ __('Gas Leak') }}" id="gas-checkbox" name="actual_loss[]"
                                     value="GasLeak"/>

                    <x-form.checkbox wire:model.defer="incident.actual_loss.6"
                                     label="{{ __('Transport Safety') }}" id="transport-checkbox" name="actual_loss[]"
                                     value="TransportSafety"/>
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                    <x-form.checkbox wire:model.defer="incident.actual_loss.7"
                                     label="{{ __('Environment') }}" id="environment-checkbox" name="actual_loss[]"
                                     value="Environment"/>

                    <x-form.checkbox wire:model.defer="incident.actual_loss.8"
                                     label="{{ __('Fire/Explosion') }}" id="fire-checkbox" name="actual_loss[]"
                                     value="Fire"/>
                </div>
            </div>
        </div>


        <h5 wire:ignore class="bg-light p-2 mt-0 mb-3 assessment-show hide">{{ __('Loss Potential') }}</h5>

        <div class="pl-2 my-4 assessment-show hide" wire:ignore>
            <div class="row " wire:ignore>
                <div class="col-4">
                    <x-form.checkbox wire:model.defer="incident.people_checkbox"
                                     label="{{ __('People') }}" id="people" value="1"/>
                </div>

                <div class="col-4">
                    <x-form.checkbox wire:model.defer="incident.environment_checkbox"
                                     label="{{ __('Environment') }}" id="environment" value="1"/>
                </div>

                <div class=" col-4 col-md ">
                    <x-form.checkbox wire:model.defer="incident.asset_damage_checkbox"
                                     label="{{ __('Asset and Production Loss') }}" id="cost" value="1"/>
                </div>
            </div>
        </div>


        <div class="row my-3 border rounded hide" id="assessment" wire:ignore>
            <x-form.loss name="{{ __('People') }}" matrix-id="people-matrix" id="people-evaluation"
                         :datalist="$datalist" style="display: none;">
                @foreach($datalist->where('name','Potential Severity People')->first()->content as $item)
                    <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                @endforeach
            </x-form.loss>

            <x-form.loss name="{{ __('Environment') }}" matrix-id="environment-matrix"
                         id="environment-evaluation" :datalist="$datalist" style="display: none;">
                @foreach($datalist->where('name','Potential Severity Environment')->first()->content as $item)
                    <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                @endforeach
            </x-form.loss>

            <x-form.loss name="{{ __('Asset and Production Loss') }}" matrix-id="cost-matrix" id="cost-evaluation"
                         :datalist="$datalist" style="display: none;">
                @foreach($datalist->where('name','Potential Severity Cost')->first()->content as $item)
                    <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                @endforeach
            </x-form.loss>

            <div class="col-12">
                <div class="row" style="margin-left: 0.5rem;">
                    <x-form.matrix id="people-matrix" name="{{ __('People') }}"/>
                    <x-form.matrix id="environment-matrix" name="{{ __('Environment') }}"/>
                    <x-form.matrix id="cost-matrix" name="{{ __('Asset and Production Loss') }}"/>
                </div>
            </div>
        </div>


        <h5 class="bg-light p-2 mt-0 mb-3">{{ __('Related People') }}</h5>

        <div class="row " wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.text-input required='required' label="{{ __('Reported By') }}"
                                   disabled="disabled"
                                   placeholder="{{ __('Name') }}" mb="0"
                                   value="{{Auth::user()->name}}" users="users"/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-"
                                   placeholder="{{ __('Department') }}" mb="3"
                                   disabled="disabled"
                                   value="{{Auth::user()->department}}"/>
            </div>
        </div>


        <div class="row " wire:ignore>
            <div class="col-12 col-sm-6 ">
                <x-form.select-input wire:model.defer="incident.responsible_person"
                                     id="anyId" required='required'
                                     label="{{ __('Responsible Person') }}"
                                     placeholder="{{ __('Name') }}" name="responsible_person"
                                     users='users' class="js-select">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-"
                                   placeholder="{{ __('Department') }}" mb="3"
                                   disabled="disabled"/>
            </div>
        </div>
    </form>


    <div wire:key="attachmentSection" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} " wire:ignore>

        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Attachments & Documents') }}</h5>


        <x-form.file-input/>


        <div class="row justify-content-end ">
            <x-form.button form="incident-form" id="my-secret-btn" label="{{ __('Submit') }}" class="m-1"/>
        </div>
    </div>


    @push('scripts')


        <script>

            window.onbeforeunload = function () {

                let id = @this.incident.id;

                //only call leaving dialog & function if the form is created
                if (id) {
                @this.leavePage();
                    return "";
                }
            }


            $('#incident-form').on('submit', function () {
                $("html, body").animate({scrollTop: 0}, 800);
            })


            //initialize users select input as select2 elements to enable search
            // and send chosen value to backend on change
            $(document).ready(function () {
                let select = $('.js-select');
                select.select2({
                    placeholder: "Select",
                });

                select.on('change', function (e) {
                @this.set('incident.' + e.target.name, e.target.value);
                });
            });
        </script>



        <script>
            document.addEventListener('DOMContentLoaded', function () {


                Livewire.on('uploadAttachments', () => {
                    $('#upload').click();
                })


                Livewire.on('hide_alert', () => {
                    $(function () {
                        setTimeout(function () {
                            $(".alert").hide()
                        }, 5000);
                    });
                })


                Livewire.on('resetJsFields', () => {
                    let people_evaluation = $('#people-evaluation');
                    let environment_evaluation = $('#environment-evaluation');
                    let asset_evaluation = $('#cost-evaluation');
                    $('select, input, textarea').each(function () {
                        $(this).css("background-color", "#fff");
                    });

                    $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');

                    $("label,h5, h3, h2, .page-title-box li").each(function () {
                        let text = $(this).text();
                        text = text.replace("Nearmiss", "Incident");
                        text = text.replace("Accident", "Incident");
                        $(this).text(text);
                    });

                    $('.hijri').html('');
                    $('#type-of-activity').hide();
                    $('.accident-consequences').hide();

                    people_evaluation.hide()
                    people_evaluation.find('.red-star').html('');
                    $('#people-matrix').hide()
                    $('.people-potential-loss').attr('disabled', true);

                    environment_evaluation.hide()
                    environment_evaluation.find('.red-star').html('');
                    $('#environment-matrix').hide()
                    $('.environment-potential-loss').attr('disabled', true);

                    asset_evaluation.hide()
                    asset_evaluation.find('.red-star').html('');
                    $('#cost-matrix').hide()
                    $('.asset-potential-loss').attr('disabled', true);

                    $('#assessment').hide();
                    $('.assessment-show').hide();

                    $('#file-previews .card').remove();


                    //timeout was set to prevent action from removing notification alert, so it's set to be done after
                    $(function () {
                        setTimeout(function () {
                            $('.js-select').val(null).trigger('change');
                        }, 6000);
                    });


                });

            })
        </script>


        <script>
            //auto choose Risk based on consequences/frequency change
            $('.matrix-options').on('change', function () {

                let consequence = $(this).parents('.loss-category').find('.potential-severity');
                let frequency = $(this).parents('.loss-category').find('.frequency-of-occurrence');
                let risk = $(this).parents('.loss-category').find('.risk');
                let matrix = $(this).parents('.loss-category').find('#matrix-id').val();


                frequency.prop('disabled', false);
                $('#' + matrix + ' span').html('-');
                let result = consequence.val() + frequency.val();

                Jump(result);

                function Jump(result) {
                    switch (result) {
                        case 'C5F3':
                            $('#' + matrix + ' .C5F3').html(22);
                            Jump('finish HH');
                            break;
                        case 'C5F4':
                            $('#' + matrix + ' .C5F4').html(24);
                            Jump('finish HH');
                            break;
                        case 'C5F5':
                            $('#' + matrix + ' .C5F5').html(25);
                            Jump('finish HH');
                            break;
                        case 'C4F4':
                            $('#' + matrix + ' .C4F4').html(21);
                            Jump('finish HH');
                            break;
                        case 'C4F5':
                            $('#' + matrix + ' .C4F5').html(23);
                            Jump('finish HH');
                            break;
                        case 'C3F5':
                            $('#' + matrix + ' .C3F5').html(20);
                            Jump('finish HH');
                            break;
                        case 'finish HH':
                            risk.val('High High');
                            risk.css('background-color', '#fb7363');
                            risk.css('color', 'white');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C5F2':
                            $('#' + matrix + ' .C5F2').html(19);
                            Jump('finish H');
                            break;
                        case 'C4F2':
                            $('#' + matrix + ' .C4F2').html(14);
                            Jump('finish H');
                            break;
                        case 'C4F3':
                            $('#' + matrix + ' .C4F3').html(18);
                            Jump('finish H');
                            break;
                        case 'C3F4':
                            $('#' + matrix + ' .C3F4').html(17);
                            Jump('finish H');
                            break;
                        case 'C2F5':
                            $('#' + matrix + ' .C2F5').html(16);
                            Jump('finish H');
                            break;

                        case 'finish H':
                            risk.val('High');
                            risk.css('background-color', '#ec8631');
                            risk.css('color', 'white');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C5F1':
                            $('#' + matrix + ' .C5F1').html(15);
                            Jump('finish m');
                            break;
                        case 'C4F1':
                            $('#' + matrix + ' .C4F1').html(10);
                            Jump('finish m');
                            break;
                        case 'C3F2':
                            $('#' + matrix + ' .C3F2').html(9);
                            Jump('finish m');
                            break;
                        case 'C3F3':
                            $('#' + matrix + ' .C3F3').html(13);
                            Jump('finish m');
                            break;
                        case 'C2F3':
                            $('#' + matrix + ' .C2F3').html(8);
                            Jump('finish m');
                            break;
                        case 'C2F4':
                            $('#' + matrix + ' .C2F4').html(12);
                            Jump('finish m');
                            break;
                        case 'C1F5':
                            $('#' + matrix + ' .C1F5').html(11);
                            Jump('finish m');
                            break;

                        case 'finish m':
                            risk.val('Medium');
                            risk.css('background-color', '#f1f27c');
                            risk.css('color', 'black');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C3F1':
                            $('#' + matrix + ' .C3F1').html(6);
                            Jump('finish l');
                            break;
                        case 'C2F1':
                            $('#' + matrix + ' .C2F1').html(3);
                            Jump('finish l');
                            break;
                        case 'C2F2':
                            $('#' + matrix + ' .C2F2').html(5);
                            Jump('finish l');
                            break;
                        case 'C1F1':
                            $('#' + matrix + ' .C1F1').html(1);
                            Jump('finish l');
                            break;
                        case 'C1F2':
                            $('#' + matrix + ' .C1F2').html(2);
                            Jump('finish l');
                            break;
                        case 'C1F3':
                            $('#' + matrix + ' .C1F3').html(4);
                            Jump('finish l');
                            break;
                        case 'C1F4':
                            $('#' + matrix + ' .C1F4').html(7);
                            Jump('finish l');
                            break;

                        case 'finish l':
                            risk.val('Low');
                            risk.css('background-color', '#aadbee');
                            risk.css('color', 'black');
                            $('#' + matrix).fadeIn(1000);
                            break;
                    }
                }

            @this.set('incident.' + $(this).attr('id').split('-')[0] + '.potential_risk', risk.val());
            });
        </script>


    @endpush

</div>
