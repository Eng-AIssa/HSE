<div class="container-fluid">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    @if(session('successMessage'))
        <div
            class="alert alert-warning alert-dismissible fade show "
            style="position: fixed; top: 80px; right: 10px; z-index: 1; padding: .35rem 3.9rem .35rem 1.2rem;"
            role="alert">
            <i class="mdi mdi-alert-circle-check-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500;">{{session('successMessage')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">

                    <div class=" col-lg-3">
                        <form class="form-inline">
                            <div class="form-group mx-sm-3">
                                <label for="inspection-table"
                                       class="mr-2 text-dark font-weight-bold">{{ __('Inspection') }}</label>
                                <select wire:model="inspection.table" class="custom-select" id="inspection-table">
                                    <option selected="">All</option>
                                    @foreach($tables as $table)
                                        <option value="{{$table}}">{{$table}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </form>
                    </div>

                    @if($inspection['table']  == 'WTA')
                        <div class="col-lg-3">
                            <form class="form-inline">
                                <div class="form-group  ">
                                    <label for="inspection-section"
                                           class="mr-2 text-dark font-weight-bold">{{ __('Section') }}</label>
                                    <select wire:model="inspection.section"
                                            style="max-width: 30%"
                                            class=" custom-select" id="inspection-section">
                                        <option selected="">All</option>
                                        @foreach($sections as $section)
                                            <option value="{{$section->id}}">{{$section->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </form>
                        </div>
                    @endif


                    <div class="{{ ($inspection['table'] == 'WTA') ? 'col-lg-4' : 'col-lg-7' }}">
                        <form class="form-inline {{ ($inspection['table'] == 'WTA') ? 'justify-content-center' : '' }}">
                            <label for="search" class="mr-2 text-dark font-weight-bold">{{ __('Search') }}</label>
                            <input class="form-control gccShadow" wire:model="search" id="search">

                        </form>
                    </div>


                    <div class="col-lg-2">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <a data-toggle="modal" data-target="#add-new-questions-modal"
                               class="text-white btn btn-danger waves-effect waves-light">
                                <i class="mdi mdi-plus-circle mr-1"></i>
                                {{ __('Add New') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card-box">

                <div class="d-flex justify-content-between">
                    <h3>{{ __('Inspection Questions') }}</h3>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped mb-0 text-center">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>{{ __('Question') }}</th>
                            <th>{{ __('Answers') }}</th>
                            <th>{{ __('Section') }}</th>
                            <th>{{ __('Edit') }}</th>
                            <th>{{ __('Delete') }}</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($Questions as $question)
                            <tr id="question-row-{{$loop->index}}" wire:key="row-{{$loop->index}}">
                                <th class="index" scope="row">{{$question['id']}}</th>

                                <td class="item" id="question-field">{{$question['question']}}</td>

                                <td class="item" id="answers-field">
                                    @foreach($question['answers'] as $answer)
                                        <span>{{$answer}}</span>
                                        @if(!$loop->last)
                                            ,
                                        @endif
                                    @endforeach</td>

                                <td class="item" id="section-field">{{ $question['section']['name'] ?? ''}}</td>

                                <td class="text-center">
                                    <button wire:key="edit-btn-{{$loop->index}}"
                                            wire:click="$emit('set_update_model_fields','{{$loop->index}}')"
                                            id="edit-button"
                                            type="button"
                                            class="btn btn-lg update-button"
                                            data-toggle="modal"
                                            data-target="#update-question-model-{{$loop->index}}">
                                        <i class=" far fa-edit"></i>
                                    </button>


                                    <!-- Update modal -->
                                    <div wire:ignore.self wire:key="update-question-model-{{$loop->index}}"
                                         class="modal fade" id="update-question-model-{{$loop->index}}"
                                         tabindex="-1" role="dialog" aria-labelledby="update-question-model-label"
                                         aria-hidden="true">
                                        <div class="modal-dialog modal-md modal-dialog-centered">
                                            <div class="modal-content">

                                                <div class="modal-header bg-light">
                                                    <h4 class="modal-title"
                                                        id="update-question-model-label">{{ __('Update Question') }}</h4>
                                                    <button wire:key="updateModelClose-{{$loop->index}}" type="button"
                                                            class="close" data-dismiss="modal" aria-hidden="true">×
                                                    </button>
                                                </div>

                                                <div class="modal-body p-3 text-left">
                                                    <form wire:key="updateModelForm-{{$loop->index}}"
                                                          wire:submit.prevent="updateQuestion({{$question['id']}}, '{{ isset($question['section']) ? 'WTA' : 'PTW'}}', {{$loop->index}})"
                                                          id="update-question-form-{{$loop->index}}" action=""
                                                          method="POST">
                                                        @csrf
                                                        @method('PUT')

                                                        <x-form.text-input wire:model.defer="inspection.question_update"
                                                                           wire:key="updateModelQuestion-{{$loop->index}}"
                                                                           label="{{ __('Question') }}"
                                                                           id="update-question-field"
                                                                           required="required"/>

                                                        <x-form.select-input wire:model="inspection.table_update"
                                                                             wire:key="updateModelTable-{{$loop->index}}"
                                                                             label="{{ __('Belong To') }}"
                                                                             id="update-table-field"
                                                                             required="required">
                                                            @foreach($tables as $table)
                                                                <option value="{{$table}}">{{$table}}</option>
                                                            @endforeach
                                                        </x-form.select-input>

                                                        @if(($inspection['table_update'] ?? '') == 'WTA')
                                                            <x-form.select-input
                                                                wire:model.defer="inspection.section_update"
                                                                wire:key="updateModelSection-{{$loop->index}}"
                                                                label="{{ __('Section') }}"
                                                                id="update-section-field" required="required">
                                                                @foreach($sections as $section)
                                                                    <option
                                                                        value="{{$section->name}}">{{$section->name}}</option>
                                                                @endforeach
                                                            </x-form.select-input>
                                                        @endif


                                                    </form>
                                                </div>

                                                <div class="modal-footer pt-0">
                                                    <x-form.button wire:key="updateModelCancel-{{$loop->index}}"
                                                                   type="button" label="{{ __('Cancel') }}"
                                                                   data-dismiss="modal" class="btn btn-light"/>
                                                    <x-form.button wire:key="updateModelSubmit-{{$loop->index}}"
                                                                   label="{{ __('Update') }}"
                                                                   form="update-question-form-{{$loop->index}}"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td class="text-center">
                                    <button wire:key="delete-btn-{{$loop->index}}"
                                            id="delete-button"
                                            type="button"
                                            class="btn  btn-lg"
                                            data-toggle="modal"
                                            data-target="#delete-question-modal-{{$loop->index}}"><i
                                            class="far fa-trash-alt"></i>
                                    </button>


                                    <!-- Delete Questions Modal -->
                                    <div wire:ignore.self wire:key="delete-question-modal-{{$loop->index}}"
                                         class="modal fade" id="delete-question-modal-{{$loop->index}}"
                                         tabindex="-1" role="dialog" aria-labelledby="delete-question-modal-label"
                                         aria-hidden="true">
                                        <div class="modal-dialog modal-sm modal-dialog-centered">
                                            <div class="modal-content">

                                                <div class="modal-header bg-light">
                                                    <h4 class="modal-title"
                                                        id="delete-question-modal-label">{{ __('Delete Question') }}</h4>
                                                    <button wire:key="deleteModelClose-{{$loop->index}}"
                                                            type="button" class="close" data-dismiss="modal"
                                                            aria-hidden="true">×
                                                    </button>
                                                </div>

                                                <div class="modal-body p-3">
                                                    <div class="form-group">
                                                        <p><strong> {{ __('Ary you Sure you want to delete this
                                                            question?') }} </strong></p>
                                                    </div>
                                                </div>

                                                <div class="modal-footer pt-0">
                                                    <x-form.button wire:key="deleteModelCancel-{{$loop->index}}"
                                                                   type="button" label="{{ __('Cancel') }}"
                                                                   data-dismiss="modal" class="btn btn-light"/>
                                                    <x-form.button label="{{ __('Yes') }}" data-dismiss="modal"
                                                                   wire:key="deleteModelSubmit-{{$loop->index}}"
                                                                   wire:click="deleteQuestion( {{$question['id']}}, '{{isset($question['section']) ? 'wta' : 'ptw' }}', {{$loop->index}} ) "/>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </td>

                            </tr>

                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- Add New Question modal -->
    <div wire:ignore.self class="modal fade" id="add-new-questions-modal" tabindex="-1" role="dialog"
         aria-labelledby="add-model-label" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header bg-light">
                    <h4 class="modal-title" id="add-model-label">{{ __('Add New Questions') }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>

                <div class="modal-body p-3 ">
                    <form wire:submit.prevent="storeNewQuestions()" id="add-new-questions-form" action="" method="POST">
                        @csrf

                        <x-add-symbol label="{{ __('More') }}" wire:click="addModelNewQuestion('add')"
                                      wire:key="addSymbol"/>

                        @foreach($new_question  as $index => $question)
                            <div class="form-group">
                                @if(!$loop->first)
                                    <x-remove-symbol wire:click="addModelNewQuestion('remove',{{$index}})"
                                                     label="{{ __('remove') }}"/>
                                @endif

                                <x-form.text-input wire:model.defer="new_question.{{$index}}"
                                                   wire:key="questionField-{{$loop->index}}"
                                                   label="{{ __('Question #') }} {{$loop->iteration}}"
                                                   required="required"/>
                            </div>
                        @endforeach

                        <x-form.select-input wire:model="addModal.belongTo"
                                             label="{{ __('Belong To') }}"
                                             required="required">
                            @foreach($tables as $table)
                                <option value="{{$table}}">{{$table}}</option>
                            @endforeach
                        </x-form.select-input>


                        @if( ($addModal['belongTo'] ?? '') == 'WTA')
                            <x-form.select-input wire:model.defer="addModal.section" label="{{ __('Section') }}"
                                                 required="required">
                                @foreach($sections as $section)
                                    <option value="{{$section->id}}">{{$section->name}}</option>
                                @endforeach
                            </x-form.select-input>
                        @endif

                    </form>
                </div>

                <div class="modal-footer pt-0">
                    <x-form.button type="button" label="{{ __('Cancel') }}" data-dismiss="modal" class="btn btn-light"/>
                    <x-form.button form="add-new-questions-form" label="{{ __('Save') }}"/>
                </div>
            </div>
        </div>
    </div>

</div>


<script>


    document.addEventListener('DOMContentLoaded', function () {


        Livewire.on('set_update_model_fields', (id) => {

            let record = $('#question-row-' + id);
            //get the values from HTML table
            let question = record.find('#question-field').text();
            let section = record.find('#section-field').text();


            //set the values into inputs fields in update-question-model
            record.find('#update-question-field').val(question);
        @this.set('inspection.question_update', question);

            if (section) {
                record.find('#update-table-field').val('WTA');
            @this.set('inspection.table_update', 'WTA');
                record.find('#update-section-field').val(section);
            @this.set('inspection.section_update', section);
            } else {
                record.find('#update-table-field').val('PTW');
            @this.set('inspection.table_update', 'PTW');
            }
        })

        Livewire.on('control_modal', (id, action) => {
            if (action === 'hide') {
                $('#' + id).modal('hide');
                console.log('#' + id)
            } else if (action === 'show') {
                $('#' + id).modal('show');
            }
        })


        Livewire.on('hide_alert', () => {
            $(function () {
                setTimeout(function () {
                    $(".alert").hide()
                }, 5000);
            });
        })


    });

</script>
@push('scripts')


@endpush
