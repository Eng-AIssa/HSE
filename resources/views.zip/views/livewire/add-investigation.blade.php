<div class="row justify-content-center">


    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
        <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Investigation') }} # {{$object->id}} </h3>
    </div>

    <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
         style="display: flex;">
        <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-2 ml-2 ml-sm-0">
            <h3 class="">{{ __('Status:') }}</h3>
            <p class=" ml-2  font-20" style="padding-top: 0.6rem;">{{ __('Initiation') }}</p>
        </div>
    </div>


    <form wire:submit.prevent="store()" id="investigation-form" class="col-sm-11 {{--col-xl-11--}} {{--ml-2--}} mt-2 reporting-form"
          method="POST"
          action="">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <x-form.workflow stage="{{ __('Initiation') }}" first="{{ __('Responsible') }}" second="{{ __('Sponsor') }}"
                         third="{{ __('Leader') }}" forth="{{ __('Sponsor') }}"
                         fMessage="{{ __('Assign Sponsor') }}" sMessage="{{ __('Assign Investigation Leader') }}"
                         tMessage="{{ __('Investigate') }}"
                         fthMessage="{{ __('Approve/Reject') }}"/>


        <h5 class="bg-light p-2 mt-0 mb-3">{{ __('Type & Date') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.type" label="{{ __('Investigation Type')}}"
                                     required="required">
                    @foreach($datalist->where('name', 'Investigation Type')->first()->content as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.classification" required='required'
                                     label="{{ __('Classification') }}"
                                     id="general_classification"
                                     name="classification">
                    @foreach($datalist->where('name','Classification')->first()->content as $item)
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="investigation.target_date" label="{{ __('Target Date') }}"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="investigation.actual_completion_date" label=""
                                   label="{{ __('Actual Completion Da') }}"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Sequence of Events') }}</h5>

        <div class="row " id="investigation-data-container">

            <span wire:click="newEvent('add')s" wire:ignore
                  style="position: absolute; right: 10px; z-index: 1;"
                  class=" text-primary">{{ __("Add Next Event") }}
                <i style="z-index: 1;" id="add-event" data-feather="plus-circle"
                   class="icon-dual-blue icons-sm clicky"></i>
            </span>

            @foreach($event as $single_event)
                <div class="col-12 col-md-3 mb-md-3">
                    <x-form.date-input wire:model.defer="event.{{$loop->index}}.date"
                                       label="{{ __('Event Date') }}"
                                       mb="0" required="required"/>
                </div>

                <div class="col-12 col-md-3">
                    <x-form.time-input wire:model.defer="event.{{$loop->index}}.time"
                                       label="{{ __('Event Time') }}"
                                       mb="0" required="required"/>
                </div>

                <div class="col-12 col-md-6 mb-2 mb-md-0">

                    @if(!$loop->first)
                        <span wire:click="newEvent('remove', {{$loop->index}})" wire:ignore
                              class='text-danger' style='position: absolute; right: 15px; z-index: 1;'>
                            {{ __('remove') }}
                            <i style="z-index: 1;" class="text-danger clicky">X</i>
                        </span>
                    @endif

                    <x-form.textarea-input wire:model.defer="event.{{$loop->index}}.description"
                                           label="{{ __('Event Description') }}"
                                           placeholder="{{ __('Description') }}"
                                           required="required" rows="1" mb="0"/>
                </div>

            @endforeach
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Investigation Data') }}</h5>

        <div class="row">
            <div class="col-md-6" wire:ignore>
                <x-form.select-input wire:model="investigation.direct_immediate_cause"
                                     label="{{ __('Immediate Causes') }}" required="required"
                                     mb="0">
                    @foreach($datalist->where('name', 'Immediate Causes')->first()->content as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.immediate_cause"
                                     wire:ignore.self label="-" mb="0"
                                     id="immediate-cause-sub" required="required">
                    @foreach($sub_immediate as $sub)
                        <option value="{{$sub}}">{{$sub}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 hide" id="immediate-cause-manual" wire:ignore>
                <x-form.textarea-input wire:model.defer="investigation.immediate_cause_manual" label=""
                                       placeholder="{{ __('Write Here') }}" rows="1" mb="0"
                />
            </div>
        </div>


        <div class="row mt-3">
            <div class="col-md-6" wire:ignore>
                <x-form.select-input wire:model="investigation.direct_contributing_factor"
                                     label="{{ __('Contributing Factors') }}" required="required"
                                     mb="0" mt="0">
                    @foreach($datalist->where('name', 'Contributing Factors')->first()->content as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.contributing_factor"
                                     label="-" mb="0" wire:ignore.self
                                     id="contributing-factor-sub" mt="0"
                                     required="required">
                    @foreach($sub_factor as $sub)
                        <option value="{{$sub}}">{{$sub}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-md-12 hide" id="contributing-factor-manual" wire:ignore>
                <x-form.textarea-input wire:model.defer="investigation.contributing_factor_manual" label=""
                                       placeholder="{{ __('Write Here') }}" rows="1"
                                       mb="0"/>
            </div>
        </div>


        <div class="row mt-3">
            <div class="col-md-6" wire:ignore>
                <x-form.select-input wire:model.="investigation.direct_root_cause" label="{{ __('Root Causes') }}"
                                     required="required" mb="0"
                                     mt="0">
                    @foreach($datalist->where('name', 'Root Causes')->first()->content as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.root_cause"
                                     label="-" wire:ignore.self
                                     mb="0" id="root-cause-sub" mt="0"
                                     required="required">
                    @foreach($sub_root as $sub)
                        <option value="{{$sub}}">{{$sub}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 hide" id="root-cause-manual" wire:ignore>
                <x-form.textarea-input wire:model.defer="investigation.root_cause_manual" label=""
                                       placeholder="{{ __('Write Here') }}" rows="1" mb="0"
                />
            </div>
        </div>


        <div class="row mt-3" wire:ignore>
            <div class="col-md-6">
                <x-form.select-input wire:model.defer="investigation.root_cause_analysis_tool"
                                     label="{{ __('Root Cause Analysis Tool') }}"
                                     id="root-cause-analysis-tool" required="required" mb="0">
                    @foreach($datalist->firstWhere('name', 'Root Cause Analysis Tool')->content as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </x-form.select-input>

            </div>

            <div class="col-md-6 mt-2 mt-md-0 d-flex align-self-end">
                <x-form.checkbox wire:model.defer="investigation.has_communication_done"
                                 label="{{ __('Communication Done to Authorities') }}"
                                 id="done-communication" value="1" name="done_communication"/>
            </div>

            <div class="col-6 hide" id="root-cause-analysis-tool-manual">
                <x-form.text-input wire:model.defer="investigation.root_cause_analysis_tool_manual"
                                   placeholder="{{ __('Write Here') }}" mb="0"
                />
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3 mt-3">{{ __('Related People') }}</h5>

        <div class="row">

            <span wire:key="add_accompany" wire:click="newTeamMember('add')" wire:ignore
                  style="position: absolute; right: 10px; z-index: 1;"
                  class=" text-primary">{{ __('Add team member') }}
                <i style="z-index: 1;" id="add-member" data-feather="plus-circle"
                   class="icon-dual-blue icons-sm clicky"></i>
            </span>

            <div class="col-12 col-md-6" wire:ignore>
                <x-form.select-input wire:key="investigation-leader"
                                     wire:model.defer="investigation.investigation_leader"
                                     label="{{ __('Investigation Leader') }}"
                                     name="investigation_leader" class="js-select"
                                     required="required">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">

                <x-form.text-input label="-" placeholder="{{ __('Department') }}"
                                   readonly="readonly"/>
            </div>

            @foreach($investigation['investigation_team'] ?? [] as $team_member)
                <div class="col-12 col-md-6" wire:ignore>
                    <x-form.select-input wire:key="investigation-team-{{$loop->index}}"
                                         wire:model.defer="investigation.investigation_team.{{$loop->index}}"
                                         label="{{ __('Team Member #') }} {{$loop->iteration}}"
                                         name="investigation_team.{{$loop->index}}" class="js-select"
                                         required="required" onchange='fetchData(this)'>
                        @foreach($users as $user)
                            <option value="{{$user->id}}">{{$user->name}}</option>
                        @endforeach
                    </x-form.select-input>
                </div>

                <div class="col-12 col-md-6">

                    <span wire:click="newTeamMember('remove', {{$loop->index}})" wire:ignore
                          class='text-danger' style='position: absolute; right: 15px; z-index: 1;'>
                        {{ __('remove') }}
                        <i style="z-index: 1;" class="text-danger clicky">X</i>
                    </span>

                    <x-form.text-input label="-" placeholder="{{ __('Department') }}"
                                       readonly="readonly"/>
                </div>
            @endforeach

        </div>

        <div class="members mt-1" wire:ignore>

        </div>


        <div class="row sponsor" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="investigation.sponsor"
                                     label="{{ __('Sponsor') }}"
                                     name="sponsor" class="js-select"
                                     required="required">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}"
                                   readonly="readonly"/>
            </div>
        </div>


    </form>


    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2--}} " wire:ignore>
        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Attachments & Documents') }}
            <span style="color: red">*</span></h5>


        <x-form.file-input/>


        <div class=" d-flex justify-content-end mt-3">
            <x-form.button id="my-secret-btn" form="investigation-form"
                           label="{{ __('Submit') }}"
                           class="m-1"/>
        </div>
    </div>


</div>

@push('scripts')


    <script>


        window.onbeforeunload = function () {

        @this.leavePage();

        }


        $('#investigation-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        //initialize users select input as select2 elements to enable search
        // and send chosen value to backend on change
        $(document).ready(function () {
            let select = $('.js-select');
            select.select2({
                placeholder: "Select",
            });

            select.on('change', function (e) {
            @this.set('investigation.' + e.target.name, e.target.value);
            });
        });


        //Called onChange of select2 inputs which were generated dynamically, fetch chosen option and save it on backend,
        function fetchData(me) {
            let name = $(me).attr('name');
            let value = $(me).val();
        @this.set('investigation.' + name, value);
        }

    </script>




    <script>
        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                $('#upload').click();
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('runScripts', () => {
                $('.js-select').select2({
                    placeholder: "Select",
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');


                //reset values, remove generated elements, hide shown elements
                $('#immediate-cause-manual').val('').hide();
                $('#contributing-factor-manual').val('').hide();
                $('#root-cause-manual').val('').hide();
                $('#root-cause-analysis-tool-manual').val('').hide();
                $('.hijri').html('')
                $('#file-previews .card').remove();

                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                        $('.js-select').val(null).trigger('change');
                    }, 6000);
                });


            });

        })
    </script>

@endpush
