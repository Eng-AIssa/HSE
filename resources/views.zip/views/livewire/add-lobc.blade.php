<div class="row justify-content-center">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 justify-content-start d-flex">
        <h3 class="ml-3 mb-4">{{ __('Loss of Primary Containment') }}  </h3>
    </div>


    <form wire:submit.prevent="store()" id="lobc-form" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('LOPC General Information') }}</h5>

        <div class="row mb-2" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="lobc.type_of_leak"
                                     label="{{ __('Type of Leak') }}"
                                     name="type_of_leak"
                                     required="required" mb="1">
                    @foreach($datalist->firstwhere('name', 'Type Of Leak')->content as $item)
                        <option value="{{$item}}"> {{$item}} </option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="lobc.leak_quantity"
                                   label="{{ __('Leak Quantity(KG)') }}"
                                   min="0" name="leak_quantity"
                                   required="required" type="number"/>
            </div>
        </div>


        <div class="row mb-3">
            <div class="col-6" wire:ignore>
                <x-form.select-input wire:model.defer="lobc.chemical_leaked"
                                     label="{{ __('Chemical Leaked') }}" name="chemical_leaked"
                                     required="required" class="chemical-leaked js-select">
                    @foreach($datalist->firstwhere('name', 'Chemical Leaked')->content as $item)
                        <option value="{{$item}}"> {{$item}} </option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-6 pl-5">
                <div class="row ml-1">
                    <label>{{ __('Any Person Exposed?')}}<span
                            class="pl-1 text-danger">*</span></label>
                </div>
                <div class="row ml-3 mt-1 flex-md-row flex-column">
                    <x-form.radioButton wire:model.defer="lobc.was_any_person_exposed"
                                        label="{{ __('Yes') }}" id="exposed-person-yes"
                                        required="required" value="1"
                                        name="exposed_person" class="align-self-end"/>

                    <x-form.radioButton wire:model.defer="lobc.was_any_person_exposed"
                                        label="{{ __('No') }}" id="exposed-person-no"
                                        name="exposed_person" class="ml-md-3" value="0"/>
                </div>
            </div>
        </div>


        <div class="row mb-3">
            <div class="col-8 ">
                <div class="row" wire:ignore>
                    <div class="col-6 pr-1">
                        <x-form.text-input wire:model.defer="lobc.hours"
                                           min="0" type="number" mb="0"
                                           label="{{ __('Leak Duration') }}"
                                           name="leak_duration_hours" id="hours"
                                           required="required" class="pl-2"/>
                        <span class="time-label-col-5">{{ __('hours') }}</span>
                    </div>

                    <div class="col-6 pl-0">
                        <x-form.text-input wire:model.defer="lobc.minutes"
                                           min="0" type="number" label="{{ __('-') }}"
                                           name="leak_duration_minutes" mb="0"/>
                        <span class="time-label-col-5">{{ __('minutes') }}</span>
                    </div>
                </div>
            </div>
        </div>


        <div class="row mb-3" wire:ignore>
            <div class="col-12 col-md-6  mb-1 mb-md-0">
                <x-form.select-input wire:model.defer="lobc.equipment_involved"
                                     label="{{ __('Equipment Involved') }}"
                                     name="equipment_involved" mb="0"
                                     id="equipment-involved" required="required">
                    @foreach($datalist->firstwhere('name', 'Equipment Involved')->content as $item)
                        <option value="{{$item}}"> {{$item}} </option>
                    @endforeach
                    <option value="Other">Other</option>
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6 hide" id="involved-employee">
                <x-form.select-input wire:model.defer="lobc.employee_involved"
                                     label="{{ __('Employee/Contractor Involved') }}"
                                     name="employee_involved" mb="0" class="js-select"
                                     id="employee-involved">
                    @foreach($users as $user)
                        <option value="{{$user->name}}">{{$user->name}}</option>
                    @endforeach
                    <option value="Other">Other</option>
                </x-form.select-input>
            </div>


            <div class="hide employee-equipment-manual-container col-12" wire:ignore>
                <div class="row">
                    <div class="col-md-6 ">
                        <x-form.text-input wire:model.defer="lobc.equipment_involved_manual"
                                           style="margin-top: -10px;"
                                           name="equipmentInvolved"
                                           placeholder="Write Equipment Name"
                                           mb="0" id="equipment-involved-manual"
                                           class="hide"/>
                    </div>

                    <div class=" col-md-6 ">
                        <x-form.text-input wire:model.defer="lobc.employee_involved_manual"
                                           style="margin-top: -10px;"
                                           name="employeeInvolved"
                                           placeholder="Write Employee Name"
                                           mb="0" id="employee-involved-manual"
                                           class="hide"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Location & Related Issues') }}</h5>

        <div class="row mb-3">
            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.select-input wire:model="lobc.location_id"
                                     required='required' label="{{ __('Location') }}"
                                     name="location_id" mb="1">
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="lobc.area_id" wire:ignore.self
                                     required='required' label="{{ __('Area') }}"
                                     name="area_id" mb="1">
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.text-input wire:model.defer="lobc.location_details"
                                   label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details"/>
            </div>
        </div>


        <div class="row mb-3 ">
            <div class="col-12 mb-1">
                <div class="row ml-1">
                    <div class="col-7">
                        <label
                            class="font-weight-bold">{{ __('Leak resulted into fire/explosion?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>
                    </div>

                    <div class="col-5 d-flex">
                        <x-form.radioButton wire:model="lobc.has_leak_resulted_into_fire"
                                            label="{{ __('Yes') }}" id="fire-explosion-yes"
                                            name="fire_explosion" value="1" required="required"/>

                        <x-form.radioButton wire:model="lobc.has_leak_resulted_into_fire"
                                            label="{{ __('No') }}" id="fire-explosion-no"
                                            name="fire_explosion" class="ml-3" value="0"/>
                    </div>
                </div>
            </div>


            <div class="col-12 mb-1">
                <div class="row ml-1 ">
                    <div class="col-7">
                        <label
                            class="font-weight-bold">{{ __('Leak resulted into environment issues?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>
                    </div>

                    <div class="col-5 d-flex align-items-center">
                        <x-form.radioButton wire:model.defer="lobc.has_leak_resulted_into_environment_issues"
                                            label="{{ __('Yes') }}" id="environment-issues-yes"
                                            name="environment_issues" value="1" required="required"/>

                        <x-form.radioButton wire:model.defer="lobc.has_leak_resulted_into_environment_issues"
                                            label="{{ __('No') }}" id="environment-issues-no"
                                            name="environment_issues" class="ml-3" value="0"/>
                    </div>
                </div>
            </div>

            <div class="col-12  mb-1">
                <div class="row ml-1">
                    <div class="col-7">
                        <label class="font-weight-bold">{{ __('Leak resulted into human injury?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>
                    </div>

                    <div class="col-5 d-flex">
                        <x-form.radioButton wire:model.defer="lobc.has_leak_resulted_into_human_injury"
                                            label="{{ __('Yes') }}" id="human-injury-yes"
                                            name="human_injury" value="1" required="required"/>

                        <x-form.radioButton wire:model.defer="lobc.has_leak_resulted_into_human_injury"
                                            label="{{ __('No') }}" id="human-injury-no"
                                            name="human_injury" class="ml-3" value="0"/>
                    </div>
                </div>
            </div>

            <div class="col-12 mb-1 ">
                <div class="row ml-1">
                    <div class="col-7">
                        <label
                            class="font-weight-bold">{{ __('Is release resulted into emergency evacuation or shelter in place?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>
                    </div>

                    <div class="col-5 d-flex align-items-center">
                        <x-form.radioButton wire:model.defer="lobc.has_release_resulted_into_emergency_evacuation"
                                            label="{{ __('Yes') }}" id="emergency-evacuation-yes"
                                            name="emergency_evacuation" value="1" required="required"/>

                        <x-form.radioButton wire:model.defer="lobc.has_release_resulted_into_emergency_evacuation"
                                            label="{{ __('No') }}" id="emergency-evacuation-no"
                                            name="emergency_evacuation" class="ml-3" value="0"/>
                    </div>
                </div>
            </div>

            <div class="col-12 mb-1 ">
                <div class="row ml-1">
                    <div class="col-7">
                        <label
                            class="font-weight-bold">{{ __('Is release resulted in adverse consequences outside of facility?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>
                    </div>

                    <div class="col-5 d-flex align-items-center">
                        <x-form.radioButton wire:mdoel.defer="lobc.has_release_resulted_in_adverse_consequences"
                                            label="{{ __('Yes') }}" id="adverse-consequences-yes"
                                            name="adverse_consequences" value="1" required="required"/>

                        <x-form.radioButton wire:model.defer="lobc.has_release_resulted_in_adverse_consequences"
                                            label="{{ __('No') }}" id="adverse-consequences-no"
                                            name="adverse_consequences" class="ml-3" value="0"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Leak Type') }}</h5>

        <div class="row my-3 ml-1 dropdown checkboxes-container" wire:ignore>

            <div class="col-12  " data-toggle="dropdown" aria-haspopup="true"
                 aria-expanded="false">
                <div class="icon-item font-16" id="typeOfLeakHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Type') }}</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up" style="width: 50%">

                    <div class="col-12 col-sm-6 ">
                        <x-form.checkbox wire:model.defer="lobc.leak_type.1"
                                         label="{{ __('Pin hole') }}"
                                         id="pin-hole-1" name="leak_type"/>
                        <x-form.checkbox wire:model.defer="lobc.leak_type.2"
                                         label="{{ __('Crack') }}"
                                         id="crack-2" name="leak_type"/>
                    </div>

                    <div class="col-12 col-sm-6 ">
                        <x-form.checkbox wire:model.defer="lobc.leak_type.3"
                                         label="{{ __('Flange') }}"
                                         id="flange-3" name="leak_type"/>
                        <x-form.checkbox wire:model.defer="lobc.leak_type.4"
                                         label="{{ __('Seal') }}"
                                         id="seal-4" name="leak_type"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Operational Mode') }}</h5>

        <div class="row my-3 ml-1 dropdown checkboxes-container" wire:ignore>

            <div class="col-12  " data-toggle="dropdown" aria-haspopup="true"
                 aria-expanded="false">
                <div class="icon-item font-16" id="operationalModeHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Mode') }}</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up" style="width: 50%">

                    <div class="col-12 col-sm-6">
                        <x-form.checkbox wire:model.defer="lobc.operational_mode.1"
                                         label="{{ __('Shutdown') }}" id="shutdown-1"
                                         name="operational_mode"/>
                        <x-form.checkbox wire:model.defer="lobc.operational_mode.2"
                                         label="{{ __('Emergency') }}" id="emergency-2"
                                         name="operational_mode"/>
                    </div>

                    <div class="col-12 col-sm-6">
                        <x-form.checkbox wire:model.defer="lobc.operational_mode.3"
                                         label="{{ __('Startup') }}" id="startup-3"
                                         name="operational_mode"/>
                        <x-form.checkbox wire:model.defer="lobc.operational_mode.4"
                                         label="{{ __('Testing') }}" id="testing-4"
                                         name="operational_mode"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Equipment & Immediate Action') }}</h5>

        <div class="row mb-2" wire:ignore>
            <div class="col-12 col-md-6 ">
                <x-form.select-input wire:model.defer="lobc.type_of_equipment_involved"
                                     label="{{ __('Type of Equipment Involved') }}"
                                     required='required' name="type_of_equipment_involved">
                    @foreach($datalist->where('name','Type of Equipment Involved')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6 ">
                <x-form.select-input wire:model.defer="lobc.apparent_cause"
                                     label="{{ __('Apparent Cause') }}" name="apparentCause"
                                     required='required'>
                    @foreach($datalist->where('name','Apparent Cause')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <div class="row pb-1 mb-3">
            <div class="col-12">
                <div class="row ml-1">
                    <label class="font-weight-bold">{{ __('Equipment Condition:')}}<span
                            class="pl-1 text-danger">*</span></label>
                </div>

                <div class="row  ml-3 mt-1">
                    <x-form.radioButton wire:model.defer="lobc.equipment_condition"
                                        label="{{ __('Under Operation') }}" id="under-operation"
                                        name="equipment_condition" value="Under Operation"/>

                    <x-form.radioButton wire:model.defer="lobc.equipment_condition"
                                        label="{{ __('Under Maintenance') }}"
                                        id="under-maintenance" value="Under Maintenance"
                                        name="equipment_condition" class="ml-3"/>
                </div>
            </div>

        </div>


        <div class="row ">
            <div class="col-12 ">
                <x-form.textarea-input wire:model.defer="lobc.immediate_action_taken"
                                       label="{{ __('Actions Taken Immediately to Contain the Gas Leak') }}"
                                       name="ActionsTakenImmediatelyToContainTheGasLeak"
                                       required='required' rows="3"/>
            </div>
        </div>

    </form>


    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-1 ml-2 ml-sm-3--}} ">
        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Attachment & Documents') }}</h5>

        <x-form.file-input/>


        <div class="row justify-content-end">
            <x-form.button form="lobc-form" id="my-secret-btn" class="m-1" label="{{ __('Submit')}}"/>
        </div>
    </div>
</div>




@push('scripts')

    <script>


        $('#lobc-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        //initialize users select input as select2 elements to enable search
        // and send chosen value to backend on change
        $(document).ready(function () {
            let select = $('.js-select');
            select.select2({
                placeholder: "Select",
            });

            select.on('change', function (e) {
            @this.set('lobc.' + e.target.name, e.target.value);
            });
        });
    </script>



    <script>
        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                $('#upload').click();
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');


                //reset values, remove generated elements, hide shown elements
                $('.result-container').hide().find('span').remove();
                $('#equipment-involved-manual').val('').hide();
                $('#involved-employee').hide();
                $('#employee-involved-manual').val('').hide();
                $('#file-previews .card').remove();

                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                        $('.js-select').val(null).trigger('change');
                    }, 6000);
                });


            });

        })
    </script>



    {{-- handle checkbox lists style and dynamic adding and removing --}}
    <script>

        $('.checkbox').on('change', function () {
            let checkboxes_result_container = $(this).parents('.checkboxes-container').find('.result-container');

            // if checkbox is checked
            if ($(this).prop('checked') === true) {

                // create span to hold the value of the checked checkbox
                let span_element = $("<span id='" + $(this).attr('id') + "2' class=' bg-light rounded' style='display: inline-block; margin:5px 5px 0 5px; padding: 5px 10px; font-size: 0.74rem;'></span>");

                // create small exit icon with 'x' sign to remove span manually if desired
                let small_quite = $("<small class='clicky ml-2 ' onclick='smallQuite(this)'>x</small>")

                // add checked checkbox value to the created span and attach the created close icon
                span_element.text($(this).val()).append(small_quite);

                // show the results container to hold the created span
                checkboxes_result_container.fadeIn(1000);

                // add the created spans to results container
                checkboxes_result_container.append(span_element);

                // else if the checkbox was unchecked
            } else {

                // remove span which is related to unchecked checkbox
                $('#' + $(this).attr('id') + '2').remove();

                // hide the results container if no spans left to show
                if (!checkboxes_result_container.find('span').html())
                    checkboxes_result_container.fadeOut(1000);
            }
        });


        // function to handle the click event on span's close icon
        function smallQuite(me) {
            let checkbox = $(me).parent('span').attr('id');
            let result_container = $(me).parents('.result-container');
            let checkbox_id = $('#' + checkbox.slice(0, -1));

            Livewire.emit('unsetCheckboxValue', checkbox.slice(-2, -1), checkbox_id.attr('name').slice(0, -2));

            // uncheck the checkbox related to removed span
            checkbox_id.prop("checked", false);

            // hide the result container if there is no spans left to show( -1 in the if statement represent the span which will be removed after the if)
            if (!(result_container.find('span').length - 1 > 0)) {
                result_container.fadeOut(1000);
            }

            // remove the span
            $('#' + checkbox).remove();
        }


        $('.dropdown-menu').on('click', function (e) {
            e.stopPropagation();
        });


    </script>


@endpush
