<div class="row justify-content-center">

    @if(session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show "
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    @if(session()->has('validate_inspection'))
        <div
            class="alert alert-danger alert-dismissible fade show "
            style="position: fixed; top: 80px; right: 10px; z-index: 1; padding: .35rem 3.9rem .35rem 1.2rem;"
            role="alert">
            <i class="mdi mdi-close-octagon-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500;">{{session('validate_inspection')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    @if(session()->has('delete'))
        <div
            class="alert alert-warning alert-dismissible fade show "
            style="position: fixed; top: 80px; right: 10px; z-index: 1; padding: .35rem 3.9rem .35rem 1.2rem;"
            role="alert">
            <i class="mdi mdi-alert-circle-check-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500;">{{session('delete')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
        <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Inspection') }}
            # @isset($inspection['id']){{$inspection['id']}}@endisset </h3>
    </div>
    <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
         style="display: flex;">
        <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-2 ml-2 ml-sm-0">
            <h3 class="">{{ __('Status:') }}</h3>
            <p class=" ml-2  font-20" style="padding-top: 0.6rem;">{{$status}}</p>
        </div>
    </div>


    <form wire:submit.prevent="storeInspection()" id="inspection-form"
          class="col-sm-11 {{--col-xl-11--}} {{--ml-2--}} mt-2 reporting-form" method="POST"
          action="{{route('msi.store')}}">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>

        <x-form.workflow :stage="$stage"/>

        <div class="row justify-content-around mb-2">
            <button wire:click="moveStage('back')" type="button" class="btn btn-primary">Previous Stage</button>
            <button wire:click="moveStage('next')" type="button" class="btn btn-primary">Next Stage</button>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Inspection Type') }}</h5>

        <div class="row mb-2">
            <div class="col-12 mb-3">
                <label class="font-weight-bold">{{ __('Inspection is Related to')    }}:</label>
                <span class="pl-1 text-danger">*</span>
                <div class="d-flex">
                    <x-form.radioButton wire:model="inspection.name" label="MSI" name="inspection" id="inspection-msi"
                                        class="ml-3"/>
                    <x-form.radioButton wire:model="inspection.name" label="WTA" name="inspection" id="inspection-wta"
                                        class="ml-3"/>
                    <x-form.radioButton wire:model="inspection.name" label="PTW" name="inspection" id="inspection-ptw"
                                        class="ml-3"/>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="inspection.type" label="{{ __('Type') }}" name="type"
                                     required='required'>
                    @foreach($datalist->where('report_name', ucfirst(strtolower($inspection['name'])))->where('name', 'Type')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <div class="row">
                    <div class="col-12">
                        <x-form.select-input wire:model.defer="inspection.category" label="{{ __('Category') }}"
                                             name="category" id="category"
                                             required='required' mb="0">
                            @foreach($datalist->where('report_name', ucfirst(strtolower($inspection['name'])))->where('name', 'Category')->first()->content as $item)
                                <option value="{{$item}}">{{ $item }}</option>
                            @endforeach
                            <option value="Other">Other</option>
                        </x-form.select-input>
                    </div>
                    <div class="col-12">
                        <x-form.text-input wire:model.defer="inspection.category" label=''
                                           style='margin-top: -10px;' class="hide"
                                           name='contactor_department' id="manual-category"
                                           placeholder='Write Category'
                                           mb='0'/>
                    </div>
                </div>
            </div>
        </div>

        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Time & Location') }}</h5>


        <div class="row">
            <div class="col-12 col-sm-6">
                <x-form.date-input wire:model.defer="inspection.inspection_date" label="{{ __('Inspection Date') }}"
                                   max="{{date('Y-m-d')}}"
                                   name="inspection_date" required='required'/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.time-input wire:model.defer="inspection.inspection_time" label="{{ __('Inspection Time') }}"
                                   name="inspection_time" required='required'/>
            </div>
        </div>


        <div class="row">
            <div class="col-12 col-sm-6">
                <x-form.date-input label="{{ __('Logging Date') }}"
                                   readonly="readonly"
                                   name="logging_date" value="{{date('Y-m-d')}}"/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.time-input label="{{ __('Logging Time') }}"
                                   readonly="readonly"
                                   name="logging_time" value="{{date('H:i:s', strtotime('+3 hours') )}}"/>
            </div>
        </div>


        <div class="row">
            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model="inspection.location_id" required='required'
                                     label="{{ __('Location') }}"
                                     name="location_id">
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="inspection.area_id" required='required' label="{{ __('Area') }}"
                                     name="area_id">
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.text-input wire:model.defer="inspection.location_details" label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('MSI Data') }}</h5>

        <x-form.textarea-input wire:model.defer="inspection.activity_observed" label="{{ __('Activity Observed') }}"
                               rows="2"
                               name="activity_observed"
                               required='required' id="activity-observed"/>


        <x-form.textarea-input wire:model.defer="inspection.general_remark" label="{{ __('General Remarks') }}" rows="2"
                               name="general_remark"
        />

        <div x-data="{showContact:@entangle('showContact').defer }">
            <div class="row mb-3 mt-4">

                <div wire:ignore class="col-6 vertical-alignment-when-wrapping">
                    <div class="row ml-1">
                        <label class="font-weight-bold">{{ __('Any Contact Made?')}}
                            <span
                                class="pl-1 text-danger">*</span></label>

                    </div>
                    <div class="row flex-md-row flex-column ml-3 mt-1">
                        <x-form.radioButton @click="showContact='open'" wire:model.defer="inspection.is_contact_made"
                                            label="{{ __('Yes') }}"
                                            id="contact-made-ye"
                                            name="contact_made" value="1"/>

                        <x-form.radioButton @click="showContact='close'" wire:model.defer="inspection.is_contact_made"
                                            wire:click="updateContact('hide', -1)" label="{{ __('No') }}"
                                            id="contact-made-n"
                                            name="contact_made" class="ml-md-3" value="0"/>
                    </div>
                </div>


                <div class="col-6 d-flex align-items-center ">
                    <span x-show="showContact == 'open'" x-transition.duration.1000ms
                          wire:click="updateContact('increment',-1)"
                          wire:key="add_more_contact" wire:ignore
                          class=' text-primary ' id="add-more-container">
                            <i id='add-contact-employee' data-feather='plus-circle'
                               class='icon-dual-blue icons-sm clicky'></i>
                            {{ __('Add more') }}
                    </span>
                </div>


            </div>

            <div x-show="showContact == 'open'" x-transition.duration.1000ms wire:ignore
                 class='row mb-3 hid contact-container'
                 id='contact-container'>
                <div class='col-12 col-md-6'>
                    <div class='row flex-column ml-1' id='contact-information-container' style='margin-top: 20px;'>


                        <x-form.checkbox wire:model="inspection.has_interactive_discussion_made.'0'" class='ml-1'
                                         wire:key="contactor-interactive-discussion-0"
                                         label="{{ __('Interactive Discussion Made with Employee/Contractor') }}"
                                         name='interactive_discussion_with_contract_held'
                                         id='interaction-discussion'
                                         value='1'/>

                        <x-form.checkbox class='ml-1'
                                         wire:model.defer="inspection.has_positive_behavior_highlighted.'0'"
                                         wire:key="contactor-positive-behavior-0"
                                         label="{{ __('Positive Behaviors highlighted') }}"
                                         name='positive_behavior' id='positive-behaviors'
                                         value='1'/>

                        <x-form.checkbox class='ml-1'
                                         wire:model.defer="inspection.has_concurrence_of_improvement_taken.'0'"
                                         wire:key="contactor-improvement-taken-0"

                                         label="{{ __('Concurrence of Improvement Taken') }}"
                                         name='concurrence_of_improvement_taken'
                                         id='concurrence-of-improvement' value='1'/>
                    </div>
                </div>


                <div class='col-12 col-md-6'>

                    <div class='row' id='involved-employee-container'>

                        <div wire:key="contactor_name" wire:ignore class='col-12  ' id='contactor-name'>
                            <x-form.select-input wire:model="inspection.contact_info_name.'0'"
                                                 wire:key="contactor-name-list-0"
                                                 label="{{ __('Fill Contact Info') }}" name="contact_info_name.'0'"
                                                 id="contact-employee" class="js-select" mb="0">
                                @foreach($users as $user)
                                    <option value="{{$user->id}}">{{$user->name}}</option>
                                @endforeach
                                <option value="Other">Other</option>
                            </x-form.select-input>
                        </div>

                        <div class='col-12 hide manual-contact-department' id="manual-contact-department-0">
                            <x-form.text-input wire:model.defer="inspection.contact_info_name.'0'" label=''
                                               wire:key="contactor-name-0"
                                               style='margin-top: -10px;'
                                               name='contactor_name'
                                               placeholder="{{ __('Write Name') }}"
                                               mb='0'/>
                        </div>


                        <div class='col-12 ' id='contactor-department'>
                            <x-form.text-input wire:model.defer="inspection.contact_info_department.'0'" label=''
                                               wire:key="contactor-department-0"
                                               style='margin-top: -10px;'
                                               name='contactor_department'
                                               placeholder="{{ __('Write Department') }}"
                                               mb='0'/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @for($i=1; $i < $contact; $i++)

            <div class='row mb-3 contact-container' id='contact-container-{{$i}}'>

                <div class='col-12 col-md-6'>

                    <div class='row flex-column ml-1' id='contact-information-container-{{$i}}'
                         style='margin-top: 30px;'>

                        <span style='position: absolute; left: 15px; top: 5px;' class='text-danger'>{{ __('Remove') }}
                            <i wire:click="updateContact('decrement',{{$i}})" onclick='removeContact(this)'
                               class='clicky remove-reporter text-danger'>X</i>
                        </span>

                        <x-form.checkbox class='ml-1'
                                         wire:model.defer="inspection.has_interactive_discussion_made.{{$i}}"
                                         wire:key="contactor-interactive-discussion-{{$i}}"
                                         label="{{ __('Interactive Discussion Made with Employee/Contractor') }}"
                                         name='interactive_discussion_with_contract_held_{{$i}}'
                                         id='interaction-discussion-{{$i}}' value="1"
                        />

                        <x-form.checkbox class='ml-1'
                                         wire:model.defer="inspection.has_positive_behavior_highlighted.{{$i}}"
                                         wire:key="contactor-positive-behavior-{{$i}}"
                                         label="{{ __('Positive Behaviors highlighted') }}" value="1"
                                         name='positive_behavior_{{$i}}' id='positive-behaviors-{{$i}}'
                        />

                        <x-form.checkbox class='ml-1'
                                         wire:model.defer="inspection.has_concurrence_of_improvement_taken.{{$i}}"
                                         wire:key="contactor-improvement-taken-{{$i}}"
                                         label="{{ __('Concurrence of Improvement Taken') }}" value="1"
                                         name='concurrence_of_improvement_taken_{{$i}}'
                                         id='concurrence-of-improvement-{{$i}}'/>
                    </div>
                </div>


                <div class='col-12 col-md-6 my-2 '>

                    <div class='row involved-employee-container' id='involved-employee-container-{{$i}}'>

                        <div wire:ignore wire:key="contactor_name_{{$i}}" class='col-12' id='contactor-name-{{$i}}'>
                            <x-form.select-input wire:model.defer="inspection.contact_info_name.{{$i}}"
                                                 wire:key="contactor-name-list-{{$i}}"
                                                 label="{{ __('Fill Contact Info') }}" mb="0"
                                                 name='contact_info_name.{{$i}}' class="js-select"
                                                 required='required' onchange='fetchData(this, true)'>
                                @foreach($users as $user)
                                    <option value="{{$user->id}}">{{$user->name}}</option>
                                @endforeach
                                <option value="Other">Other</option>
                            </x-form.select-input>
                        </div>

                        <div wire:ignore class='col-12 hide manual-contact-department'
                             id="manual-contact-department-{{$i}}">
                            <x-form.text-input wire:model.defer="inspection.contact_info_name.{{$i}}" label=''
                                               wire:key="contactor-name-{{$i}}"
                                               style='margin-top: -10px;'
                                               name='contactor_name'
                                               placeholder="{{ __('Write Name') }}"
                                               mb='0'/>
                        </div>

                        <div class='col-12 ' id='contactor-department-{{$i}}'>
                            <x-form.text-input wire:model.defer="inspection.contact_info_department.{{$i}}"
                                               wire:key="contactor-department-{{$i}}"
                                               onfocusout="changeBgColor(this)" label='' style='margin-top: -10px;'
                                               name='contactor_department_{{$i}}' id='contactor-sun-{{$i}}'
                                               placeholder="{{ __('Write Department') }}"
                                               mb='0'/>
                        </div>
                    </div>
                </div>
            </div>
        @endfor


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Related People') }}</h5>

        <div class="row ">

            <div class="col-12 col-sm-6 em">
                <x-form.text-input label="{{ __('Reported By') }}" users="users"
                                   placeholder="{{ __('Name') }}" mb="0"
                                   value="{{Auth::user()->name}}" disabled="disabled"
                                   required='required'/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                   value="{{Auth::user()->name}}" disabled="disabled"/>
            </div>
        </div>


        <div class="row ">

            <span wire:click="newEmployee('add')"
                  wire:key="add_accompany" wire:ignore style="position: absolute; right: 10px; z-index: 1;"
                  class=" text-primary">{{ __('Add more employees') }}
                <i style="z-index: 1;" id="add-employee" data-feather="plus-circle"
                   class="icon-dual-blue icons-sm clicky"></i>
            </span>

            @foreach($inspection['accompanied_by'] as $employee)
                <div wire:key="accompanied_by-{{$loop->index}}" wire:ignore
                     class="col-12 col-sm-6">

                    <x-form.select-input wire:model.defer="inspection.accompanied_by.{{$loop->index}}"
                                         label="{{ __('Accompanied By') }} # {{$loop->iteration}}" users="users"
                                         class="js-select" name="accompanied_by.{{$loop->index}}"
                                         onchange='fetchData(this, false)'>
                        @foreach($users as $user)
                            <option value="{{$user->id}}">{{$user->name}}</option>
                        @endforeach
                    </x-form.select-input>

                </div>

                <div class="col-12 col-sm-6">

                    @if(!$loop->first)
                        <span wire:click="newEmployee('remove', {{$loop->index}})"
                              wire:ignore
                              class='text-danger' style='position: absolute; right: 15px; z-index: 1;'>
                            {{ __('remove') }}
                            <i style="z-index: 1;" class="text-danger clicky">X</i>
                        </span>
                    @endif

                    <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                       disabled="disabled"/>
                </div>
            @endforeach
        </div>


        <div class="row notify">
            <div wire:key="notify_only" wire:ignore class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="inspection.notify_only" label="{{ __('Notify Only') }}"
                                     users="users" class="js-select" required="required" name="notify_only">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                   disabled="disabled"/>
            </div>
        </div>


    </form>

    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2--}} ">
        <h5 wire:key="attachment" class=" bg-light p-2 mt-0 mb-3">{{ __('Attachments & Documents') }}</h5>

        <x-form.file-input/>

    </div>


    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2--}} mt-4 reporting-form ">

        @if($inspection['name'] == 'WTA')
            <h3>{{ __('Inspection Check List') }}</h3>

            <div class="row my-3 ml-1 dropdown checkboxes-container">

                <div class="col-12 " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div wire:ignore class="icon-item font-16" id="partsOfBodyHarmedHeading">
                        <i style="color: #4a81d4;" class="mdi mdi-plus-circle-outline mdi-36px clicky"></i>
                        <span style="vertical-align: super;" class="clicky">{{ __('Add Inspection Section') }}</span>
                    </div>
                </div>

                <div class="col-12">
                    <div class="dropdown-menu checkboxes-pop-up ">
                        @foreach($wta_sections as $section)
                            <div class="col-4">
                                <x-form.checkbox wire:model="chosen_section" label="{{ __($section->name) }}"
                                                 value="{{$loop->iteration}}" id="checkbox{{$loop->iteration}}"
                                                 name="section{{$loop->iteration}}"/>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            @foreach($wta_questions as $section)


                <h4 class="mt-4 font-weight-bold">{{$section->name}}:</h4>

                <div class="row border rounded p-1">
                    @foreach($section->questions as $question)

                        <div class="col-8 my-1" style="font-size: 0.9rem;">
                            - {{ ' ' . $question->question}}
                        </div>

                        <div class="col-4 d-flex justify-content-around align-items-center">
                            <x-form.radioButton wire:model="answer.{{$question->id}}"
                                                label="{{ __('Yes') }}"
                                                name="question_{{$question->id}}_yes"
                                                id="question-{{$question->id}}-yes"/>
                            <x-form.radioButton wire:model="answer.{{$question->id}}"
                                                label="{{ __('No') }}"
                                                name="question_{{$question->id}}_no"
                                                id="question-{{$question->id}}-no"/>

                        </div>

                        <div class="col-7 my-3 ml-2">
                            <div
                                class="row flex-column inspection-slider @if($rate[$question->id] == 2) risk-slider @elseif($rate[$question->id] == 1) save-slider @endif">
                                <input wire:model="rate.{{$question->id}}" value="0" type="range" class=" form-range"
                                       min="0" max="2" step="1" disabled id="customRange3">
                                <div class="d-flex justify-content-between mt-1">
                                    <span>{{ __('No Evaluation') }}</span>
                                    <span style="margin-right: 2.5rem; color: #019301;">{{ __('Safe') }}</span>
                                    <span style="color: #f82f56;">{{ __('At Risk') }}</span>
                                </div>
                            </div>
                        </div>

                        @if($rate[$question->id] == 2)
                            <div class="col-4 text-center">
                                <button style="margin-top: 10px; margin-left: 80px; padding: 0.375rem .6em;"
                                        wire:click="resetErrors({{$question->id}})"
                                        type="button"
                                        class="btn btn-primary waves-effect waves-light">{{ __('Add Action') }}
                                </button>
                            </div>

                            <x-modal.add-action :question="$question" :datalist="$datalist" :users="$users"
                                                :id="$question->id" operation="write"/>
                        @endif


                    @endforeach
                </div>

            @endforeach

        @elseif($inspection['name'] == 'PTW')
            <h3 class="mb-4">{{ __('Inspection Check List') }} </h3>


            @foreach($ptw_questions as $question)

                <div class="row mb-4">
                    <div class="col-8 my-1" style="font-size: 0.9rem;">
                        - {{ ' ' . $question->question}}
                    </div>

                    <div class="col-4 d-flex justify-content-around align-items-center">
                        <x-form.radioButton label="{{ __('Yes') }}" name="ptw-question_{{$question->id}}"
                                            wire:model="ptw_answer.{{$question->id}}"
                                            id="ptw-question-{{$question->id}}-yes"/>
                        <x-form.radioButton label="{{ __('No') }}" name="ptw-question_{{$question->id}}"
                                            wire:model="ptw_answer.{{$question->id}}"
                                            id="ptw-question-{{$question->id}}-no"/>
                    </div>

                    <div class="col-7 mt-3 pl-4">
                        <div
                            class="row flex-column inspection-slider @if($ptw_rate[$question->id] == 2) risk-slider @elseif($ptw_rate[$question->id] == 1) save-slider @endif">
                            <input wire:model="ptw_rate.{{$question->id}}" value="0" type="range" class="form-range"
                                   min="0" max="2" step="1" disabled id="customRange3">
                            <div class="d-flex justify-content-between mt-1">
                                <span>{{ __('No Evaluation') }}</span>
                                <span style="color: #019301; margin-right: 2.5rem;">{{ __('Safe') }}</span>
                                <span style="color: #f82f56;">{{ __('At Risk') }}</span>
                            </div>
                        </div>
                    </div>

                    @if($ptw_rate[$question->id] == 2)
                        <div class="col-5 text-center">
                            <button
                                style="margin-top: 10px; margin-left: 50px; padding: 0.375rem .6em;"
                                type="button" wire:click="resetErrors({{$question->id}})"
                                class="btn btn-primary waves-effect waves-light">{{ __('Add Action') }}
                            </button>
                            <br>
                        </div>

                        <x-modal.add-action :question="$question" :datalist="$datalist" :users="$users"
                                            :id="$question->id" operation="write"/>
                    @endif
                </div>

            @endforeach

        @endif


        @if($added_actions)
            <h5 class=" bg-light p-2 mt-0 mt-3">Added Actions</h5>


            <div class="table-responsive">
                <table class="table table-bordered my-2 text-center">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>{{ __('Action ID') }}</th>
                        <th>{{ __('Action Title') }}</th>
                        <th>{{ __('Responsible') }}</th>
                        <th>{{ __('Target Date') }}</th>
                        <th>{{ __('View') }}</th>
                        <th>{{ __('delete') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($added_actions as $key => $added_action)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$added_action['id']}}</td>
                            <td>{{$added_action['title']}}</td>
                            <td>{{$added_action['responsible_person']}}</td>
                            <td>{{$added_action['target_date']}}</td>


                            <td style="padding: 5px;">
                                <button wire:click="$emit('control_modal', 'read-{{$added_action['id']}}', 'show')"
                                        type="button"
                                        class="btn btn-blue">
                                    {{ __('View') }}
                                </button>
                            </td>
                            <td style="padding: 5px;">
                                <button wire:click="removeAction({{$added_action['id']}}, {{$loop->index}})"
                                        type="button" class="btn btn-danger">
                                    {{ __('Remove') }}
                                </button>
                            </td>
                        </tr>

                        <x-modal.add-action operation="read" id="read-{{$added_action['id']}}" :users="$users"
                                            :action="$added_action"/>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif


        <div class="row justify-content-end mt-3">
            <x-form.button id="my-secret-btn" form="inspection-form" label="{{ __('Submit') }}"
                           class="m-1"/>
        </div>
    </div>

</div>



@push('scripts')


    <script>

        window.onbeforeunload = function () {

            let id = @this.inspection.id;

            //only call leaving dialog & function if the form is created
            if (id) {
            @this.leavePage();
                return "";
            }
        }


        $('#inspection-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        //initialize static users select input as select2 elements to enable search
        // and save chosen value onChange to backend
        $(document).ready(function () {
            let select = $('.js-select');
            select.select2({
                placeholder: "Select",
            });

            select.on('change', function (e) {
            @this.set('inspection.' + e.target.name, e.target.value);
                if (select.val() === 'Other') {
                @this.set('inspection.' + e.target.name, null);
                    $(this).closest('.row').find('.manual-contact-department').fadeIn(1000);
                } else
                    $(this).closest('.row').find('.manual-contact-department').fadeOut(1000);
            });
        });


        //Called onChange of select2 inputs which were generated dynamically, fetch chosen option and save it on backend,
        // it also handle text input if 'Other' value chosen
        function fetchData(me, other) {
            let name = $(me).attr('name');
            let value = $(me).val();
            if (value !== 'Other')
            @this.set('inspection.' + name, value);

            //check if the handled field have  manual text field based on 'other' choice
            if (other) {
                if (value === 'Other') {
                @this.set('inspection.' + name, null);
                    $(me).closest('.row').find('.manual-contact-department').fadeIn(1000);
                } else
                    $(me).closest('.row').find('.manual-contact-department').fadeOut(1000);
            }

        }


        //Called onChange of select2 inputs which were generated dynamically in Action modal, fetch chosen option and save it on backend
        function fetchActionData(me) {
            let name = $(me).attr('name');
            let value = $(me).val();
            if (value !== 'Other')
            @this.set('action.' + name, value);

        }
    </script>

    <script type="text/javascript">


        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                $('#upload').click();
            })


            Livewire.on('control_modal', (id, action) => {
                if (action === 'hide')
                    $('#action-modal-' + id).modal('hide');
                else if (action === 'show') {
                    $('#action-modal-' + id).modal('show');
                }
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');


                $('#file-previews .card').remove();

                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                        $('.js-select').val(null).trigger('change');
                    }, 6000);
                });


            });


            //initialize dynamic users select inputs as select2 elements to enable search
            Livewire.on('runScripts', () => {
                $('.js-select').select2({
                    placeholder: "Select",
                });
            })


            Livewire.on('changeBgColor', () => {
                changeBgColor();
            })


            Livewire.on('toggle_sections_container', () => {
                $('#sections-container').fadeToggle();
            });


        });
    </script>



    <script>
        function changeBgColor(me) {

            $('select, input, textarea').each(function () {
                if ($(this).val() !== '') {
                    $(this).css("background-color", "rgb(232, 240, 254)");
                } else {
                    $(this).css("background-color", "#fff");
                }
            });


            $('.js-select').on('change', function (e) {
                if (e.target.value !== '')
                    $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                else
                    $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
            });
        }
    </script>

@endpush
