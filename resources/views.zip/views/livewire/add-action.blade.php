<div class="row justify-content-center">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


        <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
            <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Action') }} # {{$object->id ?? ''}} </h3>
        </div>
        <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
             style="display: flex;">
            <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-2 ml-2 ml-sm-0">
                <h3 class="">{{ __('Status:') }}</h3>
                <p class=" ml-2  font-20" style="padding-top: 0.6rem;">Initiation</p>
            </div>
        </div>


    <form wire:submit.prevent="store" id="action-form" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form"
          method="POST" action="{{route('action.store')}}">
        @csrf


        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <x-form.workflow/>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Category & Title') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model="action.action_item_source"
                                     label="{{ __('Action Item Source') }}"
                                     name="action_item_source" required='required'>
                    @foreach($datalist->where('name','Action Item Source')->first()->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.action_item_type"
                                     label="{{ __('Action Item Type') }}"
                                     name="action_item_type" required='required'>
                    @foreach($datalist->where('name','Action Item Type')->first()->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.action_item_category"
                                     label="{{ __('Action Item Category') }}"
                                     name="action_item_category" required='required'>
                    @foreach($datalist->where('name','Action Item Category')->first()->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12">
                <x-form.text-input wire:model.defer="action.title"
                                   label="{{ __('Action Title') }}"
                                   name="title" id="title" mb="3"
                                   required='required'/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Time & Location') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.date-input wire:model.defer="action.logging_date"
                                   label="{{ __('Logging Date') }}"
                                   max="{{date('Y-m-d')}}"
                                   name="logging_date" required='required'/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.time-input wire:model.defer="action.logging_time"
                                   label="{{ __('Logging Time') }}"
                                   name="logging_time"
                                   required='required'/>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.date-input wire:model.defer="action.target_date"
                                   label="{{ __('Target Date') }}"
                                   min="{{date('Y-m-d')}}"
                                   name="target_date" required='required'/>
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.select-input wire:model="action.location_id"
                                     label="{{ __('Location') }}"
                                     name="location_id"
                                     required='required'>
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.area_id"
                                     wire:ignore.self
                                     label="{{ __('Area') }}"
                                     name="area_id"
                                     required='required'>
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.text-input wire:model.defer="action.location_details"
                                   label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Action Data') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.action_category"
                                     label="{{ __('Action Category') }}"
                                     name="action_category"
                                     required='required'>
                    @foreach($datalist->firstwhere('name','Action category')->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.risk"
                                     label="{{ __('Risk') }}"
                                     name="risk" required='required'>
                    @foreach($datalist->firstwhere('name','Risk')->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="action.priority"
                                     label="{{ __('Priority') }}"
                                     name="priority" required='required'>
                    @foreach($datalist->firstwhere('name','Priority')->content as $item )
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12">
                <x-form.textarea-input wire:model.defer="action.description"
                                       label="{{ __('Action Description') }}"
                                       name="description" required='required'/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Related People') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.text-input label="{{ __('Reported By') }}"
                                   placeholder="{{ __('Name') }}"
                                   value="{{Auth::user()->name}}"
                                   readonly="readonly" required='required' mb="0"/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-"
                                   placeholder="{{ __('Department') }}"
                                   value="{{Auth::user()->department}}"
                                   mb="3" readonly="readonly"/>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="action.responsible_person"
                                     label="{{ __('Responsible Person') }}"
                                     placeholder="{{ __('Name') }}"
                                     name="responsible_person" class="js-select"
                                     required='required' mb="0">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                   disabled="disabled"/>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="action.approver"
                                     label="{{ __('Approver') }}"
                                     placeholder="{{ __('Name') }}"
                                     name="approver" class="js-select"
                                     required='required' mb="0">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="4"
                                   disabled="disabled"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3"> {{ __('Closure & Attachments') }} <span
                style="color: red">*</span>
        </h5>

        <div class="row" wire:ignore>
            <div class="col-12">
                <x-form.textarea-input wire:model.defer="action.closure_justification"
                                       label="{{ __('Action Closure Justification') }}"
                                       name="closure_justification" required='required'/>
            </div>
        </div>


    </form>



    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} ">

        <x-form.file-input/>

        <div class="row justify-content-end">
            <x-form.button form="action-form" label="{{ __('Submit') }}" class="m-1"/>
        </div>

    </div>


    @push('scripts')


        <script>

            window.onbeforeunload = function () {

                let id = @this.action.id;

                //only call leaving dialog & function if the form is created
                if (id) {
                    @this.leavePage();
                    return "";
                }
            }


            $('#action-form').on('submit', function (){
                $("html, body").animate({ scrollTop: 0 }, 800);
            })


            //initialize users select input as select2 elements to enable search
            // and send chosen value to backend on change
            $(document).ready(function () {
                let select = $('.js-select');
                select.select2({
                    placeholder: "Select",
                });

                select.on('change', function (e) {
                @this.set('action.' + e.target.name, e.target.value);
                });
            });
        </script>



        <script>
            document.addEventListener('DOMContentLoaded', function () {

                Livewire.on('uploadAttachments', () => {
                    $('#upload').click();
                })


                Livewire.on('hide_alert', () => {
                    $(function () {
                        setTimeout(function () {
                            $(".alert").hide()
                        }, 5000);
                    });
                })


                Livewire.on('resetJsFields', () => {

                    $('select, input, textarea').each(function () {
                        $(this).css("background-color", "#fff");
                    });

                    $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');


                    //reset values, remove generated elements, hide shown elements
                    $('.hijri').html('');
                    $('#file-previews .card').remove();

                    //timeout was set to prevent action from removing notification alert, so it's set to be done after
                    $(function () {
                        setTimeout(function () {
                            $('.js-select').val(null).trigger('change');
                        }, 6000);
                    });


                });

            })
        </script>

    @endpush
</div>
