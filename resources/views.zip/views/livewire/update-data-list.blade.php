<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-lg-8">
                        <form class="form-inline">
                            <div class="form-group mx-sm-3">
                                <label for="status-select" class="mr-2">Related To</label>
                                <select wire:model="table" class="custom-select" id="status-select">
                                    <option selected="">All</option>
                                    @foreach($tables as $table)
                                        <option value="{{$table}}">{{$table}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mx-sm-3">
                                <label for="status-select" class="mr-2">List Name</label>
                                <select wire:model="subTable" style="max-width: 130px" class="custom-select"
                                        id="status-select">
                                    <option selected="">All</option>
                                    @foreach($subTables as $subTable)
                                        <option value="{{$subTable}}">{{$subTable}}</option>
                                    @endforeach
                                </select>
                            </div>
                            {{--<div class="form-group mx-sm-3">
                                <x-form.button wire:click.prevent="" label="Filter"/>
                            </div>--}}
                        </form>
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <a wire:click="resetProperty()" data-toggle="modal" data-target="#add-dataList"
                               class="text-white btn btn-danger waves-effect waves-light"><i
                                    class="mdi mdi-plus-circle mr-1"></i> Add New</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        @if($successMessage )
            <div wire:poll.visible="dismissMessage()"
                 class="alert {{$isDeleteMessage ? 'alert-warning' : 'alert-success'}} alert-dismissible fade show"
                 style="position: fixed; top: 80px; right: 10px; z-index: 1;  "
                 role="alert">
                <i class="mdi mdi-check-all mr-2"></i> {{$successMessage}}
                <button wire:click="dismissMessage()" type="button" class="close" data-dismiss="alert"
                        aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif


        @foreach($lists as $list)
            <div class="col-lg-6">
                <div class="card-box">
                    <div class="d-flex justify-content-between">
                        <h3>{{$list->name}}</h3>

                        <button wire:click="create({{$list->id}})"
                                id="add-button"
                                type="button"
                                class="btn btn-lg"
                                data-toggle="modal"
                                data-target="#add-model">Add<i class="p-1 far fa-plus-square"></i>
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped mb-0 text-center">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Element</th>
                                <th>Belong To</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($list->content as $item)
                                <tr>
                                    <th class="index" scope="row">{{$loop->iteration}}</th>
                                    @if($loop->first)
                                        <td class="id" hidden>{{$list->id}}</td>@endif
                                    <td wire:poll class="item">{{$item}}</td>
                                    <td>@if($loop->first){{$list->report_name}}@endif</td>
                                    <td class="text-center">
                                        <button wire:click="edit({{$list->id}}, '{{$item}}')"
                                                id="edit-button"
                                                type="button"
                                                class="btn  btn-lg"
                                                data-toggle="modal"
                                                data-target="#edit-model"><i class=" far fa-edit"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button wire:click="delete({{$list->id}}, '{{$item}}')"
                                                id="delete-button"
                                                type="button"
                                                class="btn  btn-lg"
                                                data-toggle="modal"
                                                data-target="#delete-model"><i class="far fa-trash-alt"></i>
                                        </button>
                                    </td>

                                </tr>

                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <!-- Edit modal -->
    <div wire:ignore class="modal fade" id="edit-model" tabindex="-1" role="dialog" aria-labelledby="edit-model-label"
         aria-hidden="true">
        <!-- Start modal-dialog -->
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <!-- Start modal-content -->
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h4 class="modal-title" id="edit-model-label">Edit Model</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-3">
                    <form id="edit-form" action="" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label><strong>{{ __('Element') }}</strong></label>
                            <input id="edit-index" value="" name="index" hidden>
                            <input wire:model="element" id="edit-name" name="name" type="text" class=" form-control"
                                   required>
                        </div>

                        <div class="text-right mt-3">
                            <button wire:click.prevent="resetProperty()" type="button" class="btn btn-light"
                                    data-dismiss="modal">
                                Cancel
                            </button>
                            <button wire:click.prevent="update()" type="button" data-dismiss="modal"
                                    class="btn btn-primary ml-1">
                                Edit
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Add modal -->
    <div wire:ignore class="modal fade" id="add-model" tabindex="-1" role="dialog" aria-labelledby="add-model-label"
         aria-hidden="true">
        <!-- Start modal-dialog -->
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <!-- Start modal-content -->
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h4 class="modal-title" id="add-model-label">Add Model</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-3">
                    <form id="add-form" action="" method="POST">
                        @csrf
                        <div class="form-group">
                            <label><strong>{{ __('New Element') }}</strong></label>
                            <input wire:model="element" placeholder="Name..." id="add-name" name="name" type="text"
                                   class=" form-control"
                                   required>
                        </div>
                        <div class="text-right mt-3">
                            <button wire:click.prevent="resetProperty()" type="button" class="btn btn-light"
                                    data-dismiss="modal">Cancel
                            </button>
                            <button wire:click.prevent="store()" type="button" class="btn btn-primary"
                                    data-dismiss="modal">Add
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Delete modal -->
    <div wire:ignore class="modal fade" id="delete-model" tabindex="-1" role="dialog"
         aria-labelledby="delete-model-label"
         aria-hidden="true">
        <!-- Start modal-dialog -->
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <!-- Start modal-content -->
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h4 class="modal-title" id="delete-model-label">Delete Model</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-3">
                    <div class="form-group">
                        <p>Ary you Sure you want to delete this element ?</p>
                    </div>
                    <div class="text-right">
                        <button wire:click.prevent="resetProperty()" type="button" class="btn btn-light"
                                data-dismiss="modal">Cancel
                        </button>
                        <button wire:click.prevent="destroy()" type="button" class="btn btn-primary"
                                data-dismiss="modal">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Add New Datalist modal -->
    <div wire:ignore class="modal fade" id="add-dataList" tabindex="-1" role="dialog" aria-labelledby="add-model-label"
         aria-hidden="true">
        <!-- Start modal-dialog -->
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <!-- Start modal-content -->
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h4 class="modal-title" id="add-model-label">Add Model</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-3">
                    <form id="add-form" action="" method="POST">
                        @csrf
                        <div class="form-group">
                            <label><strong>{{ __('DataList Name') }}</strong></label>
                            <input wire:model="dataListName" type="text" class=" form-control"
                                   required>
                        </div>
                        <div class="form-group">
                            <label><strong>{{ __('Belong To') }}</strong></label>
                            <select wire:model="dataListTable" class="custom-select" required>
                                <option selected="">Select</option>
                                @foreach($tables as $table)
                                    <option value="{{$table}}">{{$table}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="text-right mt-3">
                            <button wire:click.prevent="resetProperty()" type="button" class="btn btn-light"
                                    data-dismiss="modal">Cancel
                            </button>
                            <button wire:click.prevent="storeDataList" type="button" class="btn btn-primary"
                                    data-dismiss="modal">Add
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

