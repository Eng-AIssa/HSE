<div class="row justify-content-center">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    @if(session('remove_success'))
        <div
            class="alert alert-warning alert-dismissible fade show "
            style="position: fixed; top: 80px; right: 10px; z-index: 1; padding: .35rem 3.9rem .35rem 1.2rem;"
            role="alert">
            <i class="mdi mdi-alert-circle-check-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500;">{{session('remove_success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 justify-content-start d-flex">
        <h3 class="ml-3 mb-4">{{ __('Personal Injury') }} </h3>
    </div>


    <form wire:key="personal-form" wire:submit.prevent="store()"
          class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form"
          id="personal-form">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <h5 class=" bg-light p-1 pl-2 mb-3" wire:key="employeeSection"
            style="display: flex; justify-content: space-between; align-items: center;" id="employee-information">
            {{ __('Injured Employee Information') }}
            <div x-data="{sectionState:@entangle('toggleEmployee').defer}">
                <span x-show="sectionState=='closed'" class="pr-1">{{ __('Add') }}</span>
                <span x-show="sectionState=='closed'" @click="sectionState='opened'" wire:ignore>
                <i data-feather="plus-square" class="icon-dual icons-md clicky"></i></span>

                <span x-show="sectionState=='opened'" class="pr-1">{{ __('Remove') }}</span>
                <span x-show="sectionState=='opened'" @click="sectionState='closed'" wire:ignore>
                <i data-feather="minus-square" class="icon-dual icons-md clicky"></i></span>
            </div>
        </h5>


        <div wire:key="employeeInfo" class="row hide employee-information-section" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.employee_id"
                                   label="{{ __('Employee ID') }}"
                                   name="employee_id" maxlength="10"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.employee_name"
                                   label="{{ __('Employee Name') }}"
                                   name="employee_name"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.employee_age"
                                   label="{{ __('Age') }}" type="number" min="0"
                                   name="employee_age"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.employee_department"
                                   label="{{ __('Department') }}"
                                   name="employee_department" maxlength="10"/>
            </div>

            <div class="col-12 col-md-6">
                <div wire:key="genderContainer" class="row mt-2 mb-3 ">
                    <label class="col-12">{{ __('Gender') }}<span class="text-danger pl-1">*</span></label>

                    <div class="col-6 pl-3 radio radio-primary">
                        <x-form.radioButton wire:key="gender-male" wire:model.defer="personal.employee_gender"
                                            label="{{ __('Male') }}"
                                            name="gender" id="male" value="male"/>
                    </div>

                    <div class="col-6 pl-2 radio radio-primary ">
                        <x-form.radioButton wire:key="gender-female" wire:model.defer="personal.employee_gender"
                                            label="{{ __('Female') }}"
                                            name="gender" id="female" value="female"/>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.employee_job_title"
                                   label="{{ __('Job Title') }}"
                                   name="employee_job_title"/>
            </div>
        </div>


        <h5 class=" bg-light p-1 pl-2 mb-3" wire:ignore wire:key="contractorSection"
            style="display: flex; justify-content: space-between; align-items: center;"
            id="contractor-information">
            {{ __('Injured Contractor Information') }}
            <div x-data="{sectionState:@entangle('toggleContractor').defer}">
                <span x-show="sectionState=='closed'" class="pr-1 ">{{ __('Add') }}</span>
                <span x-show="sectionState=='closed'" @click="sectionState='opened'" wire:ignore>
                <i data-feather="plus-square" class="icon-dual icons-md clicky"></i></span>

                <span x-show="sectionState=='opened'" class="pr-1 ">{{ __('Remove') }}</span>
                <span x-show="sectionState=='opened'" @click="sectionState='closed'" wire:ignore>
                <i data-feather="minus-square" class="icon-dual icons-md clicky"></i></span>
            </div>
        </h5>


        <div x-show="sectionState=='opened" class="row hide contractor-information-section" wire:ignore
             wire:key="contractorInfo">
            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.contractor_name"
                                   label="{{ __('Contractor Name') }}"
                                   name="contractor_name"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.contractor_job_title"
                                   label="{{ __('Job Title') }}"
                                   name="contractor_job_title"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.contractor_age"
                                   label="{{ __('Age') }}"
                                   type="number" min="0"
                                   name="contractor_age"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.contractor_department"
                                   label="{{ __('Department') }}"
                                   name="contractor_department"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.contractor_company"
                                   label="{{ __('Contractor Company') }}"
                                   name="contractor_company"/>
            </div>

        </div>


        <h5 wire:key="typeAndDescriptionSection" class=" bg-light p-2 mt-0 mb-3"
            wire:ignore>{{ __('Type & Description') }}</h5>

        <div wire:key="typeAndDescriptionInfo" class="row" wire:ignore>
            <div wire:key="typeInfo" class="col-6 ">
                <x-form.select-input wire:key="type" wire:model.defer="personal.type_of_injury"
                                     label="{{ __('Type of Injury') }}"
                                     name="injury_type"
                                     required='required' id="type-of-injury-list">
                    @foreach($datalist->where('name','Injury Type')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div wire:key="descriptionInfo" class="col-12 ">
                <x-form.textarea-input wire:model.defer="personal.injury_description" rows="3"
                                       label="{{ __('Injury Description') }}"
                                       name="description_of_injury" required='required'/>
            </div>
        </div>


        <h5 wire:key="injuryCategorySection" class=" bg-light p-2 mt-0 mb-3 injury-category-checkboxes hide"
            wire:ignore>{{ __('Injury Category') }}</h5>

        <div wire:key="injuryCategoryInfo" class="row mb-2 ml-1 injury-category-checkboxes hide" wire:ignore>
            <div class="col-12 mb-2">
                <div class="icon-item font-16" id="injuryCategoryHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Choose Category') }}</span>
                    <span class="pl-1 text-danger">*</span>
                </div>
            </div>

            <div class="col-6 col-sm-6 col-md-4 pl-3 injuryCategoryElement">
                <x-form.radioButton wire:model.defer="personal.injury_category"
                                    label="{{ __('FAC') }}"
                                    id="fac-1" name="injury_category"/>

                <x-form.radioButton wire:model.defer="personal.injury_category"
                                    label="{{ __('MTC') }}"
                                    id="mtc-2" name="injury_category"/>
            </div>

            <div class="col-6 col-sm-6 col-md-4 pl-3 injuryCategoryElement">
                <x-form.radioButton wire:model.defer="personal.injury_category"
                                    label="{{ __('RWC') }}"
                                    id="rwc-3" name="injury_category"/>

                <x-form.radioButton wire:model.defer="personal.injury_category"
                                    label="{{ __('LTI') }}"
                                    id="lti-4" name="injury_category"/>
            </div>

            <div class="col-6 col-sm-6 col-md-4 pl-3 injuryCategoryElement">
                <x-form.radioButton wire:model.defer="personal.injury_category"
                                    label="{{ __('Fatality') }}"
                                    id="fatality-5" name="injury_category"/>

            </div>
        </div>


        <h5 wire:key="injuryTypeSection" class=" bg-light p-2 mt-0 mb-3 injury-type-checkboxes hide"
            wire:ignore>{{ __('Injury Type') }}</h5>

        <div wire:key="injuryTypeInfo" class="row my-3 ml-1 dropdown checkboxes-container injury-type-checkboxes hide"
             wire:ignore>

            <div class="col-12 " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="icon-item font-16" id="injury-type-heading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Injury Type') }}</span>
                    <span class="pl-1 text-danger">*</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up " style="width: 95%">

                    <div class="col-12 col-sm-6 col-md-4 ">
                        <x-form.checkbox wire:model.defer="personal.injury_type.1"
                                         label="{{ __('Amputation') }}"
                                         id="amputation-1" name="injury_type"/>

                        <x-form.checkbox wire:model.defer="personal.injury_type.2"
                                         label="{{ __('Crushing') }}"
                                         id="crushing-2" name="injury_type"/>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3 ">
                        <x-form.checkbox wire:model.defer="personal.injury_type.3"
                                         label="{{ __('MSD') }}"
                                         id="msd-3" name="injury_type"/>

                        <x-form.checkbox wire:model.defer="personal.injury_type.4"
                                         label="{{ __('Strains') }}"
                                         id="strains-4" name="injury_type"/>
                    </div>

                    <div class="col-12 col-sm-6 col-md-5">
                        <x-form.checkbox wire:model.defer="personal.injury_type.5"
                                         label="{{ __('Blow / Compression') }}"
                                         id="blow-5" name="injury_type"/>

                        <x-form.checkbox wire:model.defer="personal.injury_type.6"
                                         label="{{ __('Broken Bones') }}"
                                         id="brokenBones-6" name="injury_type"/>
                    </div>
                </div>
            </div>
        </div>

        <h5 wire:key="IllnessTypeSection" class=" bg-light p-2 mt-0 mb-3 illness-type-checkboxes hide"
            wire:ignore>{{ __('Illness Type') }}</h5>

        <div wire:key="IllnessTypeInfo" class="row my-3 ml-1 dropdown checkboxes-container illness-type-checkboxes hide"
             wire:ignore>
            <div class="col-12 " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="icon-item font-16" id="typeOfIllnessHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Illness Type') }}</span>
                    <span class="pl-1 text-danger">*</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up">

                    <div class="col-12 col-sm-6 col-md-4 ">
                        <x-form.checkbox wire:model.defer="personal.illness_type.1"
                                         label="{{ __('Skin Disorder') }}"
                                         id="skinDisorder-1" name="illness_type"/>

                        <x-form.checkbox wire:model.defer="personal.illness_type.2"
                                         label="{{ __('Poisoning') }}"
                                         id="poisoning-2" name="illness_type"/>
                    </div>

                    <div class="col-12 col-sm-6 col-md-4 ">
                        <x-form.checkbox wire:model.defer="personal.illness_type.3"
                                         label="{{ __('Hearing Loss') }}"
                                         id="hearingLoss-3" name="illness_type"/>

                        <x-form.checkbox wire:model.defer="personal.illness_type.4"
                                         label="{{ __('Heat Stress') }}"
                                         id="heatStress-4" name="illness_type"/>
                    </div>

                    <div class="col-12 col-sm-6 col-md-4 ">
                        <x-form.checkbox wire:model.defer="personal.illness_type.5"
                                         label="{{ __('Acute Illness') }}"
                                         id="acuteIllness-5" name="illness_type"/>

                        <x-form.checkbox wire:model.defer="personal.illness_type.6"
                                         label="{{ __('All Other Diseases') }}"
                                         id="allOtherDiseases-6" name="illness_type"/>
                    </div>

                    <div class="col-5 ">
                        <x-form.checkbox wire:model.defer="personal.illness_type.7"
                                         label="{{ __('Respiratory Condition') }}"
                                         id="respiratoryCondition-7" name="illness_type"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 wire:key="harmedSection" class=" bg-light p-2 mt-0 mb-3" wire:ignore>{{ __('Harmed Body Parts') }}</h5>

        <div wire:key="harmedInfo" class="row my-3 ml-1 dropdown checkboxes-container" wire:ignore>

            <div class="col-12 " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="icon-item font-16" id="partsOfBodyHarmedHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Body Parts') }}</span>
                    <span class="pl-1 text-danger">*</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up">
                    <div class="col-6 col-sm-4  ">
                        <x-form.checkbox wire:model.defer="personal.harmed_body_parts.1"
                                         label="{{ __('Hands') }}"
                                         id="hands-1" name="harmed_body_parts"/>

                        <x-form.checkbox wire:model.defer="personal.harmed_body_parts.2"
                                         label="{{ __('Ankle') }}"
                                         id="ankle-2" name="harmed_body_parts"/>
                    </div>

                    <div class="col-6 col-sm-4 ">
                        <x-form.checkbox wire:model.defer="personal.harmed_body_parts.3"
                                         label="{{ __('Leg') }}"
                                         id="leg-3" name="harmed_body_parts"/>

                        <x-form.checkbox wire:model.defer="personal.harmed_body_parts.4"
                                         label="{{ __('Face') }}"
                                         id="face-4" name="harmed_body_parts"/>
                    </div>

                    <div class="col-6 col-sm-4 ">
                        <x-form.checkbox wire:model.defer="personal.harmed_body_parts.5"
                                         label="{{ __('Eyes') }}"
                                         id="eyes-5" name="harmed_body_parts"/>

                    </div>
                </div>
            </div>
        </div>


        <h5 wire:key="reasonSection" class=" bg-light p-2 mt-0 mb-3">{{ __('Reason of Injury or Illness') }}</h5>

        <div wire:key="reasonInfo" class="row my-3 ml-1 dropdown checkboxes-container" wire:ignore>

            <div class="col-12 " data-toggle="dropdown" aria-haspopup="true"
                 aria-expanded="false">
                <div class="icon-item font-16" id="reasonOfInjuryOrIllnessHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Reasons') }}</span>
                    <span class="pl-1 text-danger">*</span>
                </div>
            </div>
            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up">

                    <div class="col-6 col-md-4">
                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.1"
                                         label="{{ __('Heat Stress') }}"
                                         id="heatStress2-1" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.2"
                                         label="{{ __('High Noise') }}"
                                         id="highNoise-2" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.3"
                                         label="{{ __('Chemical Exposure') }}"
                                         id="chemicalExposure-3" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.4"
                                         label="{{ __('Hitting by an Object') }}"
                                         id="hittingByAnObject-4" name="reason_of_injury_or_illness"/>
                    </div>

                    <div class="col-6 col-md-4">
                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.5"
                                         label="{{ __('Radiation') }}"
                                         id="radiation-5" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.6"
                                         label="{{ __('Electrocution') }}"
                                         id="electrocution-6" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.7"
                                         label="{{ __('High Vibration') }}"
                                         id="highVibration-7" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.8"
                                         label="{{ __('Dust Exposure') }}"
                                         id="dustExposure-8" name="reason_of_injury_or_illness"/>
                    </div>

                    <div class="col-12 col-sm-6 col-md-4">
                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.9"
                                         label="{{ __('Hot Surfaces') }}"
                                         id="hotSurfaces-9" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.10"
                                         label="{{ __('Fall from height') }}"
                                         id="fallFromHeight-10" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.11"
                                         label="{{ __('Unhygienic') }}"
                                         id="unhygienic-11" name="reason_of_injury_or_illness"/>

                        <x-form.checkbox wire:model.defer="personal.reason_of_injury_or_illness.12"
                                         label="{{ __('Ergonomics') }}"
                                         id="ergonomics-12" name="reason_of_injury_or_illness"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 wire:key="treatmentSection" class=" bg-light p-2 mt-0 mb-3"
            wire:ignore>{{ __('Treatment Information') }}</h5>

        <div x-data="{isJobTransfer:@entangle('isJobTransfer').defer}" wire:key="treatmentInfo" class="row" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="personal.treatment_date" max="{{date('Y-m-d')}}"
                                   required='required'
                                   label="{{ __('Treatment Date') }}" name="treatment_date"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="personal.diagnosis_date" max="{{date('Y-m-d')}}"
                                   required='required'
                                   label="{{ __('Diagnosis Date') }}" name="diagnosis_date"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.date-input wire:model.defer="personal.return_to_work_date" min="{{date('Y-m-d')}}"
                                   required='required'
                                   label="{{ __('Return to Work Date') }}" name="return_to_work_date"/>
            </div>

            <div class="col-12 col-md-6">
                <x-form.text-input wire:model.defer="personal.numbers_of_days_away_from_work"
                                   label="{{ __('Numbers of Days Away From Work') }}"
                                   name="days_away_from_work" type="number" min="0"/>
            </div>

            <div class="col-12">


                <div class="row mt-2 mb-3 ">
                    <label class="col-12">{{ __('Job Transfer') }} <span class="ml-1 text-danger">*</span></label>

                    <div class="col-3 pl-3 ">
                        <x-form.radioButton @click="isJobTransfer='yes'"
                                            wire:model.defer="personal.is_job_transfer"
                                            wire:key="job-transfer-yes"
                                            label="{{ __('Yes') }}"
                                            name="job_transfer" id="job-transfer-yes"
                                            value="1" required="required"/>
                    </div>

                    <div class="col-3 pl-2 ">
                        <x-form.radioButton @click="isJobTransfer='no'"
                                            wire:model.defer="personal.is_job_transfer"
                                            wire:key="job-transfer-no"
                                            label="{{ __('No') }}"
                                            name="job_transfer" id="job-transfer-no"
                                            value="0"/>
                    </div>
                </div>


            </div>

            <div x-show="isJobTransfer=='yes'" x-transition.duration.500ms class="col-12 job-transfer-container ">
                <x-form.textarea-input wire:model.defer="personal.restriction_post_injury"
                                       label="{{ __('Restriction Post Injury') }}" rows="2"
                                       name="restriction_post_injury"/>
            </div>

            <div x-show="isJobTransfer=='yes'" x-transition.duration.500ms class="col-12 job-transfer-container">
                <x-form.text-input wire:model.defer="personal.number_of_light_duty_days"
                                   label="{{ __('Numbers of Light Duty Days') }}"
                                   name="end_date_for_rest" type="number" min="0"/>
            </div>

            <div class="col-12">
                <x-form.textarea-input wire:model.defer="personal.doctor_remark"
                                       label="{{ __('Doctor Remarks') }}"
                                       name="doctor_remarks" rows="2"
                                       required="required"/>
            </div>
        </div>


    </form>


    <div wire:key="attachment-section" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 ">

        <h5 wire:key="attachment-heading" class=" bg-light p-2 mt-0 mb-3">{{ __('Attachment & Documents') }}</h5>

        <x-form.file-input/>

        @if($added_injuries)
            <h5 class=" bg-light p-2 mt-0 mt-3">{{ __('Added Injuries') }}</h5>


            <div class="table-responsive">
                <table class="table table-bordered my-2">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>{{ __('Injured ID') }}</th>
                        <th>{{ __('Injured Name') }}</th>
                        <th>{{ __('Injured Department') }}</th>
                        <th>{{ __('Injury') }}</th>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('View') }}</th>
                        <th>{{ __('delete') }}</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($added_injuries as $key => $injury)
                        <tr class="text-center " wire:key="row-of-add-injuries-{{$loop->index}}">
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$injury[0] == 'employee' ? $injury[1]['employee_id'] : '' }}</td>
                            <td>{{$injury[0] == 'employee' ? $injury[1]['employee_name'] : $injury[1]['contractor_name'] }}</td>
                            <td>{{$injury[0] == 'employee' ? $injury[1]['employee_department'] : $injury[1]['contractor_department'] }}</td>

                            <td>
                                @if($injury[1]['type_of_injury'] == 'Injury')
                                    @foreach ($injury[1]['injury_type'] as $inj)
                                        <span>{{$inj}},</span>
                                    @endforeach
                                @else
                                    @foreach($injury[1]['illness_type'] as $illness)
                                        <span>{{$illness}},</span>
                                    @endforeach
                                @endif
                            </td>

                            <td> {{ $injury[1]['treatment_date'] }} </td>

                            <td style="padding: 5px;">
                                <button wire:click="$emit('control_modal',{{$loop->index}} , 'show')" type="button"
                                        class="btn btn-blue">
                                    {{ __('View') }}
                                </button>
                                <x-modal.show-personal-Injury :id="$loop->index" :personalInjury="$injury[1]"
                                                              :type="$injury[0]"/>
                            </td>
                            <td style="padding: 5px;">
                                <button wire:click="remove({{$loop->index}})" type="button" class="btn btn-danger">
                                    {{ __('Remove') }}
                                </button>
                            </td>
                        </tr>


                    @endforeach

                    </tbody>
                </table>
            </div>
        @endif

        <div class="row justify-content-end">
            <x-form.button wire:click="$set('submit', 'true')" id="my-secret-btn2" form="personal-form" class="m-1"
                           label="Submit & Go Home"/>
            <x-form.button id="my-secret-btn" form="personal-form" class="m-1" label="{{ __('Add New Injury')}}"/>
        </div>
    </div>
</div>

@push('scripts')

    <script type="text/javascript">

        $('#personal-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                $('#upload').click();
            })


            Livewire.on('control_modal', (id, action) => {
                if (action === 'hide')
                    $('#personalInjury-modal-' + id).modal('hide');
                else if (action === 'show') {
                    $('#personalInjury-modal-' + id).modal('show');
                }
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                //reset employee & Contractor sections fields to not required after saving
                $('.employee-information-section').find('input').prop('required', false);
                $('.contractor-information-section').find('input').prop('required', false);

                //reset values, remove generated elements, hide shown elements which their base state is to be hidden
                $('.result-container').hide().find('span').remove();
                $('.employee-information-section').hide();
                $('.contractor-information-section').hide();
                $('.injury-category-checkboxes').hide();
                $('.injuryCategoryElement').hide();
                $('.hijri').html('')
                $('.injury-type-checkboxes').hide();
                $('.illness-type-checkboxes').hide();
                $('.job-transfer-container').hide();
                $('#file-previews .card').remove();


                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                    }, 6000);
                });


            });


        });
    </script>



    {{-- handle checkbox lists style and dynamic adding and removing --}}
    <script>

        $('.checkbox').on('change', function () {
            let checkboxes_result_container = $(this).parents('.checkboxes-container').find('.result-container');

            // if checkbox is checked
            if ($(this).prop('checked') === true) {

                // create span to hold the value of the checked checkbox
                let span_element = $("<span id='" + $(this).attr('id') + "2' class=' bg-light rounded' style='display: inline-block; margin:5px 5px 0 5px; padding: 5px 10px; font-size: 0.74rem;'></span>");

                // create small exit icon with 'x' sign to remove span manually if desired
                let small_quite = $("<small class='clicky ml-2 ' onclick='smallQuite(this)'>x</small>")

                // add checked checkbox value to the created span and attach the created close icon
                span_element.text($(this).val()).append(small_quite);

                // show the results container to hold the created span
                checkboxes_result_container.fadeIn(1000);

                // add the created spans to results container
                checkboxes_result_container.append(span_element);

                // else if the checkbox was unchecked
            } else {

                // remove span which is related to unchecked checkbox
                $('#' + $(this).attr('id') + '2').remove();

                // hide the results container if no spans left to show
                if (!checkboxes_result_container.find('span').html())
                    checkboxes_result_container.fadeOut(1000);
            }
        });


        // function to handle the click event on span's close icon
        function smallQuite(me) {
            let checkbox = $(me).parent('span').attr('id');
            let result_container = $(me).parents('.result-container');
            let checkbox_id = $('#' + checkbox.slice(0, -1));


            Livewire.emit('unsetCheckboxValue', checkbox.slice(0, -1).split("-")[1], checkbox_id.attr('name').slice(0, -2));

            // uncheck the checkbox related to removed span
            checkbox_id.prop("checked", false);

            // hide the result container if there is no spans left to show( -1 in the if statement represent the span which will be removed after the if)
            if (!(result_container.find('span').length - 1 > 0)) {
                result_container.fadeOut(1000);
            }

            // remove the span
            $('#' + checkbox).remove();
        }


        $('.dropdown-menu').on('click', function (e) {
            e.stopPropagation();
        });


    </script>


@endpush
