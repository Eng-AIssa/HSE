<div class="row justify-content-center">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 justify-content-start d-flex">
        <h3 class="ml-3 mb-4">{{ __('Asset Damage') }} </h3>
    </div>


    <form wire:submit.prevent="storeAssetDamage()"
          class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form"
          id="asset-form" action="" method="POST">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Asset Information') }}</h5>

        <div class="row mb-3" wire:ignore>
            <div class="col-12 col-md-6 mb-md-0 mb-3">
                <x-form.select-input wire:model.defer="asset.equipment_tag"
                                     label="{{ __('Equipment/Asset Tag') }}"
                                     class="equipment-tage js-select"
                                     required="required" name="equipment_tag">
                    @foreach($datalist->firstwhere('name','Equipment/Asset Tag')->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6 mb-md-0 mb-3">
                <x-form.text-input {{--wire:model.defer="asset.equipment_description"--}}
                                   label="{{ __('Equipment/Asset Description') }}"
                                   placeholder="Description" readonly="readonly"
                                   name="equipment_description" id="equipment-description"/>
            </div>

        </div>


        <div class="row mb-3" wire:ignore>
            <div class="col-12 col-md-6  ">
                <div class="row ml-1">
                    <label class="font-weight-bold">{{ __('Any Person Exposed?')}}<span
                            class="pl-1 text-danger">*</span></label>
                </div>
                <div class="row  ml-3 mt-1">
                    <x-form.radioButton wire:model.defer="asset.was_any_person_exposed"
                                        label="{{ __('Yes') }}" id="exposed-person-yes"
                                        name="exposed_person" value="1" required="required"/>

                    <x-form.radioButton wire:model.defer="asset.was_any_person_exposed"
                                        label="{{ __('No') }}" id="exposed-person-no"
                                        name="exposed_person" class="ml-3" value="0"/>
                </div>
            </div>

            <div class="col-12 col-md-6 mt-3 mt-md-0">
                <div class="row hide" id="involved-employee-container"
                     style="margin-top: -15px; margin-bottom: -10px;">
                    <div class="col-12  hide " id="involved-employee">
                        <x-form.select-input wire:model.defer="asset.employee_involved"
                                             label="{{ __('Employee/Contractor Involved') }}"
                                             name="employee_involved" id="employee-involved"
                                             mb="0" class="js-select">
                            @foreach($users as $user)
                                <option value="{{$user->name}}">{{$user->name}}</option>
                            @endforeach
                            <option value="Other">Other</option>
                        </x-form.select-input>
                    </div>

                    <div class="col-12  hide" id="employee-involved-manual">
                        <x-form.text-input wire:model.defer="asset.employee_involved_manual"
                                           label="" style="margin-top: -15px;"
                                           name="employeeInvolved"
                                           placeholder="{{ __('Write Employee Name') }}"
                                           mb="0"/>
                    </div>
                </div>
            </div>

        </div>


        <div class="row mb-2">
            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model="asset.location_id" wire:ignore
                                     label="{{ __('Location') }}" mb="1"
                                     required='required' name="location_id">
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="asset.area_id" wire:ignore.self
                                     required='required' label="{{ __('Area') }}"
                                     name="area_id" mb="1">
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.text-input wire:model.defer="asset.location_details" wire:ignore
                                   label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details" mb="1"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Influencing Factors') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="asset.human_factor"
                                     label="{{ __('Human Factor') }}" name="human_factor">
                    @foreach($datalist->where('name','Human Factor')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="asset.nature_factor"
                                     label="{{ __('Nature Factor') }}" name="nature_factor">
                    @foreach($datalist->where('name','Nature Factor')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>

        <div class="row" wire:ignore>
            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="asset.external_factor"
                                     label="{{ __('External Factor') }}" name="externalFactor"
                                     required="required">
                    @foreach($datalist->where('name','External Factor')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-md-6">
                <x-form.select-input wire:model.defer="asset.factor_led_to_asset_damage"
                                     label="{{ __('Factor led to Asset Damage') }}"
                                     name="factorsLeadingToIncident"
                                     required="required">
                    @foreach($datalist->where('name','Factors Leading to Asset Damage')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3"> {{ __('Asset Type') }}</h5>

        <div class="row my-3 ml-1 dropdown checkboxes-container" wire:ignore>

            <div class="col-12 " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="icon-item font-16" id="typeOfAssetHeading">
                    <i data-feather="plus-circle" class="icon-dual-blue icons-md clicky"></i>
                    <span class="clicky">{{ __('Add Types') }}</span>
                </div>
            </div>

            <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
                 style="min-height: 2.2rem;">

            </div>

            <div class="col-12">
                <div class="dropdown-menu checkboxes-pop-up" style="width: 70%;">

                    <div class="col-12 col-md-6  ">
                        <x-form.checkbox wire:model.defer="asset.asset_type.1"
                                         label="{{ __('Plant Equipment') }}" id="plant-equipment-1"
                                         name="asset_type"/>

                        <x-form.checkbox wire:model.defer="asset.asset_type.2"
                                         label="{{ __('Material / Product') }}" id="material-2"
                                         name="asset_type"/>
                    </div>
                    <div class="col-12 col-md-6  ">
                        <x-form.checkbox wire:model.defer="asset.asset_type.3"
                                         label="{{ __('Plant Civil Structure') }}" id="plant-civil-3"
                                         name="asset_type"/>

                        <x-form.checkbox wire:model.defer="asset.asset_type.4"
                                         label="{{ __('Vehicle') }}" id="vehicle-4"
                                         name="asset_type"/>
                    </div>
                </div>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Cost Category') }}</h5>


        <div class="row  mb-2 pl-1" wire:ignore>
            <div class="col-6  ">
                <x-form.checkbox wire:model.defer="asset.direct_cost_check"
                                 label="{{ __('Direct Cost') }}" value="direct"
                                 id="direct-cost-checkbox" name="cost_type"/>
            </div>

            <div class="col-6  ">
                <x-form.checkbox wire:model.defer="asset.indirect_cost_check"
                                 label="{{ __('Indirect Cost') }}" value="indirect"
                                 id="indirect-cost-checkbox" name="cost_type"/>
            </div>
        </div>

        <div class="row mb-2 " wire:ignore>

            <div class="col-12 col-md-6 mb-2">
                <div class="row">
                    <div class="col-12 hide ml-1" id="direct-cost">
                        <x-form.select-input wire:model.defer="asset.direct_cost"
                                             label="{{ __('Direct Cost') }}"
                                             name="direct_cost" mb="0" id="direct-list">
                            @foreach($datalist->firstwhere('name', 'Direct Cost')->content as $item)
                                <option value="{{$item}}">{{$item}}</option>
                            @endforeach
                        </x-form.select-input>
                    </div>

                    <div class="col-8 ml-1 hide" id="direct-cost-amount-container">
                        <x-form.text-input wire:model.defer="asset.direct_cost_amount"
                                           style="margin-top: -10px;" class="placeholder-style"
                                           placeholder="{{ __('in $') }}" mb="0" id="direct-cost-amount"
                                           disabled="disabled" type="number" min="0"/>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 mb-2">
                <div class="row">
                    <div class="col-12 hide" id="indirect-cost">
                        <x-form.select-input wire:model.defer="asset.indirect_cost"
                                             label="{{ __('Indirect Cost') }}"
                                             name="indirect_cost" mb="0" id="indirect-list">
                            @foreach($datalist->firstwhere('name', 'Indirect Cost')->content as $item)
                                <option value="{{$item}}">{{$item}}</option>
                            @endforeach
                        </x-form.select-input>
                    </div>

                    <div class="col-8  hide" id="indirect-cost-amount-container">
                        <x-form.text-input wire:model.defer="asset.indirect_cost_amount"
                                           style="margin-top: -10px;" class="placeholder-style"
                                           placeholder="{{ __('in $') }}" id="indirect-cost-amount" mb="0"
                                           disabled="disabled" type="number" min="0"/>
                    </div>
                </div>
            </div>


            <div class="col-12 hide mt-2" id="total-cost-container">
                <x-form.text-input label="{{ __('Total Equipment Damaged Cost $') }}"
                                   name="equipmentDamagedWorth"
                                   readonly="readonly" id="total-cost"/>
            </div>
        </div>


    </form>


    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} ">
        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Attachment & Documents') }}</h5>

        <x-form.file-input/>


        <div class="row justify-content-end">
            <x-form.button form="asset-form" id="my-secret-btn" class="m-1" label="{{ __('Submit')}}"/>
        </div>
    </div>
</div>




@push('scripts')

    <script>

        $('#asset-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        //initialize users select input as select2 elements to enable search
        // and send chosen value to backend on change
        $(document).ready(function () {
            let select = $('.js-select');
            select.select2({
                placeholder: "Select",
            });
            select.on('change', function (e) {
            @this.set('asset.' + e.target.name, e.target.value);
            });
        });
    </script>



    <script>
        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                $('#upload').click();
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');
                $('.equipment-tage').parent('div').find('.select2-selection').css('background-color', '#fff');

                //reset values, remove generated elements, hide shown elements
                $('.result-container').hide().find('span').remove();
                $('#involved-employee').hide();
                $('#employee-involved-manual').val('').hide();
                $('#direct-cost').val('').hide();
                $('#direct-cost-amount-container').hide();
                $('#direct-cost-amount').prop('disabled', true);
                $('#indirect-cost').val('').hide();
                $('#indirect-cost-amount-container').hide();
                $('#indirect-cost-amount').prop('disabled', true);
                $('#total-cost-container').hide();
                $('#file-previews .card').remove();

                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                        $('.js-select').val(null).trigger('change');
                        $('#equipment-description').val('');
                    }, 6000);
                });


            });

        })
    </script>



    {{-- handle checkbox lists style and dynamic adding and removing --}}
    <script>

        $('.checkbox').on('change', function () {
            let checkboxes_result_container = $(this).parents('.checkboxes-container').find('.result-container');

            // if checkbox is checked
            if ($(this).prop('checked') === true) {

                // create span to hold the value of the checked checkbox
                let span_element = $("<span id='" + $(this).attr('id') + "2' class=' bg-light rounded' style='display: inline-block; margin:5px 5px 0 5px; padding: 5px 10px; font-size: 0.74rem;'></span>");

                // create small exit icon with 'x' sign to remove span manually if desired
                let small_quite = $("<small class='clicky ml-2 ' onclick='smallQuite(this)'>x</small>")

                // add checked checkbox value to the created span and attach the created close icon
                span_element.text($(this).val()).append(small_quite);

                // show the results container to hold the created span
                checkboxes_result_container.fadeIn(1000);

                // add the created spans to results container
                checkboxes_result_container.append(span_element);

                // else if the checkbox was unchecked
            } else {

                // remove span which is related to unchecked checkbox
                $('#' + $(this).attr('id') + '2').remove();

                // hide the results container if no spans left to show
                if (!checkboxes_result_container.find('span').html())
                    checkboxes_result_container.fadeOut(1000);
            }
        });


        // function to handle the click event on span's close icon
        function smallQuite(me) {
            let checkbox = $(me).parent('span').attr('id');
            let result_container = $(me).parents('.result-container');
            let checkbox_id = $('#' + checkbox.slice(0, -1));

            Livewire.emit('unsetCheckboxValue', checkbox.slice(-2, -1), checkbox_id.attr('name').slice(0, -2));

            // uncheck the checkbox related to removed span
            checkbox_id.prop("checked", false);

            // hide the result container if there is no spans left to show( -1 in the if statement represent the span which will be removed after the if)
            if (!(result_container.find('span').length - 1 > 0)) {
                result_container.fadeOut(1000);
            }

            // remove the span
            $('#' + checkbox).remove();
        }


        $('.dropdown-menu').on('click', function (e) {
            e.stopPropagation();
        });


    </script>


@endpush
