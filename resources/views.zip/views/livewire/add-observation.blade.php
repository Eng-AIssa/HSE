<div class="row justify-content-center">


    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
        <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Observation') }}
            # {{$object->id ?? ''}} </h3>
    </div>
    <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
         style="display: flex;">
        <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-2 ml-2 ml-sm-0">
            <h3 class="">{{ __('Status:') }}</h3>
            <p class=" ml-2  font-20" style="padding-top: 0.6rem;">{{ __('Initiation') }}</p>
        </div>
    </div>


    <form wire:submit.prevent="store" id="observation-form" class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} mt-2 reporting-form"
          action=""
          method="">
        @csrf

        <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>


        <x-form.workflow/>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Category & Title') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model="observation.category"
                                     label="{{ __('Category') }}"
                                     name="category" required='required'>
                    @foreach($datalist->where('name','Category')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="observation.sub_category"
                                     label="{{ __('Sub Category') }}" required='required'
                                     name="sub_category" id="sub-category">
                    @foreach($datalist->where('name','Sub Category')->first()->content as $item )
                        <option value="{{$item}}">{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>


            <div class="col-12 ">
                <x-form.text-input wire:model.defer="observation.title"
                                   label="{{ __('Title') }}" mb="3"
                                   name="title" id="title"
                    {{--required='required'--}}/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Time & Location') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.date-input wire:model.defer="observation.observation_date"
                                   label="{{ __('Observation Date') }}"
                                   id="observation-date" name="observation_date"
                                   max="{{date('Y-m-d')}}" required='required'/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.time-input wire:model.defer="observation.observation_time"
                                   label="{{ __('Observation Time') }}"
                                   name="observation_time" required='required'/>
            </div>
        </div>


        <div class="row">
            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.select-input wire:model="observation.location_id"
                                     label="{{ __('Location') }}"
                                     name="location_id" required='required'>
                    @foreach($locations as $location)
                        <option value="{{$location->id}}">{{ $location->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4">
                <x-form.select-input wire:model.defer="observation.area_id"
                                     wire:ignore.self
                                     label="{{ __('Area') }}"
                                     name="area_id" required='required'>
                    @foreach($areas as $area)
                        <option value="{{$area->id}}">{{ $area->name }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6 col-xl-4" wire:ignore>
                <x-form.text-input wire:model.defer="observation.location_details"
                                   label="{{ __('-') }}"
                                   placeholder="{{ __('Further Details') }}"
                                   name="location_details"/>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Observation Data') }}</h5>

        <div class="row" wire:ignore>
            <div class="col-12 ">
                <x-form.textarea-input wire:model.defer="observation.observation_description"
                                       label="{{ __('Observation Description') }}"
                                       name="observation_description" required='required'/>
            </div>

            <div class="col-12">
                <x-form.textarea-input wire:model.defer="observation.immediate_action_taken"
                                       label="{{ __('Immediate Action Taken') }}"
                                       rows="2" required='required'
                                       id="action-taken" name="immediate_action_taken"/>
            </div>
        </div>

        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Potential Consequences') }}</h5>


        <div class="row mb-3 pl-2" wire:ignore>
            <div class="col-4">
                <x-form.checkbox wire:model.defer="observation.people_potential_consequences_checkbox"
                                 label="{{ __('People') }}" value="1"
                                 id="people-checkbox" name="people_checkbox"/>
            </div>

            <div class="col-4">
                <x-form.checkbox wire:model.defer="observation.environment_potential_consequences_checkbox"
                                 label="{{ __('Environment') }}" value="1"
                                 id="environment-checkbox" name="environment_checkbox"/>
            </div>

            <div class="col-4 col-md">
                <x-form.checkbox wire:model.defer="observation.asset_potential_consequences_checkbox"
                                 label="{{ __('Asset and Production Loss') }}" value="1"
                                 id="cost-checkbox" name="asset_checkbox"/>
            </div>
        </div>


        <div class="row " id="potential-consequences-container " wire:ignore>
            <div class="col-12 hide" id="people-potential-consequences-container">
                <x-form.select-input wire:model.defer="observation.people_potential_consequences"
                                     label="{{ __('People') }}" {{--required='required'--}}
                                     name="people_potential_consequences"
                                     id="people-potential-consequences-list">
                    @foreach($datalist->where('name','Potential Consequences People')->first()->content as $item )
                        <option>{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 hide" id="environment-potential-consequences-container">
                <x-form.select-input wire:model.defer="observation.environment_potential_consequences"
                                     label="{{ __('Environment') }}" {{--required='required'--}}
                                     name="environment_potential_consequences"
                                     id="environment-potential-consequences-list">
                    @foreach($datalist->where('name','Potential Consequences Environment')->first()->content as $item )
                        <option>{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 hide" id="asset-potential-consequences-container">
                <x-form.select-input wire:model.defer="observation.asset_potential_consequences"
                                     label="{{ __('Asset and Production Lost') }}" {{--required='required'--}}
                                     name="asset_potential_consequences"
                                     id="asset-potential-consequences-list">
                    @foreach($datalist->where('name','Potential Consequences Cost')->first()->content as $item )
                        <option>{{ $item }}</option>
                    @endforeach
                </x-form.select-input>
            </div>
        </div>


        <h5 class=" bg-light p-2 mt-0 mb-3">{{ __('Related People') }}</h5>

        <div class="row mb-1" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.text-input label="{{ __('Reported By') }}" users="users"
                                   placeholder="{{ __('Name') }} " mb="0" disabled="disabled"
                                   value="{{Auth::user()->name}}" name="reported_by"
                                   required='required'/>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                   value="{{Auth::user()->department}}" disabled="disabled"/>
            </div>
        </div>


        <div class="row" wire:ignore>
            <div class="col-12 col-sm-6">
                <x-form.select-input wire:model.defer="observation.responsible_person"
                                     label="{{ __('Responsible Person') }}" mb="0" users="users"
                                     placeholder="{{ __('Name') }}" name="responsible_person"
                                     required='required' class="js-select">
                    @foreach($users as $user)
                        <option value="{{$user->id}}">{{$user->name}}</option>
                    @endforeach
                </x-form.select-input>
            </div>

            <div class="col-12 col-sm-6">
                <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                   disabled="disabled"/>
            </div>
        </div>


    </form>

    <div class="col-sm-11 {{--col-xl-11--}} {{--ml-2 ml-sm-3--}} " wire:ignore>
        <h5 class=" bg-light p-2 mt-0 mb-3"> {{ __('Comments & Attachments') }} </h5>

        <x-form.textarea-input wire:model.defer="observation.comment"
                               rows="2" label="{{ __('Comments') }}" name="comment"/>


        <x-form.file-input/>


        <div class="row justify-content-end btns">
            <x-form.button form="observation-form" id="my-secret-btn" label="{{ __('Submit') }}" class="m-1"/>
        </div>
    </div>


</div>



@push('scripts')

    <script>

        window.onbeforeunload = function () {

            let id = @this.observation.id;

            //only call leaving dialog & function if the form is created
            if (id) {
            @this.leavePage();
                return "";
            }
        }


        $('#observation-form').on('submit', function () {
            $("html, body").animate({scrollTop: 0}, 800);
        })


        let select = $('.js-select');
        select.select2({
            placeholder: "Select",
        });

        select.on('change', function (e) {
        @this.set('observation.' + e.target.name, e.target.value);
        });
    </script>



    <script>
        document.addEventListener('DOMContentLoaded', function () {


            Livewire.on('uploadAttachments', () => {
                console.log('hi')
                $('#upload').click();
            })


            Livewire.on('hide_alert', () => {
                $(function () {
                    setTimeout(function () {
                        $(".alert").hide()
                    }, 5000);
                });
            })


            Livewire.on('resetJsFields', () => {

                $('select, input, textarea').each(function () {
                    $(this).css("background-color", "#fff");
                });

                $('.js-select').parent('div').find('.select2-selection').css('background-color', '#fff');


                //reset values, remove generated elements, hide shown elements
                $('#people-potential-consequences-container').hide();
                $('#environment-potential-consequences-container').hide();
                $('#asset-potential-consequences-container').hide();
                $('.hijri').html('');
                $('#file-previews .card').remove();

                //timeout was set to prevent action from removing notification alert, so it's set to be done after
                $(function () {
                    setTimeout(function () {
                        $('.js-select').val(null).trigger('change');
                    }, 6000);
                });


            });

        })
    </script>
@endpush

