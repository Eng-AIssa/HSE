<x-main-layout>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 2; padding: .35rem 3.9rem .35rem 1.2rem;"
             role="alert">
            <i class="mdi mdi-checkbox-marked-circle-outline mdi-24px mr-1"></i>
            <span style="vertical-align: super;  font-weight: 500; ">{{session('success')}}</span>
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <x-slot name="pageTitle">
        {{ __('Home') }}
    </x-slot>


    <div class="d-flex justify-content-center align-items-center" style=" height: 650px;">
        @auth
            <h1 class="text-center">{{ __('Welcome Home') }} {{Auth::user()->name}}!</h1>
        @endauth
        @guest
            <h1>{{ __('Welcome Home Guest!') }}</h1>
        @endguest

    </div>


</x-main-layout>
