<x-main-layout>

    @push('css')
        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Action') }}
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">


                    <livewire:add-action :datalist="$datalist" :locations="$locations" :users="$users" />


                </div>
                {{--end card box div--}}
            </div>
            {{--end size of card box columns--}}
        </div>
        {{--end main row container--}}
    </div>
    {{--end container fluid div--}}


    @push('scripts')


        <script>
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'title') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");

                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });


            $('.js-select').on('change', function (e) {
                if (e.target.value !== '')
                    $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                else
                    $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
            });
        </script>



        @livewireScripts
    @endpush


</x-main-layout>
