<x-main-layout>

    @push('css')
        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Observation') }}
    </x-slot>


    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">


                    <livewire:add-observation :datalist="$datalist" :users="$users" :locations="$locations"/>


                    {{--end of content row--}}
                </div>
                {{--end of card-box--}}
            </div>
            {{--column size which will specify the size of the card-box--}}
        </div>
        {{--end of the main page row--}}
    </div>
    {{--end of container fluid--}}


    @push('scripts')



        <script>

            //set the default for not required
            $('#potential-consequences-container').find('select').prop('required', false);


            //operate on 'potential consequences' fields based on their checkbox values
            function toggleOnChange(on, toggle) {
                $(on).on('change', function () {
                    // if check => show related field, add 'required' propriety, add red star
                    if ($(this).is(':checked')) {
                        $(toggle).find('select').prop('required', true);
                        $(toggle).find('.red-star').html('*');
                        $(toggle).fadeIn(1000);
                    }
                    // if uncheck => hide related field, remove 'required' propriety, remove red star
                    else {
                        $(toggle).find('select').prop('required', false);
                        $(toggle).find('.red-star').html('');
                        $(toggle).fadeOut(1000);
                    }

                });
            }

            toggleOnChange($('#people-checkbox'), $('#people-potential-consequences-container'))
            toggleOnChange($('#environment-checkbox'), $('#environment-potential-consequences-container'))
            toggleOnChange($('#cost-checkbox'), $('#asset-potential-consequences-container'))




            //change background-color if an input is filled
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'title') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");
                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });

            $('.js-select').on('change', function (e) {
                if (e.target.value !== '')
                    $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                else
                    $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
            });
        </script>



        @livewireScripts
    @endpush
</x-main-layout>
