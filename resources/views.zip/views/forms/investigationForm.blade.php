<x-main-layout>

    @push('css')
        @livewireStyles

    @endpush


    <x-slot name="pageTitle">
        {{ __('Investigation') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item">Accident</li>
        <li class="breadcrumb-item active">Investigation</li>
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">

                        <livewire:add-investigation :datalist="$datalist" :users="$users" :object="$object"/>


                </div>
                {{--end card--}}
            </div>
            {{--specify card size through columns--}}
        </div>
        {{--row which contain card div and card siz div--}}
    </div>
    {{--container fluid--}}



    @push('scripts')


        {{--change background-color if an input is filled--}}
        <script>
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'title') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");

                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });


            $('.js-select').on('change', function (e) {
                if (e.target.value !== '')
                    $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                else
                    $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
            });
        </script>


        <script>
            /*//remove reporters by click on x next to them
            function removeReporter(me) {
                $(me).closest('.event-dynamic-container').remove();
            }

            //add row of new reporter(name, department)
            $('#add-event').on('click', function () {
                let remove = $("<span style='position: absolute; right: 25px;'  class='text-danger'>Remove</span><i onclick='removeReporter(this)' style='position: absolute; right: 10px; z-index: 1;'  class=' clicky remove-reporter text-danger'>X</i>");
                let event = $(`<div class='col-12 event-dynamic-container'><div class='row'><div class='col-12 col-md-3'> <div class='form-group ' style='margin-top: -20px;'><label ></label><input  class='form-control gccShadow date' type='date'></div> </div> <div class='col-12 col-md-3'> <div class='form-group ' style='margin-top: -20px;'> <label > </label><input class ='form-control gccShadow' type='time'' ></div> </div><div class='col-12 col-md-6'><span style='position: absolute; right: 25px; bottom: 50px;'  class='text-danger'>Remove</span><i onclick='removeReporter(this)' style='position: absolute; right: 10px; bottom: 50px; z-index: 1;'  class=' clicky remove-reporter text-danger'>X</i> <div class='form-group ' style='margin-top: -20px;'> <label > </label><textarea  class = 'form-control gccShadow' rows = '1' placeholder='Description'></textarea></div> </div></div></div>`);


                $('#investigation-data-container').append(event);

            });*/
        </script>


        <script>
            function showOnChange(onChange, show) {
                $(onChange).on('change', function () {
                    if ($(this).val() === 'Other')
                        $(show).fadeIn(1000);
                    else
                        $(show).fadeOut(1000);
                })
            }

            showOnChange($('#immediate-cause-sub'), $('#immediate-cause-manual'));
            showOnChange($('#contributing-factor-sub'), $('#contributing-factor-manual'));
            showOnChange($('#root-cause-sub'), $('#root-cause-manual'));

            showOnChange($('#root-cause-analysis-tool'), $('#root-cause-analysis-tool-manual'))
        </script>

        <!-- Dropzone file uploads-->
        <script src="{{asset('js/dropzone.js')}}"></script>

        <!-- Init js-->
        <script src="{{asset('js/pages/form-fileuploads.init.js')}}"></script>


        @livewireScripts
    @endpush

</x-main-layout>
