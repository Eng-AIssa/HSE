<x-main-layout>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 1;  "
             role="alert">
            <i data-feather="check-circle" class="icons-xs mr-1"></i>
            {{--<i class="mdi mdi-check-all mr-2"></i>--}} {{session('success')}}
            <button type="button" class="close" data-dismiss="alert"
                    aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <x-slot name="pageTitle">
        {{ __('Finding') }}
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-sm-10 col-md-9 col-xl-9 ">
                <div class="card-box">
                    <div class="row">

                        {{--<h3 class="ml-3 mb-4">{{ __('Finding') }} # 11 </h3>--}}
                        <div class="col-12 col-sm-6 justify-content-start" style="display: flex;">
                            <h3 class="mb-2 mb-sm-4 ml-2">{{ __('Finding') }} # 11 </h3>
                        </div>
                        <div class="col-12 col-sm-6 justify-content-sm-end justify-content-start"
                             style="display: flex;">
                            <div style="display: flex;" class="mb-3 mb-sm-0 mr-sm-4 ml-2 ml-sm-0">
                                <h3 class="">Status:</h3>
                                <p class=" ml-2  font-20" style="padding-top: 0.6rem;">Initiation</p>
                            </div>
                        </div>

                        <form class="col-sm-10 col-xl-11 ml-2 ml-sm-3 mt-2 reporting-form" method="POST"
                              action="{{route('finding.store')}}">
                            @csrf

                            <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>

                            <input type="hidden" name="section_id" value="1">
                            <input type="hidden" name="stage_id" value="1">
                            <input type="hidden" name="timeline_id" value="1">


                            <x-form.workflow/>

                            <h5 class=" bg-light p-2 mt-0 mb-3">Finding Description</h5>

                            <x-form.textarea-input label="{{ __('Description') }}" rows="2"
                                                   name="finding_description" id="description" required='required'/>


                            <h5 class=" bg-light p-2 mt-0 mb-3">Finding Category</h5>


                            <div class="row">
                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Personnel Protective Equipment') }}"
                                                         name="personal_protective_equipment" required='required'>
                                        @foreach($datalist->where('name','Personnel Protective Equipment')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4 justify-content-end align-items-end">
                                    <x-form.select-input label="{{ __('Position/Reaction of People') }}"
                                                         name="reaction_of_people" required='required'>
                                        @foreach($datalist->where('name','Reaction Of People')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input style="margin-top: 1.2rem"
                                                         label="{{ __('Environmental Aspect') }}"
                                                         name="environmental_aspect" required='required'>
                                        @foreach($datalist->where('name','Environmental Aspect')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Position of People') }}"
                                                         name="position_of_people" required='required'>
                                        @foreach($datalist->where('name','Position Of People')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Tool and Equipment') }}"
                                                         name="tool_and_equipment" required='required'>
                                        @foreach($datalist->where('name','Tool & Equipment')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Procedure') }}" name="procedure"
                                                         required='required'>
                                        @foreach($datalist->where('name','Procedure')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Housekeeping') }}" name="housekeeping"
                                                         required='required'>
                                        @foreach($datalist->where('name','housekeeping')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('OHIH') }}" name="ohih" required='required'>
                                        @foreach($datalist->where('name','OHIH')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>
                            </div>


                            <h5 class=" bg-light p-2 mt-0 mb-3">Finding Data</h5>

                            <div class="row">
                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Type of Violation') }}" name="type_of_violation"
                                                         required='required'>
                                        @foreach($datalist->where('name','Type Of Violation')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Potential Consequences') }}"
                                                         name="potential_consequence" required='required'>
                                        @foreach($datalist->where('name','Potential Consequences')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input label="{{ __('Number of Deficiencies') }}"
                                                         name="number_of_deficiencies" required='required'>
                                        @foreach($datalist->where('name','Number Of Deficiencies')->first()->content as $item )
                                            <option>{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>
                            </div>

                            <x-form.text-input label="{{ __('Contractor/Individual Involved') }}" mb="3"
                                               name="involved" required='required'/>


                            <x-form.text-input label="{{ __('On Spot Action Taken') }}" mb="3"
                                               name="on_spot_action_taken" required='required'/>


                            <h5 class=" bg-light p-2 mt-0 mb-3">Related People</h5>

                            <div class="row ">
                                <div class="col-12 col-sm-6">
                                    <x-form.select-input label="{{ __('Responsible Person') }}" mb="0"
                                                         placeholder="{{ __('Name') }}" name="responsible_person"
                                                         required='required'>
                                        @foreach($users as $user)
                                            <option value="{{$user->id}}">{{$user->name}}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="3"
                                                       disabled="disabled"/>
                                </div>
                            </div>


                            <div class="row ">
                                <div class="col-12 col-sm-6">
                                    <x-form.select-input label="{{ __('Notify Only') }}" placeholder="{{ __('Name') }}"
                                                         mb="0"
                                                         name="notify_only" required='required'>
                                        @foreach($users as $user)
                                            <option value="{{$user->id}}">{{$user->name}}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.text-input label="-" placeholder="{{ __('Department') }}" mb="4"
                                                       disabled="disabled"/>
                                </div>
                            </div>

                        </form>

                        <div class="col-sm-10 col-xl-11 ml-2 ">
                            <h5 class=" bg-light p-2 mt-0 mb-3">Attachments & Documents <span
                                    style="color: red">*</span></h5>

                            <div class="row">
                                <div class="col-12">
                                    <form style="border: 2px dashed rgba(0,0,0,0.3);"
                                          action="{{route('attachment.store')}}" method="POST"
                                          enctype="multipart/form-data"
                                          class="dropzone " id="mine"
                                          data-plugin="dropzone" data-previews-container="#file-previews"
                                          data-upload-preview-template="#uploadPreviewTemplate">
                                        @csrf

                                        <div class="fallback">
                                            <input name="file" type="file" multiple/>
                                        </div>

                                        <div class="dz-message needsclick">
                                            <i class="h1 text-muted dripicons-cloud-upload"></i>
                                            <h3>Drop files here or click to upload.</h3>
                                            <span class="text-muted font-15">
                                                Please note that <strong>25MB</strong> is the limit per file
                                                </span>
                                        </div>
                                    </form>

                                    <!-- Preview -->
                                    <div class="dropzone-previews mt-3" id="file-previews"></div>
                                </div>
                            </div>


                            <!--file preview template-->
                            <div class="d-none" id="uploadPreviewTemplate">
                                <div class="card mt-1 mb-0 shadow-none border">
                                    <div class="p-2">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <img data-dz-thumbnail src="#" class="avatar-sm rounded bg-light"
                                                     alt="">
                                            </div>
                                            <div class="col pl-0">
                                                <a href="javascript:void(0);" class="text-muted font-weight-bold"
                                                   data-dz-name></a>
                                                <p class="mb-0" data-dz-size></p>
                                            </div>
                                            <div class="col-auto">
                                                <!-- Button -->
                                                <a href="" class="btn btn-link btn-lg text-muted" data-dz-remove>
                                                    <i class="dripicons-cross"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="col-12 d-flex justify-content-end pr-4">

                            <x-form.button id="my-secret-btn" label="{{ __('Submit') }}" class="m-1 mr-3"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    @push('scripts')


        <script>
            //change background-color if an input is filled
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'description') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");
                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });
        </script>


        <!-- Dropzone file uploads-->
        {{--<script src="{{asset('libs/dropzone/min/dropzone.min.js')}}"></script>--}}
        <script src="{{asset('js/dropzone.js')}}"></script>

        <!-- Init js-->
        <script src="{{asset('js/pages/form-fileuploads.init.js')}}"></script>
    @endpush

</x-main-layout>
