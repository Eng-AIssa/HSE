<x-main-layout>

    @push('css')
        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Accident # 92') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">Accident</li>
        <li class="breadcrumb-item active">LOPC</li>
    </x-slot>


    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">


                        <livewire:add-lobc :datalist="$datalist" :locations="$locations"
                                           :users="$users" />


                </div>

            </div>
        </div>

        @push('scripts')


            {{--change background-color if an input is filled--}}
            <script>
                $("input, select, textarea").focusout(function () {
                    if ($(this).attr('id') === 'title') {
                        if ($(this).val() !== '')
                            $(this).css("background-color", "#f6ffad");
                    } else {
                        if ($(this).val() !== '')
                            $(this).css("background-color", "rgb(232, 240, 254)");

                    }
                    if ($(this).val() === '')
                        $(this).css("background-color", "#fff");
                });


                $('.js-select').on('change', function (e) {
                    if (e.target.value !== '')
                        $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                    else
                        $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
                });
            </script>



            {{-- show/hide equipment involved & employee involved manual text fields
             based on the "other" option in their corresponding dropdown lists --}}
            <script>

                let manual_employee_and_equipment_container = $('.employee-equipment-manual-container');
                let involved_employee_manual_field = $('#employee-involved-manual');
                let involved_equipment_manual_field = $('#equipment-involved-manual');

                //the case of changing "involved employee" dropdown list choice
                $('#employee-involved').on('change', function () {
                    if ($(this).val() === 'Other') {
                        involved_employee_manual_field.fadeIn(1000);
                        manual_employee_and_equipment_container.fadeIn(1000);
                    } else {
                        if ($('#equipment-involved').val() !== 'Other') {
                            manual_employee_and_equipment_container.fadeOut(1000);
                        }
                        involved_employee_manual_field.fadeOut(1000);
                    }
                });

                //the case of changing "involved equipment" dropdown list choice
                $('#equipment-involved').on('change', function () {
                    if ($(this).val() === 'Other') {
                        involved_equipment_manual_field.fadeIn(1000);
                        manual_employee_and_equipment_container.fadeIn(1000);
                    } else {
                        if ($('#employee-involved').val() !== 'Other') {
                            manual_employee_and_equipment_container.fadeOut(1000);
                        }
                        involved_equipment_manual_field.fadeOut(1000);
                    }
                });
            </script>


            {{--show & hide based on some action--}}
            <script>

                function showOrHideOnClick(click, show, manual, action, displayMode) {
                    if (action === 'show')
                        $(click).on('click', function () {
                            if (manual.val())
                                manual.fadeIn(1000);
                            $(show).fadeIn(1000).css('display', displayMode);
                        });
                    else
                        $(click).on('click', function () {
                            manual.fadeOut(1000);
                            $(show).fadeOut(1000);
                        });
                }

                //show/hide involved employee based on the answer of "any exposed person"
                let involved_employee = $('#involved-employee');
                let manual_involved_employee = $('#employee-involved-manual');
                showOrHideOnClick($('#exposed-person-yes'), involved_employee, manual_involved_employee, 'show', 'block');
                showOrHideOnClick($('#exposed-person-no'), involved_employee, manual_involved_employee, 'hide');

            </script>


            @livewireScripts
    @endpush
</x-main-layout>
