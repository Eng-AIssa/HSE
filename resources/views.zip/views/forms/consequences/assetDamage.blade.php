<x-main-layout>

    @push('css')
        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Accident # 92') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item ">{{ __('Accident') }}</li>
        <li class="breadcrumb-item active">{{ __('Asset Damage') }}</li>
    </x-slot>


    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">


                    <livewire:add-asset-damage :datalist="$datalist" :users="$users" :locations="$locations"/>


                </div>

            </div>
        </div>

        @push('scripts')



            <script>
                //give equipment tag a description automatically, temporary until real equipment list with descriptions
                $('.equipment-tage').on('change', function () {
                    $('#equipment-description').val(Math.floor(Math.random() * 100) + '-Description').css('color', '#d78a8a');
                });
            </script>



            <script>

                let direct_checkbox = $('#direct-cost-checkbox');
                let indirect_checkbox = $('#indirect-cost-checkbox');
                let direct_amount = $('#direct-cost-amount');
                let indirect_amount = $('#indirect-cost-amount');
                let total_cost = $('#total-cost');
                let total_cost_container = $('#total-cost-container');


                // handle direct & indirect cost process based on checkboxes values
                function toggleOnChange(checkbox, costList, costAmount, list) {

                    checkbox.on('change', function () {

                        if (checkbox.is(':checked')) {
                            //show fields which are related to the checked checkbox
                            costList.show()
                            total_cost_container.show();
                            //enable cost amount field only if the list has the value(meaning user must choose list value first)
                            if (list.val() !== '')
                                costAmount.attr('disabled', false);
                            //function to calculate the total result
                            countResult();

                        } else if (!direct_checkbox.is(':checked') && !indirect_checkbox.is(':checked')) {
                            //insure hiding all fields
                            costList.hide();
                            total_cost_container.hide();
                            //set cost amount to 0 since the fields are hidden to reflect that on the total
                            direct_amount.val(0);
                            indirect_amount.val(0);
                            //disable cost amount field to ensure the list has value first when appears again
                            direct_amount.attr('disabled', true);
                            indirect_amount.attr('disabled', true);
                            //function to calculate the total result
                            countResult();

                        } else {
                            //hide fields which are related to the unchecked checkbox
                            costList.hide();
                            //set cost amount to 0 since it's hidden to reflect that on the total
                            costAmount.val(0);
                            //disable cost amount field to ensure the list has value first when it appears again
                            costAmount.attr('disabled', true);
                            //function to calculate the total result
                            countResult();
                        }

                    });
                }

                // calculate the total cost
                function countResult() {
                    let direct;
                    let indirect;

                    if (direct_checkbox.is(':checked'))
                        direct = Number((direct_amount.val() !== null) ? direct_amount.val() : 0)
                    else
                        direct = 0;

                    if (indirect_checkbox.is(':checked'))
                        indirect = Number((indirect_amount.val() !== null) ? indirect_amount.val() : 0);
                    else
                        indirect = 0;

                    total_cost.val(direct + indirect);
                }


                //re calculate the 'total cost' field  when 'cost amount' change and not checkbox change
                $('#direct-cost-amount, #indirect-cost-amount').on('change', function () {
                    countResult();
                });


                function enableOnChange(change, enable) {
                    $(change).on('change', function () {
                        enable.attr('disabled', false);
                    });
                }


                // toggle "direct cost" & "indirect cost" fields between show & hide based on the value of their corresponding checkboxes
                toggleOnChange(direct_checkbox, $('#direct-cost, #direct-cost-amount-container'), direct_amount, $('#direct-list'));
                toggleOnChange(indirect_checkbox, $('#indirect-cost, #indirect-cost-amount-container'), indirect_amount, $('#indirect-list'));

                // enable "cost in $" fields after an option of corresponding dropdown list is chosen
                enableOnChange($('#direct-cost select'), direct_amount);
                enableOnChange($('#indirect-cost select'), indirect_amount);

            </script>



            {{--change background-color if an input is filled--}}
            <script>
                $("input, select, textarea").focusout(function () {
                    if ($(this).attr('id') === 'title') {
                        if ($(this).val() !== '')
                            $(this).css("background-color", "#f6ffad");
                    } else {
                        if ($(this).val() !== '')
                            $(this).css("background-color", "rgb(232, 240, 254)");
                    }
                    if ($(this).val() === '')
                        $(this).css("background-color", "#fff");
                });


                $('.js-select').on('change', function (e) {
                    if (e.target.value !== '')
                        $(this).parent('div').find('.select2-selection').css('background-color', 'rgb(232, 240, 254)');
                    else
                        $(this).parent('div').find('.select2-selection').css('background-color', '#fff');
                });
            </script>


            {{--show & hide based on some action--}}
            <script>

                function showOrHideOnClick(click, show, action, displayMode) {
                    if (action === 'show')
                        $(click).on('click', function () {
                            $(show).fadeIn(1000).css('display', displayMode);
                        });
                    else
                        $(click).on('click', function () {
                            $(show).fadeOut(1000);
                        });
                }

                // show & hide involved employee based on the answer of "any exposed person"
                let involved_employee = $('#involved-employee');
                let involved_employee_container = $('#involved-employee-container');
                let involved_employee_yes = $('#exposed-person-yes');
                let involved_employee_no = $('#exposed-person-no');
                showOrHideOnClick(involved_employee_yes, involved_employee, 'show', 'block');
                showOrHideOnClick(involved_employee_yes, involved_employee_container, 'show', 'flex');
                showOrHideOnClick(involved_employee_no, involved_employee, 'hide');
                showOrHideOnClick(involved_employee_no, involved_employee_container, 'hide');

            </script>


            {{-- show/hide employee involved manual text field
                 based on the "other" option in corresponding dropdown list --}}
            <script>

                let involved_employee_manual_field = $('#employee-involved-manual');

                //the case of changing "involved employee" dropdown list choice
                $('#employee-involved').on('change', function () {
                    if ($(this).val() === 'Other') {
                        involved_employee_manual_field.fadeIn(1000);
                    } else {
                        involved_employee_manual_field.fadeOut(1000);
                    }
                });

            </script>


            @livewireScripts
    @endpush
</x-main-layout>

