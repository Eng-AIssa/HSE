<x-main-layout>

    @push('css')
        @livewireStyles
    @endpush


    <x-slot name="pageTitle">
        {{ __('Accident # 92') }}
    </x-slot>

    <x-slot name="path">
        <li class="breadcrumb-item">{{ __('Accident') }}</li>
        <li class="breadcrumb-item active">{{ __('Personal Injury') }}</li>
    </x-slot>


    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-11 col-md-10 col-lg-9">
                <div class="card-box">


                        <livewire:add-personal-injury :datalist="$datalist"/>


                </div>
            </div>
        </div>

    </div>



    @push('scripts')

        <script>

            let employee_container = $('.employee-information-section');

            //set the default to not required
            employee_container.find('input').prop('required', false);

            //on click toggle between 'slideDown' and 'slidUp'
            $('#employee-information svg').on('click', function () {
                employee_container.slideToggle().css('display', 'flex');

                //toggle div fields between required and non required based on the container condition(shown/hidden)
                if (employee_container.height() < 3) {
                    employee_container.find('input').prop('required', true);
                    employee_container.find('.red-star').html('*')
                } else {
                    employee_container.find('input').prop('required', false);
                    employee_container.find('.red-star').html('')
                    //reset fields values to empty to avoid submit its values in case of removing(hiding)
                    employee_container.find('input').val('').prop('checked', false).css('background-color', '#fff');
                }

            });
        </script>



        <script>

            let contractor_container = $('.contractor-information-section');

            //set the default to not required
            contractor_container.find('input').prop('required', false);

            //on click toggle between 'slideDown' and 'slidUp'
            $('#contractor-information svg').on('click', function () {
                contractor_container.slideToggle().css('display', 'flex');

                //toggle div fields between required and non required based on the container condition(shown/hidden)
                if (contractor_container.height() < 3) {
                    contractor_container.find('input').prop('required', true);
                    contractor_container.find('.red-star').html('*')
                } else {
                    contractor_container.find('input').prop('required', false);
                    contractor_container.find('.red-star').html('')
                    //reset fields values to empty to avoid submit its values in case of removing(hiding)
                    contractor_container.find('input').val('').css('background-color', '#fff');
                }

            });
        </script>



        <script>
            let job_transfer_container = $('.job-transfer-container');

            //on yes choice  =>  show container, set fields to required, add red star
            $('#job-transfer-yes').on('click', function () {
                job_transfer_container.find('input,textarea').prop('required', true);
                job_transfer_container.find('.red-star').html('*');

            });

            //on no choice  =>  hide container, set fields to non required, remove red star
            $('#job-transfer-no').on('click', function () {
                job_transfer_container.find('input,textarea').prop('required', false);
                job_transfer_container.find('.red-star').html('');
            });


            function toggleOnClick(on, toggle) {
                $(on).on('click', function () {
                    toggle.fadeToggle(1000);
                });
            }

            toggleOnClick($('#injuryCategoryHeading span, #injuryCategoryHeading svg'), $('.injuryCategoryElement'));
        </script>



        <script>

            let injury_type_checkboxes = $('.injury-type-checkboxes');
            let injury_category_checkboxes = $('.injury-category-checkboxes');
            let illness_type_checkboxes = $('.illness-type-checkboxes');

            //hide and show fields based on the choice of 'type of injury' dropdown list
            $('#type-of-injury-list').on('change', function () {
                if ($(this).val() === 'Injury') {
                    injury_type_checkboxes.fadeIn(1000).css('display', 'flex');
                    injury_category_checkboxes.fadeIn(1000).css('display', 'flex');
                    illness_type_checkboxes.fadeOut(1000);
                } else {
                    injury_type_checkboxes.fadeOut(1000);
                    injury_category_checkboxes.fadeOut(1000);
                    illness_type_checkboxes.fadeIn(1000).css('display', 'flex');
                }
            });
        </script>


        {{--change background-color if an input is filled--}}
        <script>
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'title') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");
                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });
        </script>

        @livewireScripts
    @endpush


</x-main-layout>
