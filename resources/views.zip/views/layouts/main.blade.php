<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>UBold</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description"/>
    <meta content="Coderthemes" name="author"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{asset('images/favicon.ico')}}">

    <!-- App css -->
    <link href="{{asset('css/bootstrap-modern.min.css')}}" rel="stylesheet" type="text/css" id="bs-default-stylesheet"/>
    <link href="{{asset('css/app-modern.min.css')}}" rel="stylesheet" type="text/css" id="app-default-stylesheet"/>

    <link href="{{asset('css/bootstrap-modern-dark.min.css')}}" rel="stylesheet" type="text/css"
          id="bs-dark-stylesheet"/>
    <link href="{{asset('css/app-modern-dark.min.css')}}" rel="stylesheet" type="text/css" id="app-dark-stylesheet"/>


    <style>

        .custom-select.is-invalid:focus,
        .custom-select.is-valid:focus,
        .custom-select:invalid:focus,
        .custom-select:valid:focus,
        .form-control.is-invalid:focus,
        .form-control.is-valid:focus,
        .form-control:invalid:focus,
        .form-control:valid:focus {
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000) !important;
        }

        .gccShadow:focus, input:focus {
            --tw-border-opacity: 1;
            border-color: rgba(165, 180, 252, var(--tw-border-opacity));
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            --tw-ring-color: rgba(199, 210, 254, var(--tw-ring-opacity));
            --tw-ring-opacity: 0.5;
            outline: 2px solid transparent;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, /*/*/ /*/*/);
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }

        select option[disabled] {
            display: none;
        }

        .matrix-element {
            margin: 0.05rem;
            min-height: 1.8rem;
            font-size: 1rem;
            font-weight: 500;
            color: black;
            display: flex;
            justify-content: center;
        }

        .typeOfAssetElement, .typeOfFireElement, .typeOfLeakElement, .operationalModeElement, .chemicalSpillToSurroundingsElement, .typeOfSpillElement, .injuryCategoryElement, .partsOfBodyHarmedElement, .reasonOfInjuryOrIllnessElement, .typeOfIllnessElement, .typeOfInjuryElement {
            display: none;
        }

        .clicky {
            cursor: pointer !important;
        }

        .hide {
            display: none;
        }

        /* workflow chart styles */
        .track-order-list ul li.current {
            /*change the line color of the current stage*/
            border-color: green;
        }

        .track-order-list ul li.current:before {
            /*change the dot color of the current stage*/
            background-color: green !important;
        }

        .track-order-list ul li .active-dot.dot {
            /*change the blinking color of the current stage*/
            border-color: green;
        }


        .track-order-list ul li {
            border-top: 2px solid #dee2e6;
            border-left: 0;
            padding: 15px 10px 0px 10px;
        }

        .track-order-list ul li:before {
            top: -9px;
        }

        .track-order-list ul li .active-dot.dot {
            top: -36px !important;
            left: -34px;
        }

        .dot {
            border: 5px solid #5671f0;
            height: 70px;
            width: 70px;
        }

        .track-order-list ul li:before {
            height: 16px;
            width: 16px;
        }

        .end-point:before {
            content: "";
            position: absolute;
            left: -7px;
            top: 0;
            height: 10px;
            width: 10px;
            background-color: #ee324d !important;
            border-radius: 50%;
            border: 3px solid #ee324d;
        }

        .end-point:after {
            top: -5px;
            left: 120px;
        }

        .track-order-list i {
            position: absolute;
            font-size: 1.3rem;
            top: -11.5px;
            transform: rotate(45deg);
        }

        .track-order-list li i:first-of-type {
            /*right: 25%;*/
            right: 11px;
        }

        /* end workflow chart styles */


        /* checkboxes pop up style */
        .checkboxes-pop-up {
            padding: 20px;
            flex-wrap: wrap;
            background-color: #d7e9ff;
        }

        /* show checkboxes pop up in as flex */
        #observation-form .dropdown-menu.show {
            display: flex;
        }

        .reporting-form .dropdown-menu.show {
            display: flex;
        }


        /* override select2 style*/
        .select2-container .select2-selection--single {
            height: calc(1.5em + .9rem + 2px) !important;
            padding: 0.25rem 1.9rem .45rem .4rem !important;
            border: 1px solid #ced4da !important;
            border-radius: .2rem !important;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: #6c757d !important;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            top: 5px !important;
            right: 5px !important;
        }

        .select2-container--default .select2-search--dropdown {
            padding: 5px;
        }

        /* end override select2 style*/


        .vertical-alignment-when-wrapping {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .placeholder-style::-webkit-input-placeholder {
            color: #ec9191;
        }


        /* add hours or minutes label at the end of duration input field of col-5*/
        .time-label-col-5 {
            position: absolute;
            top: 36px;
            right: 25px;
            z-index: 2;
        }


        /*style the inspection slider*/
        .inspection-slider input[type='range'] {
            height: 7px;
            border-radius: 2px;
            -webkit-appearance: none;
            background-color: #aab3bf;
        }

        .risk-slider input[type='range'] {
            background-color: #f82f56 !important;
        }

        .save-slider input[type='range'] {
            background-color: #019301 !important;
        }

        .inspection-slider input[type='range']::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            z-index: 1;
            transform: rotate(45deg);
            border-radius: 10px;
            background-color: black;
            overflow: visible;
            cursor: pointer;
        }

        /*end style the inspection slider*/


        /*datatables style*/

        /*set long data to hide and 3 dots at the end after 230px*/

        @media only screen and (max-width: 800px) {
            .dtr-data {
                overflow: hidden;
                display: inline-block;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 230px;
                vertical-align: middle;
                padding-left: 10px;
            }
        }

        @media only screen and (min-width: 800px) {

            .dtr-data {
                overflow: hidden;
                display: inline-block;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 550px;
                vertical-align: middle;
                padding-left: 10px;
            }
        }

        /*end datatables style*/


        .error-massage {
            color: red;
            display: block;
            margin: -22px 0 15px 3px;
        }
    </style>
@stack('css')


<!-- icons -->
    <link href="{{asset('css/icons.min.css')}}" rel="stylesheet" type="text/css"/>
@stack('icons')


<!-- Alpine JS -->
    <script defer src="{{ asset('https://unpkg.com/alpinejs@3.3.4/dist/cdn.min.js') }}"></script>

</head>

<body class="loading" data-layout-mode="detached"
      data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": true}, "topbar": {"color": "dark"}, "showRightSidebarOnPageLoad": true}'>

<!-- Begin page -->
<div id="wrapper">

@include('layouts.topBar')

@include('layouts.leftSidebar')


<!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="content-page">
        <div class="content">

            <!-- Start Content-->
            <div class="container-fluid">
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">HSSE</a></li>
                                    @isset($path) {{$path}} @else
                                        <li class="breadcrumb-item active">{{$pageTitle}}</li> @endisset
                                </ol>
                            </div>
                            <h2 style="font-size: 1.6rem; font-weight: 450;"
                                class="page-title"> {{$pageTitle ?? 'Title'}} </h2>
                        </div>
                    </div>
                </div>
                <!-- end page title -->


            </div> <!-- container -->

            <main class="">
                {{ $slot }}
            </main>

        </div> <!-- content -->


        @include('layouts.footer')

    </div>

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->

</div>
<!-- END wrapper -->

{{--@include('layouts.rightSidebar')--}}



<!-- Vendor js -->
<script src="{{asset('js/vendor.min.js')}}"></script>

<!-- App js -->
<script src="{{asset('js/app.min.js')}}"></script>


<script src="{{asset('js/moment-with-locales.min.js')}}"></script>
<script src="{{asset('js/moment-hijri.js')}}"></script>


{{--hide notification after specific period--}}
<script>
    $(function () {
        setTimeout(function () {
            $(".alert").hide()
        }, 5000);
    });
</script>

{{--set Hijri date when gregorian chosen--}}
<script>
    $('.date').on('change', function () {
        let value = $(this).val();
        let hijriSpan = $(this).parent('div').find('.hijri');
        /*let hijriSpan = $(this).parent('div').find('span:first');*/
        hijriSpan.html(moment(value, 'YYYY-M-D').format('iYYYY/iM/iD'));
    });
</script>

@stack('scripts')


</body>
</html>
