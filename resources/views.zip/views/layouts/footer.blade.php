<!-- Footer Start -->
<footer class="footer" id="footer">
    <div class="container-fluid">
        <div class="row">

            <!-- Start Years & Copy Rights -->
            <div class="col-md-6">
                 <script>document.write(new Date().getFullYear())</script> &copy; {{ __('All Rights Are Reserved For Safety GCC') }}
            </div>
            <!-- Start Years & Copy Rights -->

            <!-- Start Footer Links -->
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript:void(0);">{{ __('About Us') }}</a>
                    <a href="javascript:void(0);">{{ __('Help') }}</a>
                    <a href="javascript:void(0);">{{ __('Contact Us') }}</a>
                </div>
            </div>
            <!-- End Footer Links -->
        </div>
    </div>
</footer>
<!-- end Footer -->
