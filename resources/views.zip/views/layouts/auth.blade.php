<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>{{ __('Log In') }}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description"/>
        <meta content="Coderthemes" name="author"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{url('images/favicon.ico')}}">

        <!-- App css -->
        <link href="{{asset('css/bootstrap-modern.min.css')}}" rel="stylesheet" type="text/css" id="bs-default-stylesheet"/>
        <link href="{{asset('css/app-modern.min.css')}}" rel="stylesheet" type="text/css" id="app-default-stylesheet"/>

        <link href="{{asset('css/bootstrap-modern-dark.min.css')}}" rel="stylesheet" type="text/css"
              id="bs-dark-stylesheet"/>
        <link href="{{asset('css/app-modern-dark.min.css')}}" rel="stylesheet" type="text/css" id="app-dark-stylesheet"/>

        <style>
            .custom-select.is-invalid:focus,
            .custom-select.is-valid:focus,
            .custom-select:invalid:focus,
            .custom-select:valid:focus,
            .form-control.is-invalid:focus,
            .form-control.is-valid:focus,
            .form-control:invalid:focus,
            .form-control:valid:focus {
                box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000) !important;
            }
            .gccShadow:focus, input:focus{
                --tw-border-opacity: 1;
                border-color: rgba(165, 180, 252, var(--tw-border-opacity));
                --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                --tw-ring-color: rgba(199, 210, 254, var(--tw-ring-opacity));
                --tw-ring-opacity: 0.5;
                outline: 2px solid transparent;
                outline-offset: 2px;
                --tw-ring-inset: var(--tw-empty, /*/*/ /*/*/);
                --tw-ring-offset-width: 0px;
                --tw-ring-offset-color: #fff;
                --tw-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            }
        </style>
        @stack('css')

        <!-- icons -->
        <link href="{{asset('css/icons.min.css')}}" rel="stylesheet" type="text/css"/>
        @stack('icons')

    </head>

    <body class="loading auth-fluid-pages pb-0">

        <div class="auth-fluid">

            <!--Auth fluid left content -->
            <div class="auth-fluid-form-box">
                <div class="align-items-center d-flex h-100">
                    <div class="card-body">


                        <!-- Logo -->
                        <div class="auth-brand text-center text-lg-left">
                            <div class="auth-logo">
                                <a href="\home" class="logo logo-dark text-center">
                                    <span class="logo-lg">
                                        <img src="{{asset('images/logo-dark.png')}}" alt="" height="22">
                                    </span>
                                </a>

                                <a href="\home" class="logo logo-light text-center">
                                    <span class="logo-lg">
                                        <img src="{{asset('images/logo-light.png')}}" alt="" height="22">
                                    </span>
                                </a>
                            </div>
                        </div>
                        <!-- End Logo -->


                        <!-- Auth Content -->
                        {{$slot}}


                    </div>
                </div>
            </div>
            <!-- end auth-fluid-form-box-->


            <!-- Auth fluid right content -->
            <div class="auth-fluid-right text-center">
                <div class="auth-user-testimonial">
                    <h2 class="mb-3 text-white">{{ __('I love the color!') }}</h2>
                    <p class="lead"><i class="mdi mdi-format-quote-open"></i> {{ __("I've been using your theme from the
                        previous
                        developer for our web app, once I knew new version is out, I immediately bought with no
                        hesitation.
                        Great themes, good documentation with lots of customization available and sample app that really
                        fit our
                        need.") }} <i class="mdi mdi-format-quote-close"></i>
                    </p>
                    <h5 class="text-white">
                        {{ __('- Fadlisaad') }}
                    </h5>
                </div>
            </div>
            <!-- end Auth fluid right content -->

        </div>
        <!-- end auth-fluid-->

        <!-- Vendor js -->
        <script src="{{asset('js/vendor.min.js')}}"></script>

        <!-- App js -->
        <script src="{{asset('js/app.min.js')}}"></script>

        @stack('scripts')
    </body>
</html>

