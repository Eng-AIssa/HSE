@props(['stage' => 'Initiation',
'first' => 'Initiation' , 'second' => 'Responsible','third' => 'HSE', 'forth' => 'Closed',
'fMessage', 'sMessage', 'tMessage', 'fthMessage', ])

<h5 class="bg-light p-2 mt-0 mb-4">Workflow Overview</h5>

<div class="row track-order-list">
    <ul class="list-unstyled col-12 d-flex flex-wrap justify-content-center">

        <li class="@if($stage!='Initiation')  completed @else current @endif pt-2">
            @if($stage == 'Initiation')
                {{--blinking dot which state we are in this stage--}}
                <span class="active-dot dot"></span>
                {{--green arrow pointing at next stage--}}
                <i style="color: green;" class="fas fa-location-arrow"></i>
            @endif
            <h5 class="mt-0 mb-1 mr-3"> {{$first}}</h5>
            <p class="text-muted text-center">{{$fMessage ?? ''}}<br><small class="text-muted"></small>
            </p>
        </li>

        <li class="@if($stage!='Initiation' && $stage !='Responsible') completed
                    @elseif($stage == 'Responsible') current @endif ">
            @if($stage == 'Responsible')
                <span class="active-dot dot"></span>
                <i style="color: green;" class="fas fa-location-arrow"></i>
            @elseif($stage == 'Initiation')
                {{-- gray arrow to clarify where workflow is going --}}
                <i class="fas fa-location-arrow"></i>
            @endif
            <h5 class="mt-0 mb-1 ">{{$second}}</h5>
            <p class="text-muted "> {{$sMessage ?? 'Review, Accept & process'}}<br> <small
                    class="text-muted"></small>
            </p>
        </li>

        <li @if($stage=='Closed') class="completed" @elseif($stage == 'HSE') class="current" @endif >
            @if($stage == 'HSE')
                <span class="active-dot dot"></span>
                <i style="color: green;" class="fas fa-location-arrow"></i>
            @elseif($stage == 'Initiation' || $stage == 'Responsible')
                <i class="fas fa-location-arrow"></i>
            @endif
            <h5 class="mt-0 mb-1 "> {{$third}} </h5>
            <p class="text-muted ">{{$tMessage ?? 'last step review'}}</p>
        </li>

        <li @if($stage=='Closed') class="completed" @endif>
            @if($stage == 'Closed')
                <i style="color: #5671f0;" class="fas fa-location-arrow"></i>
            @else
                <i class="fas fa-location-arrow"></i>
            @endif
            <h5 class="mt-0 mb-1 "> {{$forth}}</h5>
            <p class="text-muted">{{$fthMessage ?? 'last step review'}}</p>
        </li>

        <li class="end-point p-0">

        </li>
    </ul>
</div>
