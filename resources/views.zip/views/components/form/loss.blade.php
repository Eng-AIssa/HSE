@props(['id' => '', 'name' => '', 'required' => 'required', 'datalist', 'matrixId' => ''])

<div {{ $attributes->merge(['class' =>'col-12 loss-category'])}} id="{{$id}}">

    <input type="hidden" value="{{$matrixId}}" id="matrix-id">

    <div class="row">

        <div class="col-12">
            <h4>{{$name}}</h4>
            <hr style="margin-top: 0rem; margin-bottom: 1.2rem;">
        </div>

        {{--
        we have 3 different classes on every field as the following:
            - potential-loss =>
                # apply on all fields
                # used for actions needed on all at once,
                # ex: disable all fields when converting from 'Accident' to 'Nearmiss'
            - potential-severity, frequency-of-occurrence, risk =>
                # apply on 1 field and will give us 1 column with the same class
                # used to access field value on the certain row which we operate on
                # ex: extract 'frequency' & 'potential severity' fields values and concatenate them to know where to set the number in matrix as every matrix slot is combination of the two
            - *-potential-loss => customized class based on the row(people, environment, cost)
                # apply on 1 field and will give us 1 row with the same class
                # used for actions needed on all row fields at once
                # ex: disable all row fields when corresponding checkbox is unchecked
                --}}

        <div class="col-12 col-sm-6 col-md-4">
            <x-form.select-input
                wire:model.defer="{{'incident.' . lcfirst(explode(' ', $name)[0]) .'.potential_severity'}}"
                label="{{ __('Potential Severity') }}"
                id="{{lcfirst(explode(' ', $name)[0])}}-potential-severity"
                name="{{ lcfirst(explode(' ', $name)[0]) }}['potential severity']"
                class="ml-1 matrix-options potential-loss potential-severity {{lcfirst(explode(' ', $name)[0])}}-potential-loss "
                disabled="disabled">
                {{$slot}}
            </x-form.select-input>
        </div>

        <div class="col-12 col-sm-6 col-md-4">
            <x-form.select-input
                wire:model.defer="{{'incident.' . lcfirst(explode(' ', $name)[0]) .'.frequency'}}"
                label="{{__('Frequency')}}"
                id="{{lcfirst(explode(' ', $name)[0])}}-frequency-of-occurrence"
                name="{{ lcfirst(explode(' ', $name)[0]) }}['frequency]"
                class="ml-1 matrix-options potential-loss frequency-of-occurrence {{lcfirst(explode(' ', $name)[0])}}-potential-loss "
                disabled="disabled">
                @foreach($datalist->where('name','Frequency')->first()->content as $item)
                    <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                @endforeach
            </x-form.select-input>
        </div>

        <div class="col-12 col-sm-6 col-md-4">
            <x-form.text-input
                wire:model.defer="incident.{{lcfirst(explode(' ', $name)[0])}}.potential_risk"
                label="{{ __('Potential Risk') }}"
                id="{{lcfirst(explode(' ', $name)[0])}}-risk"
                name="{{ lcfirst(explode(' ', $name)[0]) }}['potential risk']"
                class="ml-1 potential-loss risk {{lcfirst(explode(' ', $name)[0])}}-potential-loss  "
                disabled="disabled" placeholder="Auto"/>
        </div>

    </div>
</div>

