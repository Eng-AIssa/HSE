@props(['label' => '', 'disabled' => '', 'required' => '', 'mb' => '3'])

<div class='form-group mb-{{$mb}}'>
    <label >{{$label}}  </label>
    <span class='text-danger red-star'>{{$required ? '*' : ''}}</span>
    <textarea  {{$attributes->merge(['class' => 'form-control gccShadow', 'rows' => '5'])}} {{$disabled}} {{$required}}>{{$slot}}</textarea>
</div>
