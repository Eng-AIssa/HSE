@props(['label' => '', 'id' => '', 'name' => ''])

<div class="custom-control custom-checkbox mb-1">
    <input id="{{$id}}"  name="{{$name}}[]"  {{ $attributes->merge(['value'=>"$label",'type' => 'checkbox','class' => 'custom-control-input checkbox'])}} >
    <label class="custom-control-label " for="{{$id}}"> {{$label}} </label>
</div>
