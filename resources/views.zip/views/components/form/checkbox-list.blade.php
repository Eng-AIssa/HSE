@props(['label' => 'Add', 'width' => '75%', 'mb' => '3', 'required' => ''])

<div class="row my-3 ml-1 dropdown checkboxes-container">

    <div class="col-12  " data-toggle="dropdown" aria-haspopup="true"
         aria-expanded="false">
        <div class="icon-item font-16 " id="typeOfLeakHeading">
            <i style="color: #4a81d4;" class="mdi mdi-plus-circle-outline mdi-36px clicky"></i>
            <span style="vertical-align: super;" class="clicky">{{$label}}</span>
        </div>
    </div>

    <div class="col-11 p-1 result-container hide ml-3 mt-2 border rounded"
         style="min-height: 2.2rem;">

    </div>

    <div class="col-12">
        <div  class="dropdown-menu checkboxes-pop-up" style="width: {{$width}}">
            {{$slot}}
        </div>
    </div>
</div>
