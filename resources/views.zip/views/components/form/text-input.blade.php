@props(['label' => '', 'disabled' => '', 'mb' => '', 'required' => '', 'readonly' => '',  'users' => ''])

<div class='form-group  mb-{{$mb}} '>
    <label>{{$label}} </label>
    <span class='text-danger red-star'>{{$required ? '*' : ''}}</span>
    <input   {{$attributes->merge(['style' => '', 'type' => 'text', 'class' => ' form-control gccShadow', 'maxlength' => '150'])}} {{$disabled}} {{$required}} {{$readonly}}>
    @if($users)
        <i data-feather='user' style='position: absolute; right: 20px; bottom: 30px;' class='d-sm-block d-none icon-dual-blue icons-sm '></i>
        <i data-feather='user' style='position: absolute; right: 20px; bottom: 5px;' class='d-sm-none d-block icon-dual-blue icons-sm '></i>
    @endif
</div>
