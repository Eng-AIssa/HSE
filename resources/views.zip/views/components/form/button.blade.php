@props(['label' => ''])

<button {{ $attributes->merge(['type' => 'submit','class' => 'btn btn-primary waves-effect waves-light'])}} >{{ __($label) }}</button>
