@props(['label' => '', 'disabled' => '', 'mb' => '3', 'mt' => '0', 'required' => '', 'users' => '', 'readonly' => ''])

@push('css')
    <link href="{{asset('libs/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css"/>
@endpush

<div class="form-group mb-{{$mb}} mt-{{$mt}}">
    <label for="">{{$label}} </label>
    <span class="text-danger red-star">{{$required ? '*' : ''}}</span>
    <select {{ $attributes->merge(['class' =>'custom-select gccShadow'])}} {{$disabled}} {{$required}} {{$readonly}}>
        <option value="" hidden>{{ __('Select') }}</option>
        {{$slot}}
    </select>
    @if($users)
        <span>
            <i data-feather="user" style="position: absolute; background-color:white; right: 20px; bottom: 30px;"
               class="d-sm-block d-none icon-dual-blue icons-sm "></i>
            <i data-feather="user" style="position: absolute; background-color:white; right: 20px; bottom: 5px;"
               class="d-sm-none d-block icon-dual-blue icons-sm "></i>
            {{--<i style="position: absolute; /*background-color:white;*/ right: 20px; bottom: 15px; color:#4a81d4;"
               class="mdi mdi-account mdi-36px d-sm-block d-none"></i>
            <i style="position: absolute; /*background-color:white;*/ right: 20px; bottom: 5px; color:#4a81d4;"
               class="mdi mdi-account mdi-36px d-sm-none d-block"></i>--}}
        </span>
    @endif
</div>


@push('scripts')
    <script src="{{asset('libs/select2/js/select2.min.js')}}"></script>

    <!-- Init js-->
    <script src="{{asset('js/pages/form-advanced.init.js')}}"></script>
@endpush
