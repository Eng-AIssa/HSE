@props(['label' => '', 'id' => '', 'name' => ''])

<div class=" mb-1 radio radio-primary">
    <input id="{{$id}}" name="{{$name}}"  {{ $attributes->merge(['value' => "$label" ,'type' => 'radio','class' => ''])}}>
    <label for="{{$id}}"> {{$label}} </label>
</div>
