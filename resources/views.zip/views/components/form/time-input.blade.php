@props(['label' => '', 'disabled' => '', 'mb' => '3', 'required' => ''])

<div class='form-group mb-{{$mb}}'>
    <label >{{$label}} </label>
    <span class='text-danger'>{{$required ? '*' : ''}}</span>
    <input  {{$attributes->merge(['class' => 'form-control gccShadow', 'type' => 'time'])}} {{$disabled}} {{$required}}>
</div>
