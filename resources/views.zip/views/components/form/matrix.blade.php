@props(['name' => ''])

<div {{ $attributes->merge(['class' =>'col-7 col-sm-6 col-md-6 col-lg-4 col-xl-4 my-2 matrix', 'style' => 'display: none;'])}}>
    <div class="row">
        <span class="matrix-element col-2  C5F1"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C5F2"  style="background-color:#ec8631;">-</span>
        <span class="matrix-element col-2  C5F3"  style="background-color:#fb7363;">-</span>
        <span class="matrix-element col-2  C5F4"  style="background-color:#fb7363;">-</span>
        <span class="matrix-element col-2  C5F5"  style="background-color:#fb7363;">-</span>

        <span class="matrix-element col-2  C4F1"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C4F2"  style="background-color:#ec8631;">-</span>
        <span class="matrix-element col-2  C4F3"  style="background-color:#ec8631;">-</span>
        <span class="matrix-element col-2  C4F4"  style="background-color:#fb7363;">-</span>
        <span class="matrix-element col-2  C4F5"  style="background-color:#fb7363;">-</span>

        <span class="matrix-element col-2  C3F1"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C3F2"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C3F3"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C3F4"  style="background-color:#ec8631;">-</span>
        <span class="matrix-element col-2  C3F5"  style="background-color:#fb7363;">-</span>

        <span class="matrix-element col-2  C2F1"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C2F2"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C2F3"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C2F4"  style="background-color:#f1f27c;">-</span>
        <span class="matrix-element col-2  C2F5"  style="background-color:#ec8631;">-</span>

        <span class="matrix-element col-2  C1F1"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C1F2"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C1F3"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C1F4"  style="background-color:#aadbee;">-</span>
        <span class="matrix-element col-2  C1F5"  style="background-color:#f1f27c;">-</span>

        <div class="col-12 text-center pr-4"><h4>{{$name}}</h4></div>
    </div>
</div>
