@props(['personalInjury' => '', 'id'=>'1' , 'type' => 'employee' ])


<div wire:key="personal-modal-{{$id}}" wire:ignore.self role="dialog" aria-labelledby="myModalLabel"
     id="personalInjury-modal-{{$id}}" class="modal fade " tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content ">
            <div class="modal-header bg-soft-light">
                <h4 class="modal-title">Injury Information</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×
                </button>
            </div>
            <div class="modal-body p-4 bg-light text-left">

                @if($type == 'employee')

                    <div class="row" wire:ignore>
                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="employee-id-{{$id}}"
                                               label="{{ __('Employee ID') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['employee_id']}}"/>
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="employee-name-{{$id}}"
                                               label="{{ __('Employee Name') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['employee_name']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="employee-age-{{$id}}"
                                               label="{{ __('Age') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['employee_age']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="employee-department-{{$id}}"
                                               label="{{ __('Department') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['employee_department']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="row mt-2 mb-3 ">
                                <label class="col-12">{{ __('Gender') }} </label>

                                <div class="col-6 pl-3 radio radio-primary">
                                    <div class=" mb-1 radio radio-primary">
                                        <input wire:key="employee-gender-male-{{$id}}"
                                               id="show-male" name="show-gender"  value="Male" type='radio' disabled
                                            {{$personalInjury['employee_gender'] == 'male' ? 'checked' : ''}} >
                                        <label for="show-male"> {{ __('Male') }} </label>
                                    </div>
                                </div>

                                <div class="col-6 pl-2 radio radio-primary ">
                                    <div class=" mb-1 radio radio-primary">
                                        <input wire:key="employee-gender-female-{{$id}}"
                                               id="show-female" name="show-gender"  value="Male" type='radio' disabled
                                            {{$personalInjury['employee_gender'] == 'female' ? 'checked' : ''}} >
                                        <label for="show-female"> {{ __('Female') }} </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="employee-job-title-{{$id}}"
                                               label="{{ __('Job Title') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['employee_job_title']}}" />
                        </div>
                    </div>

                @else

                    <div class="row " wire:ignore >
                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="contractor-name-{{$id}}"
                                               label="{{ __('Contractor Name') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['contractor_name']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="contractor-job-title-{{$id}}"
                                               label="{{ __('Job Title') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['contractor_job_title']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="contractor-age-{{$id}}"
                                               label="{{ __('Age') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['contractor_age']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="contractor-department-{{$id}}"
                                               label="{{ __('Department') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['contractor_department']}}" />
                        </div>

                        <div class="col-12 col-md-6">
                            <x-form.text-input wire:key="contractor-company-{{$id}}"
                                               label="{{ __('Contractor Company') }}"
                                               readonly="readonly"
                                               value="{{$personalInjury['contractor_company']}}" />
                        </div>

                    </div>


                @endif

                <div wire:key="showTypeAndDescription" class="row" wire:ignore>
                    <div class="col-6 ">
                        <x-form.text-input wire:key="show-type-{{$id}}"
                                             label="{{ __('Type of Injury') }}"
                                             readonly="readonly"
                                             value="{{$personalInjury['type_of_injury']}}" >

                        </x-form.text-input>
                    </div>

                    <div class="col-12 ">
                        <x-form.textarea-input wire:key="show-description-{{$id}}"
                                               label="{{ __('Injury Description') }}"
                                               rows="3" readonly="readonly">
                            {{$personalInjury['injury_description']}}
                        </x-form.textarea-input>
                    </div>
                </div>


                <div class="row" wire:ignore>
                    <div class="col-12 col-md-6">
                        <x-form.date-input wire:key="treatment-date-{{$id}}"
                                           label="{{ __('Treatment Date') }}"
                                           readonly="readonly"
                                           value="{{$personalInjury['treatment_date']}}" />
                    </div>

                    <div class="col-12 col-md-6">
                        <x-form.date-input wire:key="diagnosis-date-{{$id}}"
                                           label="{{ __('Diagnosis Date') }}"
                                           readonly="readonly"
                                           value="{{$personalInjury['diagnosis_date']}}" />
                    </div>

                    <div class="col-12 col-md-6">
                        <x-form.date-input wire:key="return-to-work-date-{{$id}}"
                                           label="{{ __('Return to Work Date') }}"
                                           readonly="readonly"
                                           value="{{$personalInjury['return_to_work_date']}}" />
                    </div>

                    <div class="col-12 col-md-6">
                        <x-form.text-input wire:key="days-away-{{$id}}"
                                           label="{{ __('Days Away From Work') }}"
                                           readonly="readonly"
                                           value="{{$personalInjury['numbers_of_days_away_from_work']}}" />
                    </div>

                    <div class="col-12">

                        <div class="row mt-2 mb-3 ">
                            <label class="col-12">{{ __('Job Transfer') }}</label>

                            <div class="col-3 pl-3 ">
                                <div class=" mb-1 radio radio-primary">
                                    <input wire:key="job-transfer-yes-{{$id}}"
                                           id="show-job-transfer-yes" name="show_job_transfer"  value="1" type='radio' disabled
                                        {{$personalInjury['is_job_transfer'] == '1' ? 'checked' : ''}} >
                                    <label for="show-job-transfer-yes"> {{ __('Yes') }} </label>
                                </div>
                            </div>

                            <div class="col-3 pl-2 ">
                                <div class=" mb-1 radio radio-primary">
                                    <input wire:key="job-transfer-no-{{$id}}"
                                           id="show-job-transfer-no" name="show_job_transfer" value="0" type='radio' disabled
                                        {{$personalInjury['is_job_transfer'] == '0' ? 'checked' : ''}} >
                                    <label for="show-job-transfer-no"> {{ __('No') }} </label>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-12 {{$personalInjury['is_job_transfer'] == 0 ? 'hide' : ''}}">
                        <x-form.textarea-input wire:key="restriction-post-injury-{{$id}}"
                                               label="{{ __('Restriction Post Injury') }}"
                                               readonly="readonly" rows="2" >
                            {{$personalInjury['restriction_post_injury']}}
                        </x-form.textarea-input>
                    </div>

                    <div class="col-12 {{$personalInjury['is_job_transfer'] == 0 ? 'hide' : ''}}">
                        <x-form.text-input wire:key="number-of_light_duty_days-{{$id}}"
                                           label="{{ __('Numbers of Light Duty Days') }}"
                                           readonly="readonly"
                                           value="{{$personalInjury['number_of_light_duty_days']}}" />
                    </div>

                    <div class="col-12">
                        <x-form.textarea-input wire:key="doctors-remark-{{$id}}"
                                               label="{{ __('Doctor Remarks') }}"
                                               rows="2" readonly="readonly" >
                            {{$personalInjury['doctor_remark']}}
                        </x-form.textarea-input>
                    </div>
                </div>

            </div>

            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary waves-effect"
                        data-dismiss="modal">Close
                </button>
            </div>
        </div>
    </div>
</div><!-- /.modal -->
