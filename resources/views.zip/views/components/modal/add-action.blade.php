@props([ 'id', 'users',  'question' => [], 'datalist' => [], 'action' => [], 'operation' => 'write' ])


<div wire:key="action-{{$id}}" id="action-modal-{{$id}}" wire:ignore.self class="modal fade" tabindex="-1"
     role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">

    <div class="modal-dialog">
        <div class="modal-content ">

            <div class="modal-header bg-soft-light">
                <h4 class="modal-title">{{ __('Action Information') }}</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×
                </button>
            </div>

            <div class="modal-body p-4 bg-light">

                <div class="row">

                    <x-auth-validation-errors class="mb-4 text-danger col-12" :errors="$errors"/>

                    <div class="col-md-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:key="item_category_{{$id}}"
                                                 wire:model.lazy="action.{{$question->id}}.action_item_category"
                                                 onfocusout="changeBgColor(this)"
                                                 label="{{ __('Action Item Category') }}"
                                                 name="action_item_category"
                                                 required='required'>
                                @foreach($datalist->where('name','Action Item Category')->first()->content as $item )
                                    <option value="{{ $item }}">{{ $item }}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="item_category_read_{{$action['id']}}"
                                               label="{{ __('Action Item Category') }}"
                                               readonly="readonly" value="{{$action['action_item_category']}}"/>
                        @endif
                    </div>

                    <div class="col-md-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:key="category_{{$id}}"
                                                 wire:model.lazy="action.{{$question->id}}.action_category"
                                                 onfocusout="changeBgColor(this)"
                                                 label="{{ __('Action Category') }}"
                                                 name="action_category" required='required'>
                                @foreach($datalist->where('name','Action category')->first()->content as $item )
                                    <option value="{{ $item }}">{{ $item }}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="category_read_{{$action['id']}}"
                                               label="{{ __('Action Category') }}"
                                               readonly="readonly" value="{{$action['action_category']}}"/>
                        @endif
                    </div>
                </div>


                <div class="row">
                    <div class="col-12 col-md-6">
                        @if($operation == 'write')
                            <x-form.text-input wire:key="title_{{$id}}" wire:model.lazy="action.{{$question->id}}.title"
                                               onfocusout="changeBgColor(this)" placeholder="Title"
                                               label="{{ __('Action Title') }}" mb="3"
                                               name="title" id="title" required='required'/>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="title_read_{{$action['id']}}"
                                               label="{{ __('Action Title') }}"
                                               readonly="readonly" value="{{$action['title']}}"/>
                        @endif
                    </div>

                    <div class="col-12 col-md-6">
                        @if($operation == 'write')
                            <x-form.date-input wire:key="target_date_{{$id}}"
                                               wire:model.lazy="action.{{$question->id}}.target_date"
                                               onfocusout="changeBgColor(this)"
                                               label="{{ __('Target Date') }}" mb="3" min="{{date('Y-m-d')}}"
                                               name="target_date" id="target-date" required='required'/>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="target_read_{{$action['id']}}"
                                               label="{{ __('Target Date') }}"
                                               readonly="readonly" value="{{$action['target_date']}}"/>
                        @endif
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:key="risk_{{$id}}" wire:model.lazy="action.{{$question->id}}.risk"
                                                 onfocusout="changeBgColor(this)"
                                                 label="{{ __('Risk') }}" name="risk"
                                                 required='required'>
                                @foreach($datalist->where('name','Risk')->first()->content as $item )
                                    <option value="{{ $item }}">{{ $item }}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="risk_read_{{$action['id']}}"
                                               label="{{ __('Risk') }}"
                                               readonly="readonly" value="{{$action['risk']}}"/>
                        @endif
                    </div>

                    <div class="col-md-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:key="priority_{{$id}}"
                                                 wire:model.lazy="action.{{$question->id}}.priority"
                                                 onfocusout="changeBgColor(this)"
                                                 label="{{ __('Priority') }}" name="priority"
                                                 required='required'>
                                @foreach($datalist->where('name','Priority')->first()->content as $item )
                                    <option value="{{ $item }}">{{ $item }}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="priority_read_{{$action['id']}}"
                                               label="{{ __('Priority') }}"
                                               readonly="readonly" value="{{$action['priority']}}"/>
                        @endif
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-12">
                        @if($operation == 'write')
                            <x-form.textarea-input wire:key="description_{{$id}}"
                                                   wire:model.lazy="action.{{$question->id}}.description"
                                                   onfocusout="changeBgColor(this)" placeholder="Description"
                                                   label="{{ __('Action Description') }}"
                                                   name="description" required='required'
                                                   rows="3"/>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="description_read_{{$action['id']}}"
                                               label="{{ __('Action Description') }}"
                                               readonly="readonly" value="{{$action['description']}}"/>
                        @endif
                    </div>
                </div>


                <div class="row">
                    <div wire:ignore wire:key="responsible_person_{{$id}}" class="col-12 col-sm-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:model.lazy="action.{{$question->id}}.responsible_person"
                                                 wire:key="add-action-model-responsible-{{$question->id}}"
                                                 onfocusout="changeBgColor(this)" class="js-select"
                                                 label="{{ __('Responsible Person') }}"
                                                 required='required'
                                                 name="{{$question->id}}.responsible_person"
                                                 onchange='fetchActionData(this)'>
                                @foreach($users as $user)
                                    <option value="{{$user->id}}">{{$user->name}}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="responsible_read_{{$action['id']}}"
                                               label="{{ __('Responsible Person') }}"
                                               readonly="readonly"
                                               value="{{$users->firstWhere('id', $action['responsible_person'])->name}}"/>
                        @endif
                    </div>

                    <div class="col-12 col-sm-6">
                        @if($operation == 'write')
                            <x-form.text-input wire:key="responsible_department_{{$id}}" label="-"
                                               placeholder="{{ __('Department') }}"
                                               mb="3"
                                               disabled="disabled"/>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="responsible_department_read_{{$action['id']}}"
                                               label="{{ __('Department') }}"
                                               readonly="readonly"/>
                        @endif
                    </div>
                </div>


                <div class="row">
                    <div wire:key="approver_{{$id}}" wire:ignore class="col-12 col-sm-6">
                        @if($operation == 'write')
                            <x-form.select-input wire:model.lazy="action.{{$question->id}}.approver"
                                                 wire:key="add-action-model-approver-{{$question->id}}"
                                                 onfocusout="changeBgColor(this)" class="js-select"
                                                 label="{{ __('Approver') }}" mb="0"
                                                 placeholder="{{ __('Name') }}" name="{{$question->id}}.approver"
                                                 required='required' onchange='fetchActionData(this)'>
                                @foreach($users as $user)
                                    <option value="{{$user->id}}">{{$user->name}}</option>
                                @endforeach
                            </x-form.select-input>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="approver_read_{{$action['id']}}"
                                               label="{{ __('Approver') }}"
                                               readonly="readonly"
                                               value="{{$users->firstWhere('id', $action['approver'])->name}}"/>
                        @endif
                    </div>

                    <div class="col-12 col-sm-6">
                        @if($operation == 'write')
                            <x-form.text-input wire:key="approver_department_{{$id}}" label="-"
                                               placeholder="{{ __('Department') }}"
                                               mb="4"
                                               disabled="disabled"/>
                        @elseif($operation == 'read')
                            <x-form.text-input wire:key="approver_department_read_{{$action['id']}}"
                                               label="{{ __('Department') }}"
                                               readonly="readonly"/>
                        @endif
                    </div>
                </div>
            </div><!-- End Model Body -->

            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary waves-effect"
                        data-dismiss="modal">Close
                </button>
                @if($operation == 'write')
                    <button wire:click="storeAction({{$question->id}})" type="button"
                            class="btn btn-primary waves-effect waves-light">
                        Save
                    </button>
                @endif
            </div>

        </div><!-- End Model content -->
    </div><!-- End Model dialog -->
</div><!-- End Modal -->
