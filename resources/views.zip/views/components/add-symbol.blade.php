@props(['label' => '', 'size' => 'sm', 'color' => 'blue', 'id' => ''])
{{--available sizes: xs, sm, md, lg, xl, xxl--}}

<div class='form-group font-15'>
    <span wire:ignore
    {{$attributes->merge(['class' => 'text-primary', 'style' => 'position: absolute; top: 20px; right: 15px; z-index: 1'])}}
           >
            {{$label}}
            <i style="z-index: 1;" id="{{$id}}" data-feather="plus-circle"
               class="icon-dual-{{$color}} icons-{{$size}} clicky"></i>
    </span>
</div>
