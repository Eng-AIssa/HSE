@props(['route' => '', 'symbol' => '', 'name' => ''])

<li>
    <a href="{{$route}}">
        <i data-feather="{{$symbol}}"></i>
        <span> {{$name}} </span>
    </a>
</li>
