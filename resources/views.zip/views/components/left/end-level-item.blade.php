@props(['route' => '', 'name' => ''])

<li>
    <a  href="{{$route}}">{{$name}}</a>
</li>

