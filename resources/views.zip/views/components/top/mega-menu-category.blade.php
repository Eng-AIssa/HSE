@props(['categoryName' => ''])

<div class="col-md-4">
    <h5 class="text-dark mt-0 font-weight-normal">{{$categoryName}}</h5>
    <ul class="list-unstyled megamenu-list">
        {{$slot}}

    </ul>
</div>
