@props(['name' => '', 'icon' => ''])

<!-- item-->
<a href="javascript:void(0);" class="dropdown-item notify-item">

    <i class="{{$icon}}"> </i>

    <span>
        {{$name}}
    </span>
</a>
