<!-- Row of Widgets -->
<div class="row no-gutters">
    {{$slot}}
</div>
