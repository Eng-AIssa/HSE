@props(['widgetImage' => '', 'name' => ''])

<!-- Widget item -->
<div class="col">
    <a class="dropdown-icon-item" href="#">
        <img src="{{$widgetImage}}" alt="{{$name}}">
        <span>{{$name}}</span>
    </a>
</div>
