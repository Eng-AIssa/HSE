@props(['itemName' => ''])

<li>
    <a {{$attributes->merge(['href' => "home"])}}>{{$itemName}}</a>
</li>
