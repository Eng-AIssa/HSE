@props(['label' => '', 'id' => ''])


<div class='form-group font-15'>
    <span wire:ignore
        {{$attributes->merge(['class' => 'text-danger', 'style' => 'position: absolute; right: 15px; z-index: 1;'])}}>
            {{$label}}
            <i id="{{$id}}" style="z-index: 1;" class="text-danger clicky">X</i>
    </span>
</div>
