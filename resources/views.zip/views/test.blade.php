<x-main-layout>

    @push('css')
        <link href="{{asset('css/dropzone.css')}}" rel="stylesheet" type="text/css"/>
    @endpush


    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show"
             style="position: fixed; top: 80px; right: 10px; z-index: 1;  "
             role="alert">
            <i data-feather="check-circle" class="icons-xs mr-1"></i> {{session('success')}}
            <button type="button" class="close" data-dismiss="alert"
                    aria-required='required' label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif


    <x-slot name="pageTitle">
        {{ __('Incident') }}
    </x-slot>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-sm-10 col-md-9 col-xl-8">
                <div class="card-box">
                    <div class="row">

                        <h3 class="ml-3 mb-4">{{ __('Incident') }} # 92 </h3>

                        <form id="incident-form" class="col-sm-10 col-xl-11 ml-2 mt-2"
                              action="{{route('accident.store')}}" method="POST">
                            @csrf

                            <x-auth-validation-errors class="mb-4 text-danger" :errors="$errors"/>

                            <input type="hidden" name="section_id" value="1">
                            <input type="hidden" name="stage_id" value="1">
                            <input type="hidden" name="timeline_id" value="1">


                            <h5 class="bg-light p-2 mt-0 mb-3">Category & Title</h5>

                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <x-form.select-input id="incident_type" required='required'
                                                         label="{{ __('Incident Type') }}"
                                                         name="incident_type">
                                        @foreach($datalist->where('name','Incident Type')[0]->content as $item)
                                            <option id="{{$item}}" value="{{$item}}">{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.select-input required='required' label="{{ __('Incident Group') }}"
                                                         name="incident_group">
                                        @foreach($datalist->where('name','Incident Group')->first()->content as $item)
                                            <option value="{{$item}}">{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>
                            </div>


                            <x-form.text-input required='required' label="{{ __('Title') }}" mb="3" name="title"
                                               id="title"/>


                            <h5 class="bg-light p-2 mt-0 mb-3">Time & Location</h5>

                            <div class="row ">
                                <div class="col-12 col-sm-6">
                                    <x-form.date-input max="{{date('Y-m-d')}}" required='required'
                                                       label="{{ __('Date Occurred') }}" name="date_occurred"/>

                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.time-input required='required' label="{{ __('Time Occurred') }}"
                                                       name="time_occurred"/>
                                </div>
                            </div>


                            <div class="row ">
                                <div class="col-12 col-sm-6">
                                    <x-form.date-input max="{{date('Y-m-d')}}" required='required'
                                                       label="{{ __('Logging Date') }}" name="logging_date"/>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.time-input required='required' label="{{ __('Logging Time') }}"
                                                       name="logging_time"/>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input required='required' label="{{ __('Location') }}"
                                                         name="location_id">
                                        @foreach($locations as $location)
                                            <option value="{{$location->id}}">{{ $location->name }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.select-input required='required' label="{{ __('Area') }}" name="area_id">
                                        <option>Area-A</option>
                                        <option>Area-B</option>
                                        <option>Area-C</option>
                                        <option>Area-D</option>
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-4">
                                    <x-form.text-input label="{{ __('-') }}" placeholder="{{ __('Further Details') }}"/>
                                </div>
                            </div>


                            <h5 class="bg-light p-2 mt-0 mb-3">Incident Data</h5>

                            <x-form.textarea-input required='required' label="{{ __('Incident Description') }}"
                                                   name="incident_description"/>

                            <x-form.textarea-input required='required' label="{{ __('Immediate Action Taken') }}"
                                                   rows="2"
                                                   name="immediate_action_taken"/>


                            <div class="row mt-4 mb-2">
                                <div class="col-6">
                                    <x-form.select-input required='required' label="{{ __('Incident Related to') }}"
                                                         class="ml-1"
                                                         name="incident_related_to">
                                        @foreach($datalist->where('name','Incident Related To')->first()->content as $item)
                                            <option value="{{ $item }}">{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-6 mt-3">
                                    <div class="checkbox checkbox-primary mt-2 ">
                                        {{--<div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="one"
                                                   name="done_communication" value="1">
                                            <label class="custom-control-label"
                                                   for="one">{{ __('Communication done to authorities') }}</label>
                                        </div>--}}
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="two"
                                                   name="is_repeated" value="1">
                                            <label class="custom-control-label"
                                                   for="two">{{ __('Repeated Incident') }}</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-12" id="type-of-activity" style="display: none;">
                                    <x-form.select-input label="{{ __('Type of Activity at Time of Incident') }}"
                                                         name="type_of_activity_at_time_of_incident"
                                    >
                                        @foreach($datalist->where('name','Type Of Activity At Time Of Incident')->first()->content as $item)
                                            <option value="{{ $item }}">{{ $item }}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>
                            </div>

                            <x-form.select-input required='required' label="{{ __('Classification') }}"
                                                 id="general_classification"
                                                 name="general_classification">
                                @foreach($datalist->where('name','General Classification')->first()->content as $item)
                                    <option value="{{ $item }}">{{ $item }}</option>
                                @endforeach
                            </x-form.select-input>


                            <div class="pl-2 my-4" style="display: none;" id="accident-consequences">
                                <p class=" font-15 ">Actual Loss</p>
                                <div class="row ">
                                    <div class="col-12 col-sm-6 col-md-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check2"
                                                   name="consequences[]" value="PersonalInjury">
                                            <label class="custom-control-label" for="Check2">Personal Injury </label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check1"
                                                   name="consequences[]" value="Spill">
                                            <label class="custom-control-label" for="Check1">Spill </label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check7"
                                                   name="consequences[]" value="Safety">
                                            <label class="custom-control-label" for="Check7"> Safety</label>
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-6 col-md-4col-12 col-sm-6 col-md-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check5"
                                                   name="consequences[]" value="AssetDamage">
                                            <label class="custom-control-label" for="Check5"> Asset Damage</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check3"
                                                   name="consequences[]" value="GasLeak">
                                            <label class="custom-control-label" for="Check3"> Gas Leak</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check8"
                                                   name="consequences[]" value="TransportSafety">
                                            <label class="custom-control-label" for="Check8"> Transport Safety</label>
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-6 col-md-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check6"
                                                   name="consequences[]" value="Environment">
                                            <label class="custom-control-label" for="Check6">Environment</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="Check4"
                                                   name="consequences[]" value="Fire">
                                            <label class="custom-control-label" for="Check4">Fire/Explosion</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <h5 class="bg-light p-2 mt-0 mb-3 assessment-show" style="display: none;">Loss
                                Potential</h5>

                            <div class="pl-2 my-4 assessment-show" style="display: none">
                                <div class="row ">
                                    <div class="col-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="people">
                                            <label class="custom-control-label" for="people">People </label>
                                        </div>
                                    </div>

                                    <div class="col-4">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="environment">
                                            <label class="custom-control-label" for="environment"> Environment</label>
                                        </div>
                                    </div>

                                    <div class="col-4 col-md">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="cost">
                                            <label class="custom-control-label" for="cost">Asset & Production
                                                Loss</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row my-3 border rounded" id="assessment" style="display: none">
                                <x-form.loss name="People" matrix-id="people-matrix" id="people-evaluation"
                                             :datalist="$datalist" style="display: none;">
                                    @foreach($datalist->where('name','Potential Severity People')->first()->content as $item)
                                        <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                                    @endforeach
                                </x-form.loss>

                                <x-form.loss name="Environment" matrix-id="environment-matrix"
                                             id="environment-evaluation" :datalist="$datalist" style="display: none;">
                                    @foreach($datalist->where('name','Potential Severity Environment')->first()->content as $item)
                                        <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                                    @endforeach
                                </x-form.loss>

                                <x-form.loss name="Asset & Production Loss" matrix-id="cost-matrix" id="cost-evaluation"
                                             :datalist="$datalist" style="display: none;">
                                    @foreach($datalist->where('name','Potential Severity Cost')->first()->content as $item)
                                        <option value="{{ $item[0] . $item[1] }}">{{ $item }}</option>
                                    @endforeach
                                </x-form.loss>

                                <div class="col-12">
                                    <div class="row" style="margin-left: 0.5rem;">
                                        <x-form.matrix id="people-matrix" name="People"/>
                                        <x-form.matrix id="environment-matrix" name="Environment"/>
                                        <x-form.matrix id="cost-matrix" name="Cost"/>
                                    </div>
                                </div>
                            </div>


                            <h5 class="bg-light p-2 mt-0 mb-3">Related People</h5>

                            <div class="row ">
                                <div class="col-12 col-sm-6">
                                    <x-form.text-input required='required' label="{{ __('Reported By') }}"
                                                       disabled="disabled"
                                                       placeholder="{{ __('Name') }}" mb="0"
                                                       value="{{Auth::user()->name}}" users="users"/>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.text-input label="-"
                                                       placeholder="{{ __('Department') }}" mb="3"
                                                       disabled="disabled"
                                                       value="{{Auth::user()->department}}"/>
                                </div>
                            </div>


                            <div class="row ">
                                <div class="col-12 col-sm-6 ">
                                    <x-form.select-input id="anyId" required='required'
                                                         label="{{ __('Responsible Person') }}"
                                                         placeholder="{{ __('Name') }}" name="responsible_person"
                                                         users='users'>
                                        @foreach($users as $user)
                                            <option value="{{$user->id}}">{{$user->name}}</option>
                                        @endforeach
                                    </x-form.select-input>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <x-form.text-input label="-"
                                                       placeholder="{{ __('Department') }}" mb="3"
                                                       disabled="disabled"/>
                                </div>
                            </div>


                            <h5 class=" bg-light p-2 mt-0 mb-3">Attachments & Documents</h5>

                            <div class="row">
                                <div class="col-12">
                                    <div style="border: 2px dashed rgba(0,0,0,0.3);"

                                          class="dropzone " id="mine"
                                          >

                                        <div class="fallback">
                                            <input name="file" type="file" multiple/>
                                        </div>

                                        <div class="dz-message needsclick">
                                            <i class="h1 text-muted dripicons-cloud-upload"></i>
                                            <h3>Drop files here or click to upload.</h3>
                                            <span class="text-muted font-15">
                                                Please note that <strong>25MB</strong> is the limit per file
                                                </span>
                                        </div>
                                    </div>

                                    <!-- Preview -->
                                    <div class="dropzone-previews mt-3" id="file-previews"></div>
                                </div>
                            </div>


                            <!-- file preview template -->
                            <div class="d-none" id="uploadPreviewTemplate">
                                <div class="card mt-1 mb-0 shadow-none border">
                                    <div class="p-2">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <img data-dz-thumbnail src="#" class="avatar-sm rounded bg-light"
                                                     alt="">
                                            </div>
                                            <div class="col pl-0">
                                                <a href="javascript:void(0);" class="text-muted font-weight-bold"
                                                   data-dz-name></a>
                                                <p class="mb-0" data-dz-size></p>
                                            </div>
                                            <div class="col-auto">
                                                <!-- Button -->
                                                <a href="" class="btn btn-link btn-lg text-muted" data-dz-remove>
                                                    <i class="dripicons-cross"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row justify-content-end ">
                                <x-form.button label="{{ __('Save As Draft') }}" class="m-1"/>
                                <x-form.button id="submit-button" label="{{ __('Submit') }}" class="m-1"/>
                            </div>
                        </form>



                            {{--<x-form.file-input label="{{ __('Evidence Attachments') }}"/>--}}


                        </div>
                    </div>
                    <!-- Row End -->
                </div>
                <!-- CardBox End -->
            </div>
            <!-- CardBox Size End -->
        </div>
        <!-- Container Row End -->
    </div>
    <!-- Container End -->


    @push('scripts')


        <script>

            //submit form on click
            $('#submit-button').click(function () {
                $('#incident-form').submit();
            });


            //show, hide, edit fields based on incident type[ accident or nearmiss]
            $('#incident_type').on('change', function () {

                //if Nearmiss chosen
                if ($('#Nearmiss').is(':selected')) {
                    $('#nearmiss-evaluation').show();
                    $('#type-of-activity').show();
                    $('.assessment-show').show();
                    $('#accident-consequences').hide();


                    $("label,h5, h3, h2, .page-title-box li").each(function () {
                        let text = $(this).text();
                        text = text.replace("Incident", "Nearmiss");
                        text = text.replace("Accident", "Nearmiss");
                        $(this).text(text);
                    });
                }
                //if Accident chosen
                else {
                    $('#nearmiss-evaluation').hide();
                    $('#type-of-activity').hide();
                    $('.assessment-show').hide();
                    $('#assessment').hide();
                    $('#accident-consequences').show();


                    $("label,h5, h3, h2, .page-title-box li").each(function () {
                        let text = $(this).text();
                        text = text.replace("Incident", "Accident");
                        text = text.replace("Nearmiss", "Accident");
                        $(this).text(text);
                    });
                }

            });


            //auto choose Risk based on consequences/frequency change
            $('.matrix-options').on('change', function () {

                let consequence = $(this).parents('.loss-category').find('#consequence-category');
                let frequency = $(this).parents('.loss-category').find('#frequency-of-occurrence');
                let risk = $(this).parents('.loss-category').find('#risk');
                let matrix = $(this).parents('.loss-category').find('#matrix-id').val();


                frequency.prop('disabled', false);
                $('#' + matrix + ' span').html('-');
                let result = consequence.val() + frequency.val();

                Jump(result);

                function Jump(result) {
                    switch (result) {
                        case 'C5F3':
                            $('#' + matrix + ' .C5F3').html(22);
                            Jump('finish HH');
                            break;
                        case 'C5F4':
                            $('#' + matrix + ' .C5F4').html(24);
                            Jump('finish HH');
                            break;
                        case 'C5F5':
                            $('#' + matrix + ' .C5F5').html(25);
                            Jump('finish HH');
                            break;
                        case 'C4F4':
                            $('#' + matrix + ' .C4F4').html(21);
                            Jump('finish HH');
                            break;
                        case 'C4F5':
                            $('#' + matrix + ' .C4F5').html(23);
                            Jump('finish HH');
                            break;
                        case 'C3F5':
                            $('#' + matrix + ' .C3F5').html(20);
                            Jump('finish HH');
                            break;
                        case 'finish HH':
                            risk.val('High High');
                            risk.css('background-color', '#fb7363');
                            risk.css('color', 'white');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C5F2':
                            $('#' + matrix + ' .C5F2').html(19);
                            Jump('finish H');
                            break;
                        case 'C4F2':
                            $('#' + matrix + ' .C4F2').html(14);
                            Jump('finish H');
                            break;
                        case 'C4F3':
                            $('#' + matrix + ' .C4F3').html(18);
                            Jump('finish H');
                            break;
                        case 'C3F4':
                            $('#' + matrix + ' .C3F4').html(17);
                            Jump('finish H');
                            break;
                        case 'C2F5':
                            $('#' + matrix + ' .C2F5').html(16);
                            Jump('finish H');
                            break;

                        case 'finish H':
                            risk.val('High');
                            risk.css('background-color', '#ec8631');
                            risk.css('color', 'white');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C5F1':
                            $('#' + matrix + ' .C5F1').html(15);
                            Jump('finish m');
                            break;
                        case 'C4F1':
                            $('#' + matrix + ' .C4F1').html(10);
                            Jump('finish m');
                            break;
                        case 'C3F2':
                            $('#' + matrix + ' .C3F2').html(9);
                            Jump('finish m');
                            break;
                        case 'C3F3':
                            $('#' + matrix + ' .C3F3').html(13);
                            Jump('finish m');
                            break;
                        case 'C2F3':
                            $('#' + matrix + ' .C2F3').html(8);
                            Jump('finish m');
                            break;
                        case 'C2F4':
                            $('#' + matrix + ' .C2F4').html(12);
                            Jump('finish m');
                            break;
                        case 'C1F5':
                            $('#' + matrix + ' .C1F5').html(11);
                            Jump('finish m');
                            break;

                        case 'finish m':
                            risk.val('Medium');
                            risk.css('background-color', '#f1f27c');
                            risk.css('color', 'black');
                            $('#' + matrix).fadeIn(1000);
                            break;

                        case 'C3F1':
                            $('#' + matrix + ' .C3F1').html(6);
                            Jump('finish l');
                            break;
                        case 'C2F1':
                            $('#' + matrix + ' .C2F1').html(3);
                            Jump('finish l');
                            break;
                        case 'C2F2':
                            $('#' + matrix + ' .C2F2').html(5);
                            Jump('finish l');
                            break;
                        case 'C1F1':
                            $('#' + matrix + ' .C1F1').html(1);
                            Jump('finish l');
                            break;
                        case 'C1F2':
                            $('#' + matrix + ' .C1F2').html(2);
                            Jump('finish l');
                            break;
                        case 'C1F3':
                            $('#' + matrix + ' .C1F3').html(4);
                            Jump('finish l');
                            break;
                        case 'C1F4':
                            $('#' + matrix + ' .C1F4').html(7);
                            Jump('finish l');
                            break;

                        case 'finish l':
                            risk.val('Low');
                            risk.css('background-color', '#aadbee');
                            risk.css('color', 'black');
                            $('#' + matrix).fadeIn(1000);
                            break;
                    }
                }
            });


            //change background-color if an input is filled
            $("input, select, textarea").focusout(function () {
                if ($(this).attr('id') === 'title') {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "#f6ffad");
                } else {
                    if ($(this).val() !== '')
                        $(this).css("background-color", "rgb(232, 240, 254)");
                }
                if ($(this).val() === '')
                    $(this).css("background-color", "#fff");
            });

        </script>


        //show-hied assessments based on their checkbox value
        <script>
            let assessment = $('#assessment');
            $("#people").on('change', function () {

                if ($(this).prop('checked') === false)
                    $('#people-matrix').fadeOut(1000);
                $('#people-evaluation').fadeToggle(1000);
                assessment.show();
            });

            $("#environment").on('change', function () {

                if ($(this).prop('checked') === false)
                    $('#environment-matrix').fadeOut(1000);
                $('#environment-evaluation').fadeToggle(1000);
                assessment.show();
            });

            $("#cost").on('change', function () {

                if ($(this).prop('checked') === false)
                    $('#cost-matrix').fadeOut(1000);
                $('#cost-evaluation').fadeToggle(1000);
                assessment.show();
            });
        </script>


        <!-- Dropzone file uploads-->
        <script src="{{asset('js/dropzone.js')}}"></script>

        <!-- Init js-->
        <script src="{{asset('js/pages/form-fileuploads.init.js')}}"></script>

    @endpush
</x-main-layout>
